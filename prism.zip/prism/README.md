# PRISM

```
common/         shared Dataflow worker code            -> image prism-common
sources/<src>/  one folder per source (pgw, ...)       -> image prism-<src>  (FROM prism-common)
orchestrator/   orchestrator, recon, config_admin      -> image prism-orchestrator
gui/            web GUI: login, roles, module access   -> image prism-gui  (docs/DEPLOY_GUI.md)
sql/            BigQuery DDL (ddl.sql, ddl_config.sql, ddl_recon.sql, ddl_gui.sql, ddl_transform.sql)
build/          Cloud Build files
docs/           DEPLOY.md, DEPLOY_CLOUD_RUN.md, DEPLOY_GUI.md, DASHBOARD_STUDIO.md, TRANSFORMATION_CODE.md
tests/          tests and import checks (run from the project root: python tests/<name>.py)
```
Start with `docs/DEPLOY.md`. Before every deploy: `python tests/check_worker_imports.py`, `check_orchestrator_imports.py` and `check_gui_imports.py`.
