# PRISM GUI - deploy and operate (internal access only)

The GUI is a small Flask app (`gui/`) in its own image `prism-gui`. Users and roles live in BigQuery (`VPDB_ADM`), next to
the PRISM config tables. Lookups are edited through the same `ConfigStore` as `config_admin.py`, so the same validation and the
same version history apply; the signed-in user is written as `changed_by`.

## What you get
| Area | Behaviour |
|---|---|
| Sign-in | username + password (scrypt hashes), same error for unknown user / wrong password / disabled user, 5 wrong passwords in a row lock the account for 15 min (an administrator can unlock), session ends after 30 min idle or 8 h in any case |
| Passwords | min 12 characters, 3 of 4 character classes, no easy words, not the username, not one of the last 5 passwords, expire after 90 days; users change their own under **Change password**; an administrator **resets** to a one-time temporary password the user must change at first sign-in |
| Roles | a role = access level per module (**No access / View / Edit**). Built-in: `admin`, `operator`, `viewer`. Create more under **Roles** |
| Module access | each user has a role and can have **per-module overrides** (e.g. operator + Edit on Reconciliation). Modules: Sources & settings (view), Lookups (view/edit), Reconciliation (view), Audit log (view), Users (view/edit), Roles (view/edit) |
| Safeguards | you cannot disable yourself, and no change may leave zero enabled users who can manage users |
| Audit | sign-ins, failures, lock-outs, password changes/resets, user/role/lookup changes (Audit log module) |
| Web security | CSRF token on every form, HttpOnly + SameSite cookie, Secure cookie in production, CSP: no scripts anywhere except Dashboard Studio pages, which may load only their own `/static/dash*.js` (never inline), `no-store`, only same-site redirects after sign-in |

Settings (lengths, lock-out, timeouts) are the constants at the top of `gui/security.py`; modules and built-in roles are in `gui/rbac.py`.

## 1. Tables
Run `sql/ddl_gui.sql` in BigQuery (creates `prism_gui_user`, `prism_gui_role`, `prism_gui_audit` and, for Dashboard Studio, `prism_gui_dashboard` and `prism_gui_dashboard_share`; CMEK like the others).

## 2. Build the image
```
gcloud builds submit --region=europe-west2 --config=build/cloudbuild.gui.yaml --substitutions=_TAG=1.0 .
```
(`build/cloudbuild.yaml` also builds it together with the other images.)

## 3. Secret + service account
```
# signing key for the session cookie: 64 random hex characters, same value for every instance
openssl rand -hex 32 | gcloud secrets create prism-gui-secret-key --data-file=-

gcloud iam service-accounts create prism-gui
```
Grant `prism-gui@<project>.iam.gserviceaccount.com` only what it needs (check role names in the current IAM docs):
- BigQuery Job User on the project
- BigQuery Data Editor on the tables it writes: `prism_transform_code` (transformation code), `prism_gui_user`, `prism_gui_role`, `prism_gui_audit`, `prism_gui_dashboard`,
  `prism_gui_dashboard_share`, `prism_lookup_config`; Data Viewer on the rest of `VPDB_ADM` (Dashboard Studio reads `file_registry`,
  `prism_runs`, `recon_result`, `recon_alarm`)
- Cloud KMS CryptoKey Encrypter/Decrypter on the CMEK key the tables use
- Secret Manager Secret Accessor on `prism-gui-secret-key`

## 4. Deploy for internal access only
```
gcloud run deploy prism-gui \
  --image europe-west2-docker.pkg.dev/vf-uk-raid-pre-prod/prism/prism-gui:1.0 \
  --region europe-west2 --service-account prism-gui@vf-uk-raid-pre-prod.iam.gserviceaccount.com \
  --set-secrets PRISM_GUI_SECRET_KEY=prism-gui-secret-key:latest \
  --ingress internal --allow-unauthenticated --max-instances 2
```
- `--ingress internal` is what keeps it off the internet: only traffic from your VPC (or an internal load balancer, or
  connected networks such as VPN/Interconnect) reaches it. `--allow-unauthenticated` is acceptable **only together with** this,
  because the app has its own sign-in; browsers cannot send Google IAM tokens.
- For people on the corporate network to open it you need a private route and a name: usually an **internal Application
  Load Balancer** with a private DNS name and a certificate, reached over your existing VPN/Interconnect. Ask the network
  team for the exact pattern; if your organisation already uses **Identity-Aware Proxy**, put it in front and keep the
  application login as a second factor of access.
- Confirm with your cloud/security team that an org policy does not already force the ingress setting.

## 5. First administrator
From Cloud Shell or a trusted workstation (the temporary password is printed once; do not run it where output is logged):
```
pip install flask google-cloud-bigquery
python gui/manage.py seed-roles
python gui/manage.py create-admin <your-username> --name "Your Name"
```
Sign in with the temporary password; you are made to choose a new one. Then create the other users in the GUI.
Rescue commands: `manage.py reset-password NAME`, `manage.py unlock NAME`, `manage.py list-users`.

## 5b. Upgrading an installation that already has roles
After deploying a version with Dashboard Studio run `python gui/manage.py seed-roles` once: it adds the new modules to the built-in roles
(never lowering a level that is already set) and sets them to No access on custom roles. See `docs/DASHBOARD_STUDIO.md`.

## 6. Try it locally without Google Cloud
```
pip install flask google-cloud-bigquery
PRISM_GUI_DEV=1 python gui/app.py          # prints a demo admin password; sample data; nothing is saved
```

## Adding a module later
1. Add it to `MODULES` in `gui/rbac.py` (label, one-line description, `max` = highest level it supports).
2. Add its route in `gui/app.py` with `@need("<module>")` (view) and `rbac.allowed(g.perms, "<module>", rbac.EDIT)` for changes.
3. Add its template in `gui/templates/` and its endpoint name to the nav (the nav uses the module key as the endpoint name).
4. Roles and per-user overrides pick it up automatically; give it to the right roles under **Roles**.

## Things to know
- **Latency:** every sign-in reads BigQuery (about a second). User and role lookups are cached 20 s per instance, so a change made
  on one instance can take up to 20 s to reach another. Password changes and disabling a user end their sessions at the next click.
- **No multi-factor, no "forgot password" e-mail:** an administrator resets passwords. If you need SSO/MFA, front the service with IAP.
- **Secrets:** the session cookie is signed, not encrypted: it holds the username and timestamps, never a password. Rotate
  `prism-gui-secret-key` to sign everybody out.
- **Fonts:** `gui/static/fonts` holds the Vodafone brand fonts copied from vodafone.com. Keep the GUI Vodafone-internal.
- **Version 1 limits:** Sources and Reconciliation are read-only in the GUI (use `config_admin.py` to change them); Lookups can be edited.
