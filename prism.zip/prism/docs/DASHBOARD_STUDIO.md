# PRISM Dashboard Studio - architecture, status and operations

Status: **Milestone 1 (vertical slice) and the JavaScript phase (interactive builder and viewer) are implemented.**
Server logic is tested with an **in-memory store, a sample-data runner and a fake BigQuery client**; the JavaScript is tested in a
**real headless Chromium** against that same demo app. **Nothing has been run against real BigQuery, real PRISM data or a deployed
Cloud Run service.**

## 1. Phase 0 - what the repository actually contains
| Question in the specification | Finding (from the code) |
|---|---|
| Frontend framework | None in the SPA sense. The PRISM GUI is **Flask + Jinja, server-rendered, no JavaScript**, with a Content-Security-Policy of `script-src 'none'`. |
| Backend | Python 3.12, **Flask** (`gui/app.py`), gunicorn in the `prism-gui` image; orchestrator/recon in separate Cloud Run job images. |
| Authentication / authorization | The GUI has its **own** local login (scrypt passwords, lock-out, sessions) and **roles with per-module levels** (`gui/rbac.py`). It is **not** corporate SSO and has no Google-group resolution. |
| BigQuery | `google-cloud-bigquery` through `config_store.BqHelper` (CMEK key attached to every job, location from `prism_settings`). Control dataset `VPDB_ADM`. |
| Persistence for application metadata | **BigQuery append-only versioned tables** (config tables, `prism_gui_*`). Reused for dashboards. |
| Existing dashboards / charts / Looker | **None.** No chart library, no Looker integration anywhere in the repository. |
| Existing data | Only PRISM's own control tables are defined in the DDL: `file_registry`, `file_processing_log`, `file_read_counts`, `prism_runs`, `recon_result`, `recon_alarm`. The PGW detail table is configured per source but its columns are not defined in this repository. |
| TAP / ASN / AMA / CDR / profile integrity / fraud | **No tables or schemas exist in the repository** for these. No templates were created for them. |
| Financial / revenue-exposure metrics | **None exist.** None were invented. |
| CI/CD | Cloud Build files in `build/`; tests are plain Python scripts in `tests/` (no pytest/CI config). |

### Consequences for the specification
* **JavaScript phase:** scripts are now allowed **only on Dashboard Studio pages, only from `/static/dash*.js`, never inline** (`script-src 'self'`; every other page keeps `script-src 'none'`). No chart library is used: the build environment had no network access to fetch Apache ECharts, and server-drawn SVG is simple to test and has no supply-chain surface. Charts stay server-rendered; `dash.js` / `dash_editor.js` (plain JavaScript, ~300 lines) add lazy loading, tooltips, filtering and the layout editor. If you later want a client-side charting library, vendor it into `gui/static` (no CDN) and keep the `/render` endpoint as the data source.
* **"Reuse corporate SSO and group membership"** cannot be honoured because the GUI does not use SSO yet. Sharing is to **users and roles** instead of groups. Putting IAP/SSO in front of the GUI and mapping groups to roles is an open item.
* **BigQuery row-level / column-level security** applies to the identity running the query. The GUI runs every dashboard query as **one service account**, so BigQuery RLS cannot distinguish users. Data access is therefore enforced **in the application** (dataset-to-module mapping, below). If you need per-user RLS, queries must run as the end user (OAuth/impersonation) - a design change, not done.

## 2. Architecture
```
Browser  --(session cookie, CSRF)-->  Flask route (gui/dashboards.py)
   1. authentication + @need(module)                       gui/app.py gate()
   2. DASHBOARD access   (owner / share / admin)           gui/dash_access.py   (404 if not allowed to know it exists)
   3. validate stored widget config                        gui/dash_spec.py     (whitelisted keys, catalog-only references)
   4. DATA access        (user's own module >= View)       gui/dash_catalog.allowed_datasets(perms)
   5. build SQL from catalog + @parameters                 gui/dash_spec.build_query  (no SELECT *, partition range, LIMIT)
   6. run with cost caps                                   gui/dash_exec.BigQueryRunner (max bytes billed, timeout, concurrency, labels)
   7. render KPI / SVG / table                             gui/charts.py        (all text HTML-escaped)
   8. audit (who, dashboard, queries, bytes, ms)           store.audit
```
The browser never receives SQL, credentials or tokens, and a dashboard never stores SQL.

### Approved catalog (`gui/dash_catalog.py`)
Four datasets, 18 governed metrics, all taken from `sql/ddl.sql` / `sql/ddl_recon.sql`. `tests/test_gui_dashboards.py` **parses the DDL files and fails if a column or metric expression in the catalog does not exist**. Metric formulas live only here (defined once, server-side).
| Dataset | Table | Needs module | Time (partition) field |
|---|---|---|---|
| File processing status | `file_registry` | Pipeline data | `discovered_at` |
| Pipeline runs | `prism_runs` | Pipeline data | `started_at` |
| Reconciliation results | `recon_result` | Recon data | `window_start` |
| Reconciliation alarms | `recon_alarm` | Recon data | `window_start` |
Adding a dataset = adding an entry (reviewed in git). Users cannot type tables, columns or SQL.

### Metadata model (`sql/ddl_gui.sql`)
* `prism_gui_dashboard` (append-only): `dashboard_id, version, kind, name, description, owner, status, published_version, published_at, definition (JSON), changed_at, changed_by, note`. Newest row = current state; `published_version` is the version viewers see, so **a published version is preserved while the owner edits the draft**.
* `prism_gui_dashboard_share` (append-only): user or role grants, `active=FALSE` revokes.
* `definition` JSON: `{schema, date:{preset}, widgets:[{id,type,title,dataset,metrics,dims,time_grain,filters,sort,limit,span,stacked,decimals}]}`. Schema version field allows migrations.

### Permissions (`gui/rbac.py`, `gui/dash_access.py`)
| Capability | How it is granted | Default |
|---|---|---|
| View dashboards shared with me | module **Dashboards = View** | viewer, operator |
| Create / edit own dashboards (Dashboard Creator) | **Dashboards = Edit** | role `dashboard-creator` only; **off for ordinary users** |
| Publish / unpublish / share own dashboards (Publisher) | **Publish & share = Edit** | role `dashboard-publisher` |
| See / edit / publish / share / archive any dashboard (Platform admin) | **Dashboard admin = Edit** | role `admin` |
| Read data behind widgets | **Pipeline data / Recon data = View** (the user's OWN role) | viewer, operator, creator, publisher |
| Export widget data as CSV | module **Export data = View** (in addition to viewing and data access) | admin only |
| Data Steward | catalog changes are code-reviewed in git (no UI yet) | - |
A share never grants data access: a viewer lacking the dataset's module sees "no access to the data" and **no query is run** (tested).

### Routes (all under `/dashboards`, all re-check access server-side)
`GET /dashboards` gallery (My / Shared with me / All (admin) / Templates, search, sort, archived) · `POST /new` · `GET /<id>` viewer (`?draft=1` owner preview, `range` / `start` / `end`) · `GET /<id>/edit` · `POST /<id>/settings` · `GET|POST /<id>/widgets[/<wid>]` (+ `/delete`, `/move`) · `POST /<id>/publish|unpublish|archive|duplicate|restore/<v>` · `GET|POST /<id>/share[/revoke]` · `GET /<id>/versions` · `GET /catalog` · `GET /catalog/<dataset>/preview`.
A dashboard the user may not know about answers **404** (name and existence never revealed); no-Edit-level users get the same 403 for real and non-existent edit URLs.

## 3. Status against the milestones
| Item | Status |
|---|---|
| Navigation, gallery (My / Shared / All / Templates, search, sort, archive) | **Done** |
| Create, add / configure / reorder / remove widgets, save draft, reopen, preview | **Done** |
| **Drag to move, drag the edge to resize (snaps to 3/4/6/8/12 of 12 columns), undo / redo (buttons and Ctrl+Z / Ctrl+Y), unsaved-change warning, save layout** | **Done, tested in a real browser** (arrows + width setting remain as the no-JavaScript fallback) |
| Widget types: KPI (**with previous-period comparison**), line, **area**, bar (grouped / stacked), **donut**, **heatmap**, data table, **pivot table** | **Done.** Exception-summary widget: build it as a table widget with filters (template); not a separate type |
| Interactive charts: tooltips, legend click to show / hide a series | **Done** |
| **Lazy widget loading** (a widget runs its query only when it scrolls into view; 3 at a time), per-widget "Updated hh:mm:ss" freshness, **Refresh button, optional automatic refresh (1 / 5 / 15 min, visible widgets only)** | **Done.** Freshness is the *query time*, not the age of the underlying data |
| **Viewer filters**: date range plus up to 4 dashboard filters on fields the creator enables; **click a bar / slice / point / cell to filter every widget** (chips to remove) | **Done.** Filters apply to a dataset only if it has that field ("shared" fields such as Source and Reconciliation span datasets; others filter only their own dataset) |
| **CSV export** | **Done**, behind its own permission (**Export data**, off by default), the user's own data access, injection-safe (`=`, `+`, `-`, `@` text cells are neutralised), audited. XLSX / PDF: not done |
| Backend validation, parameterised catalog-only SQL, partition range, limits | **Done** (all new widget types and filters go through it) |
| Cost controls: max-bytes-billed 5 GiB, 30 s timeout, 4 concurrent queries, job labels | **Done** (a comparison KPI runs 2 queries; lazy loading avoids queries for widgets nobody scrolls to) |
| Roles, creator / publisher / viewer / admin, IDOR protection, sharing by user or role, draft vs published, versions, restore | **Done** |
| Audit: create / save / publish / share / view (with query count and bytes) / denied / export; single widget queries when they fail or scan >= 100 MB | **Done** (per-widget success rows are not written: one BigQuery insert per widget would be slow and costly) |
| Starter templates | **2** (Pipeline operations, Reconciliation overview). Others need real schemas first |
| Authorized **drill-down** to detail, server-side sorting / pagination of tables | **Not done** |
| Trend comparison on charts (only KPI comparison exists), cross-filter by series on multi-dataset keys | **Not done** |
| Caching with authorization-scoped keys | **Not done** (BigQuery's own query cache applies) |
| XLSX / PDF export, scheduled delivery, threshold alerts | **Not done** |
| Submit-for-approval publishing workflow, favourites, tags, group-based sharing (needs SSO) | **Not done** |
| AI-assisted creation | **Not done** |
| TAP / ASN / AMA / CDR / profile-integrity / fraud / financial datasets and templates | **Not possible yet**: no schemas in the repository |
| Real BigQuery / Cloud Run verification | **Not done** |

### How the interactive parts work (for reviewers)
* Page loads return instantly: each widget is a placeholder with `data-render=".../widgets/<id>/render"`. `dash.js` fetches that URL (same checks as the page: dashboard access, then the user's own data access) when it is near the viewport and puts the returned HTML in place.
* `<noscript>` redirects to `?lazy=0`, the fully server-rendered page, so a browser without JavaScript still works.
* The layout editor changes only **order and width**. Save posts `order` and `spans`; the server verifies the widget ids are exactly the existing ones and the widths are allowed, then writes a new draft version.
* Click-to-filter sets `f_<key>` in the URL (so a filtered view can be bookmarked or shared) and re-fetches the widgets. The server only honours keys the creator enabled, only for datasets that have the field, and only as query parameters.

## 4. Deployment
1. Run `sql/ddl_gui.sql` (adds `prism_gui_dashboard`, `prism_gui_dashboard_share`).
2. **IAM requested, not changed by me:** GUI service account needs **BigQuery Data Editor** on the two new tables and **Data Viewer** on `file_registry`, `prism_runs`, `recon_result`, `recon_alarm`; the existing Job User and KMS grants already cover query jobs.
3. Rebuild and deploy the `prism-gui` image.
4. **Upgrade existing roles** (also needed for the new **Export data** module): `python gui/manage.py seed-roles` adds the new modules to the built-in roles (admin gets everything; viewer/operator get dashboard view + data access; two new roles `dashboard-creator` and `dashboard-publisher` are created) and sets them to **No access** on custom roles. Existing levels are never lowered. Until you run it, existing roles have **no** dashboard access (fail-closed).
5. Give creators the `dashboard-creator` role (or an override) in **Users**; publishers `dashboard-publisher`.

### Risks to review
* Cost: caps are per widget query (5 GiB billed). A dashboard of 12 widgets can scan up to 12 x 5 GiB in the worst case; lower `MAX_BYTES_BILLED` / `MAX_WIDGETS` in `dash_exec.py` / `dash_spec.py` if needed. The control tables are small, so real scans should be tiny.
* One service account reads the data (see 1): application-level data access is the control.
* Page loads run every widget synchronously (max 4 in parallel). Slow BigQuery = slow page until lazy loading arrives.
* Cached user/role lookups (20 s) mean a revocation can take up to 20 s to reach another instance.

### Tests
`python tests/test_gui_dashboards.py` (server), `python tests/test_gui_phase2.py` (lazy fragments, filters, layout, export, CSP), `python tests/test_gui_browser.py` (real Chromium; needs `pip install playwright` and its browser, skips cleanly if missing). None of them touches real BigQuery.

## 5. Try it without Google Cloud
`PRISM_GUI_DEV=1 python gui/app.py` - demo users `viewer1`, `creator1`, `publisher1`, `admin` (shared printed password), sample data, clearly marked as demo on every dashboard page.

## 6. Suggested next steps
1. Verify against real BigQuery with a test service account (and tell me the first real error).
2. Drill-down to detail pages (server-side paging and sorting), then authorization-scoped caching.
3. Decide on SSO/IAP + group mapping, and whether per-user BigQuery RLS is required.
4. Provide schemas for the TAP / ASN / AMA / CDR / profile-integrity datasets so catalog entries and templates can be added honestly.
