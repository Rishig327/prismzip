# Transformation code in the table

The Python that turns each decoded record into detail-table rows (for PGW: formerly `sources/pgw/transformation_PGW.py`) is no longer a file in the
image. It is stored in the BigQuery table `VPDB_ADM.prism_transform_code`, edited and approved in the GUI (**Sources -> PGW -> Transformation code**),
and every Dataflow job runs one exact approved version of it.

## How it fits together
```
GUI (view / edit draft / validate / approve)  --writes-->  prism_transform_code  <--reads--  orchestrator (current approved version)
                                                                  ^                                   |  launches the job with
                                                                  |  reads that exact version         v  --transform_version=N --transform_sha=...
                                                         Dataflow workers (transform_loader.py) <------+
```
1. The orchestrator, once per run and **before any file is claimed**, reads the current approved version and its SHA-256. If a source has no approved version it
   stops with a clear message and starts nothing. The version and hash are recorded on the run (`prism_runs.transform_version`, `transform_sha`).
2. They are passed to the job (`--transform_version`, `--transform_sha`; declared in `sources/pgw/metadata.json`).
3. Each worker loads that version from the table, checks the hash, compiles it and calls `setup()`. Any failure stops the worker **before it processes a
   record**. Approving a newer version while a job runs does not affect that job.

## The table (append-only, like the other PRISM tables)
| state | meaning |
|---|---|
| `DRAFT` | every save and every validation of the (single) open draft. The newest row of a source being a DRAFT means "a draft is open" |
| `APPROVED` | one row per version (1, 2, 3 ...). The highest version is what the next runs use |
| `DISCARDED` | a draft that was thrown away |
There is **one draft per source**. Editing again edits that same draft (nobody gets a second copy) until it is approved (-> next version number) or discarded.
Restoring an old version copies it into a new draft; approving it creates a NEW version number, so history stays linear.

## Who can do what (separate permissions, off by default)
| Permission (Roles screen) | Allows |
|---|---|
| **Transformation code = View** | read the code, history, diffs, download |
| **Transformation code = Edit** | start / edit the draft, run validation, restore an old version, discard |
| **Approve code = Edit** | approve a validated draft, discard, (with View) see the approval panel |
Built-in roles added by `seed-roles`: `code-editor` (cannot approve) and `code-approver` (cannot edit). `admin` has everything.
**Four-eyes rule:** the person who made the last change to the draft cannot approve it (`REQUIRE_DIFFERENT_APPROVER` in `gui/code_routes.py`; set `False` for a
one-person team).

## Validation (the button before approval)
"Save & validate" saves the draft, then checks it. **Errors block approval; warnings and notes do not.** Any later edit clears the validation.
Static checks (the code is not run): it parses; defines `class transform_record` with `process(self, row)` that yields; forbidden imports (`os`, `sys`, `subprocess`,
`socket`, `pathlib`, ...) and calls (`eval`, `exec`, `open`, ...); names that are used but never defined (typos, with "did you mean"); output columns that are not in
the detail table schema (warning: they are ignored); `lk_...` lookup names that are not defined and enabled in the lookup table; risky patterns (bare `except`,
`print`, `global`, mutable defaults, endless `while True`).
Test run: if the static checks pass, the code runs on a few sample records in a **separate process** (time, CPU and memory limited; `apache_beam` and the lookup
manager replaced by stand-ins): an empty record, records built from the fields the code reads, and any JSON records you paste. A crash on an invented record is a
warning (PRISM would reject that record and carry on); a missing name or import is an error.
At approval the static checks run again, so a lookup disabled since the validation still blocks it.
**Validation catches mistakes. It cannot prove the business logic is right: that is what the second person's approval is for.**
The real PGW code passes with 0 errors; it shows 2 warnings (it sets `filename` and `PORTED`, which are not detail-table columns, so they are ignored).

## Rolling it out (order matters)
1. Run `sql/ddl_transform.sql` (new table) and the `ALTER TABLE ... prism_runs` migration at the bottom of `sql/ddl.sql`.
2. Permissions: GUI service account **Data Editor** on `prism_transform_code`; orchestrator service account and the **Dataflow worker service account Data Viewer** on it.
   Keep Data Editor to the GUI service account only: whoever can write `APPROVED` rows decides what code runs on the workers.
3. Rebuild the images (`build/cloudbuild.yaml`: common, pgw, orchestrator, gui) and **rebuild the Flex Template** (`metadata.json` has two new parameters).
4. Load version 1 once: `python gui/manage.py seed-transform PGW sources/pgw/seed/transformation_PGW.v1.py`
   (until you do, the orchestrator refuses to start PGW runs: "no approved transformation code").
5. `python gui/manage.py seed-roles`, then give `code-editor` / `code-approver` to the right people.
6. After a successful run: `SELECT run_id, transform_version FROM prism_runs ORDER BY started_at DESC LIMIT 5` shows the version it used.
   Then delete `sources/pgw/seed/` from the repository: the table is the source of truth.

## Operating notes
* **Rollback:** History -> *Restore as draft* on the version you want -> validate -> approve (becomes the next number). Nothing is ever overwritten.
* **Which code ran for a file?** `prism_runs.transform_version` (and `transform_sha`) of the run that processed it.
* **Failure modes (all fail before processing a record):** no approved version; table unreadable by the workers; hash does not match; code does not compile.
* **Image rebuilds** are no longer needed to change transformation logic. They are still needed for the decoder, schema, plugin and common code.
* The repository no longer contains the live transformation. For code review outside the GUI use *Download*, or the diff between versions.

## What this does not do / not verified
* Anyone who can write approved rows can run Python on the workers with the worker service account's access. The controls are the separate permissions,
  validation, the second-person approval, the hash check and the audit log; the network boundary and table permissions do the rest.
* Not run against real BigQuery, real Dataflow or real PGW files. `tests/test_pgw_local.py` (needs Apache Beam and the decoder) was updated to use the loader but not run.
* Validation is static plus a sample run; it does not compare results with a reference.
