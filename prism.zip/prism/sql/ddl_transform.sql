-- =====================================================================
-- Transformation code of each source, stored in BigQuery (append-only). See common/transform_store.py for the rules.
--   DRAFT rows     : every save / validation of the (single) open draft. The newest row of a source being a DRAFT = "a draft is open".
--   APPROVED rows  : one per version (1, 2, 3 ...). The highest version is the one the next runs use.
--   DISCARDED rows : a draft that was thrown away.
-- Access:  GUI service account            -> BigQuery Data Editor on this table
--          orchestrator service account   -> Data Viewer (reads the current version)
--          Dataflow worker service account-> Data Viewer (reads the exact version of its job)
-- Whoever can write APPROVED rows decides what code runs on the workers: keep Data Editor on this table to the GUI service account only.
-- Load version 1 once:  python gui/manage.py seed-transform PGW sources/pgw/seed/transformation_PGW.v1.py
-- =====================================================================
CREATE TABLE IF NOT EXISTS `vf-uk-raid-pre-prod.VPDB_ADM.prism_transform_code` (
  source_type STRING NOT NULL, changed_at TIMESTAMP NOT NULL, changed_by STRING, note STRING,
  state STRING NOT NULL, kind STRING NOT NULL, version INT64 NOT NULL,
  code STRING, code_sha256 STRING,
  edited_by STRING,                          -- who made the last change to the code text (the approver must be someone else)
  validation_ok BOOL, validation_at TIMESTAMP, validation_report STRING,
  approved_by STRING, approved_at TIMESTAMP
)
CLUSTER BY source_type
OPTIONS (kms_key_name = 'projects/vf-uk-raid-prd-kms/locations/europe-west2/keyRings/vf-uk-raid-pre-prod-kms-ring/cryptoKeys/vf-uk-raid-pre-prod-kms-key');

-- What the next run will use, and who approved it:
-- SELECT source_type, version, approved_by, approved_at, LEFT(code_sha256, 12) AS sha FROM `vf-uk-raid-pre-prod.VPDB_ADM.prism_transform_code`
-- WHERE state = 'APPROVED' QUALIFY ROW_NUMBER() OVER (PARTITION BY source_type ORDER BY version DESC) = 1;
