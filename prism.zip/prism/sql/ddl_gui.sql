-- =====================================================================
-- PRISM GUI tables (VPDB_ADM). All append-only.
--   prism_gui_user  : a change inserts a NEW row, the newest row per username wins, older rows are the history
--                     (also what the "last 5 passwords cannot be reused" rule reads). password_hash is a scrypt hash, never the password.
--   prism_gui_role  : same pattern; permissions is JSON  {"lookups": 2, "sources": 1, ...}  (0 none, 1 view, 2 edit)
--   prism_gui_audit : one row per event (LOGIN_OK, LOGIN_FAIL, PASSWORD_CHANGED, USER_CHANGED ...). The account lock-out is computed from it.
-- Give the GUI service account dataEditor on THESE THREE tables only (plus the three config tables it edits), nobody else.
-- Create the first administrator with:  python gui/manage.py seed-roles   then   python gui/manage.py create-admin NAME
-- =====================================================================
CREATE TABLE IF NOT EXISTS `vf-uk-raid-pre-prod.VPDB_ADM.prism_gui_user` (
  username STRING NOT NULL, changed_at TIMESTAMP NOT NULL, changed_by STRING, note STRING,
  display_name STRING, email STRING, role STRING NOT NULL, overrides STRING,
  enabled BOOL NOT NULL, password_hash STRING NOT NULL, must_change_password BOOL NOT NULL, password_changed_at TIMESTAMP
)
CLUSTER BY username
OPTIONS (kms_key_name = 'projects/vf-uk-raid-prd-kms/locations/europe-west2/keyRings/vf-uk-raid-pre-prod-kms-ring/cryptoKeys/vf-uk-raid-pre-prod-kms-key');

CREATE TABLE IF NOT EXISTS `vf-uk-raid-pre-prod.VPDB_ADM.prism_gui_role` (
  role_name STRING NOT NULL, changed_at TIMESTAMP NOT NULL, changed_by STRING, note STRING,
  description STRING, permissions STRING NOT NULL, enabled BOOL NOT NULL
)
CLUSTER BY role_name
OPTIONS (kms_key_name = 'projects/vf-uk-raid-prd-kms/locations/europe-west2/keyRings/vf-uk-raid-pre-prod-kms-ring/cryptoKeys/vf-uk-raid-pre-prod-kms-key');

CREATE TABLE IF NOT EXISTS `vf-uk-raid-pre-prod.VPDB_ADM.prism_gui_audit` (
  event_time TIMESTAMP NOT NULL, username STRING, actor STRING, event STRING NOT NULL, detail STRING, ip STRING
)
PARTITION BY DATE(event_time)
CLUSTER BY username, event
OPTIONS (kms_key_name = 'projects/vf-uk-raid-prd-kms/locations/europe-west2/keyRings/vf-uk-raid-pre-prod-kms-ring/cryptoKeys/vf-uk-raid-pre-prod-kms-key');

-- =====================================================================
-- Dashboard Studio (append-only, same pattern as above)
--   prism_gui_dashboard        every save / publish / unpublish / archive inserts a row. Newest row per dashboard_id is the current state
--                              (current draft = its definition; published_version = the version viewers see, NULL = not published).
--                              version = content version (+1 on every content change); kind = created | save | restore | duplicate | publish | unpublish | archive.
--                              definition = validated JSON (widgets, layout, filters): never SQL, never secrets.
--   prism_gui_dashboard_share  grants a dashboard to a user or a role (level is always view). active = FALSE revokes.
-- Give the GUI service account dataEditor on these two tables; dataViewer on the PRISM control tables the catalog reads
-- (file_registry, prism_runs, recon_result, recon_alarm) - see docs/DASHBOARD_STUDIO.md. A share never grants data access.
-- =====================================================================
CREATE TABLE IF NOT EXISTS `vf-uk-raid-pre-prod.VPDB_ADM.prism_gui_dashboard` (
  dashboard_id STRING NOT NULL, version INT64 NOT NULL, changed_at TIMESTAMP NOT NULL, changed_by STRING, note STRING, kind STRING NOT NULL,
  name STRING NOT NULL, description STRING, owner STRING NOT NULL, status STRING NOT NULL,
  published_version INT64, published_at TIMESTAMP, definition STRING NOT NULL
)
CLUSTER BY dashboard_id
OPTIONS (kms_key_name = 'projects/vf-uk-raid-prd-kms/locations/europe-west2/keyRings/vf-uk-raid-pre-prod-kms-ring/cryptoKeys/vf-uk-raid-pre-prod-kms-key');

CREATE TABLE IF NOT EXISTS `vf-uk-raid-pre-prod.VPDB_ADM.prism_gui_dashboard_share` (
  dashboard_id STRING NOT NULL, principal_type STRING NOT NULL, principal STRING NOT NULL, level STRING NOT NULL, active BOOL NOT NULL,
  changed_at TIMESTAMP NOT NULL, changed_by STRING
)
CLUSTER BY dashboard_id
OPTIONS (kms_key_name = 'projects/vf-uk-raid-prd-kms/locations/europe-west2/keyRings/vf-uk-raid-pre-prod-kms-ring/cryptoKeys/vf-uk-raid-pre-prod-kms-key');
