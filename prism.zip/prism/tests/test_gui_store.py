"""BigQueryStore plumbing (fake BigQuery) and manage.py commands (in-memory store).   python tests/test_gui_store.py"""
import io, contextlib, sys, types
import _paths  # noqa: F401

class P:                                                  # parameter / config stand-ins keep what they were given
    def __init__(self, *a, **k): self.a, self.k = a, k
bq = types.ModuleType("google.cloud.bigquery")
for n in ("ScalarQueryParameter", "ArrayQueryParameter", "EncryptionConfiguration", "QueryJobConfig", "Client"):
    setattr(bq, n, P)
g, gc = types.ModuleType("google"), types.ModuleType("google.cloud"); gc.bigquery = bq; g.cloud = gc
sys.modules.update({"google": g, "google.cloud": gc, "google.cloud.bigquery": bq})

import re                                                 # noqa: E402
from datetime import datetime, timezone                   # noqa: E402
import manage, rbac, security as sec                      # noqa: E402
from store import BigQueryStore, MemoryStore              # noqa: E402

class Row(dict):
    def __getattr__(self, k): return self[k]

class FakeBq:
    def __init__(self): self.sql, self.params, self.result = [], [], []
    def run(self, sql, params=None): self.sql.append(sql); self.params.append({p.a[0]: p.a[2] for p in (params or [])})
    def rows(self, sql, params=None): self.sql.append(sql); self.params.append({p.a[0]: p.a[2] for p in (params or [])}); return self.result

fb = FakeBq(); st = BigQueryStore(fb, "proj", "VPDB_ADM")
now = datetime.now(timezone.utc)
st.put_user("alice", {"display_name": "A", "email": None, "role": "viewer", "overrides": "{}", "enabled": True,
                      "password_hash": "h", "must_change_password": True, "password_changed_at": now}, by="admin", note="n")
sql, p = fb.sql[-1], fb.params[-1]
cols = re.search(r"\(([^)]*)\) VALUES \((.*)\)$", sql); names = [c.strip() for c in cols.group(1).split(",")]; vals = [v.strip() for v in cols.group(2).split(",")]
assert names[-1] == "changed_at" and vals[-1] == "CURRENT_TIMESTAMP()" and len(names) == len(vals), sql
assert [v[1:] for v in vals[:-1]] == names[:-1] and set(p) == set(names[:-1]), "every column has its parameter"
assert "`proj.VPDB_ADM.prism_gui_user`" in sql and p["password_hash"] == "h" and p["username"] == "alice"
st.put_role("r1", "d", {"lookups": 2}, True, "admin"); assert '"lookups": 2' in fb.params[-1]["permissions"] and "prism_gui_role" in fb.sql[-1]
st.audit("LOGIN_FAIL", username="alice", actor=None, detail="x" * 900, ip="1.2.3.4"); assert len(fb.params[-1]["d"]) == 500 and "prism_gui_audit" in fb.sql[-1]
fb.result = [Row(event="LOGIN_FAIL", event_time=now)]
assert st.lock_events("alice", sec.LOCK_RELEVANT) == [("LOGIN_FAIL", now)] and "UNNEST(@ev)" in fb.sql[-1] and fb.params[-1]["u"] == "alice"
assert "QUALIFY ROW_NUMBER() OVER (ORDER BY changed_at DESC) = 1" in (st.get_user("alice") or fb.sql[-1]) or "QUALIFY" in fb.sql[-1]
fb.result = []; assert st.get_user("nobody") is None
st.list_audit(50, "alice", "LOGIN_OK"); assert "LIMIT 50" in fb.sql[-1] and "(username = @u OR actor = @u)" in fb.sql[-1]
print("BigQueryStore SQL + parameters: ok")

# manage.py with an in-memory store
mem = MemoryStore()
def run(*a):
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        manage.main(list(a), store=mem)
    return out.getvalue()
try: run("create-admin", "boss"); raise SystemExit("expected: seed-roles first")
except SystemExit as e: assert "seed-roles" in str(e)
assert "admin, operator, viewer" in run("seed-roles") and "none" in run("seed-roles")
out = run("create-admin", "Boss", "--name", "The Boss"); temp = re.search(r"\n    (\S+)\n", out).group(1)
u = mem.get_user("boss"); assert u["role"] == "admin" and u["must_change_password"] and sec.verify_password(u["password_hash"], temp) and not sec.policy_problems(temp, "boss")
assert temp not in str(mem.events), "temporary password is never written to the audit log"
try: run("create-admin", "boss"); raise SystemExit("expected: exists")
except SystemExit as e: assert "already exists" in str(e)
out = run("reset-password", "boss"); t2 = re.search(r"\n    (\S+)\n", out).group(1); assert t2 != temp and sec.verify_password(mem.get_user("boss")["password_hash"], t2)
run("unlock", "boss"); assert mem.events[-1]["event"] == "UNLOCK" and "boss" in run("list-users")
assert rbac.allowed(rbac.effective(rbac.loads(mem.get_role("admin")["permissions"]), {}), "users", rbac.EDIT)
print("manage.py: ok")
print("ALL GUI STORE CHECKS PASSED")
