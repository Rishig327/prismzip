"""
Dashboard Studio in a REAL browser (headless Chromium via Playwright) against the demo app (in-memory store, sample data).
Covers: lazy loading on scroll, tooltips, legend toggle, click-to-filter + chips, refresh, drag to move, drag to resize, keyboard resize,
undo / redo, save layout (persisted), unsaved-change warning, no-JavaScript fallback, and NO console / page / CSP errors.
Skips (exit 0, says so) when Playwright or Chromium is not installed.      python tests/test_gui_browser.py
"""
import json, socket, sys, threading
from _gui_helpers import fresh, PW, widgets_of
import demo

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("SKIPPED: playwright is not installed"); sys.exit(0)

st, app, runner = fresh()
bar = lambda t, **k: {"type": "bar", "title": t, "dataset": "file_status", "metrics": ["files"], **k}
D_LAZY = demo.new_dashboard(st, "pub", "Lazy", template="pipeline_ops", publish=True, share=[("role", "viewer")])
D_CF = demo.new_dashboard(st, "pub", "CrossFilter", publish=True, share=[("role", "viewer")], definition={"filters": ["source"], "widgets": [
    bar("By source", dims=["source_type"], span=6), {"type": "kpi", "title": "Files", "dataset": "file_status", "metrics": ["files"], "span": 3},
    {"type": "donut", "title": "By status", "dataset": "file_status", "metrics": ["files"], "dims": ["status"], "span": 3}]})
D_ED = demo.new_dashboard(st, "pub", "Editor", template="pipeline_ops")
import pgw_schema
COL = pgw_schema.DETAIL_SCHEMA[0][0]
CODE = f'''from LookupsManager import LookupManager


class transform_record:
    def setup(self):
        LookupManager.load_selected(["lk_VFUK_R_UC_APN_LIST"])

    def process(self, row):
        out_row = {{}}
        out_row["{COL}"] = (row.get("a") or "").upper()
        yield dict(out_row)
'''
demo.new_user(st, "coder", PW, "code-editor"); st.transform.seed("PGW", CODE, "seed", "initial import")

from werkzeug.serving import make_server
s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
srv = make_server("127.0.0.1", port, app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
B = f"http://127.0.0.1:{port}"
problems, renders = [], []

def login(br, user, js=True):
    ctx = br.new_context(viewport={"width": 1280, "height": 460}, java_script_enabled=js); pg = ctx.new_page()
    pg.on("console", lambda m: problems.append(("console", m.text)) if m.type == "error" else None)
    pg.on("pageerror", lambda e: problems.append(("pageerror", str(e))))
    pg.on("request", lambda r: renders.append(r.url) if "/render" in r.url else None)
    pg.goto(B + "/login"); pg.fill("#username", user); pg.fill("#password", PW); pg.click("button.btn"); pg.wait_for_load_state()
    return pg

def until(pg, cond, timeout=15):
    """Polls with Playwright locators / python properties. (page.wait_for_function evals a string in the page, which our CSP - correctly - forbids; the CSP is NOT bypassed here.)"""
    for _ in range(int(timeout * 10)):
        if cond():
            return
        pg.wait_for_timeout(100)
    raise AssertionError("timed out waiting for the page")
def loaded(pg, n): until(pg, lambda: pg.locator(".wbody[data-state=loaded]").count() >= n)
def order(pg): return pg.eval_on_selector_all(".wcard[data-wid]", "els => els.map(e => e.dataset.wid)")
def spans(pg): return pg.eval_on_selector_all(".wcard[data-wid]", "els => els.map(e => parseInt(e.dataset.span))")

with sync_playwright() as p:
    try:
        br = p.chromium.launch()
    except Exception as e:
        print("SKIPPED: Chromium is not available:", str(e)[:120]); sys.exit(0)

    # ---------------------------------------------------------------- 1. viewer: lazy loading
    v = login(br, "view"); renders.clear()
    v.goto(f"{B}/dashboards/{D_LAZY}"); loaded(v, 1); v.wait_for_timeout(600)
    first = len(renders)
    assert 0 < first < 7, f"only widgets near the viewport load first (got {first} of 7)"
    v.evaluate("window.scrollTo(0, document.body.scrollHeight)"); loaded(v, 7)
    assert len(renders) == 7 and len(set(renders)) == 7, "every widget fetched exactly once"
    assert v.locator(".skeleton").count() == 0 and v.locator("svg.chart").count() >= 2 and v.locator(".kpi").count() == 4 and v.locator("table.dtable").count() == 1
    print(f"1 lazy loading: {first} of 7 widgets loaded before scrolling, all 7 after, each once: ok")

    # ---------------------------------------------------------------- 2. tooltip + legend
    v.evaluate("window.scrollTo(0, 0)")
    v.hover("svg.chart .pt"); v.wait_for_selector("#tip:not([hidden])"); assert v.inner_text("#tip").strip() != ""
    assert v.locator("svg title").count() == 0, "native <title> removed so the tooltip does not show twice"
    items = v.locator(".legend li"); assert items.count() >= 2
    name = items.first.get_attribute("data-s"); marks = v.locator(f'svg [data-s="{name}"]').first
    items.first.click(); assert "off" in items.first.get_attribute("class") and marks.evaluate("e => e.style.display") == "none"
    items.first.click(); assert marks.evaluate("e => e.style.display") == ""
    print("2 tooltip on hover, legend click hides / shows a series: ok")

    # ---------------------------------------------------------------- 3. click-to-filter
    renders.clear(); v.goto(f"{B}/dashboards/{D_CF}"); loaded(v, 3); before = len(renders)
    v.locator('rect[data-fk="source"]').first.click(); until(v, lambda: "f_source=PGW" in v.url)
    assert v.locator(".chip").inner_text().startswith("Source: PGW") and v.input_value('input[name="f_source"]') == "PGW"
    until(v, lambda: v.locator(".wbody[data-state=loaded]").count() == 3); v.wait_for_timeout(400)
    assert len(renders) >= before + 3 and all("f_source=PGW" in u for u in renders[before:before + 3]), "all widgets re-fetched with the filter"
    sql = [q for q in runner.queries if "IN UNNEST(@f0)" in q.sql]; assert sql and ["PGW"] in [dict((n, x) for n, _, x in q.params).get("f0") for q in sql]
    url = v.url; v.locator('path[data-fk="file_status.status"]').first.click(); v.wait_for_timeout(300)
    assert v.url == url, "a mark whose field the creator did not enable as a filter does nothing"
    n = len(renders); v.click(".chip button"); until(v, lambda: "f_source" not in v.url); v.wait_for_timeout(500)
    assert v.locator(".chip").count() == 0 and len(renders) >= n + 3
    n = len(renders); v.click("#refresh-now"); v.wait_for_timeout(800); assert len(renders) >= n + 3, "Refresh re-runs the visible widgets"
    print("3 click-to-filter, chips, only enabled fields filter, refresh: ok")

    # ---------------------------------------------------------------- 4. editor: drag, resize, undo / redo, save
    e = login(br, "pub"); e.set_viewport_size({"width": 1700, "height": 1500})
    e.goto(f"{B}/dashboards/{D_ED}/edit"); loaded(e, 7)
    assert e.is_visible("#layoutbar") and e.is_disabled("#undo") and e.is_disabled("#savelayout") and e.is_hidden("#dirty")
    o0, s0 = order(e), spans(e)
    e.locator(".wcard").first.locator(".dh").drag_to(e.locator(".wcard").nth(5), target_position={"x": 20, "y": 20})
    o1 = order(e); assert o1 != o0 and sorted(o1) == sorted(o0) and e.is_visible("#dirty") and e.is_enabled("#savelayout") and e.is_enabled("#undo"), "dragged"
    e.click("#undo"); assert order(e) == o0 and e.is_hidden("#dirty") and e.is_disabled("#undo") and e.is_enabled("#redo"), "undo"
    e.click("#redo"); assert order(e) == o1, "redo"
    e.keyboard.press("Control+z"); assert order(e) == o0; e.keyboard.press("Control+y"); assert order(e) == o1, "keyboard undo / redo"
    card = e.locator('.wcard[data-wid]').nth(next(i for i, s in enumerate(spans(e)) if s == 4)); sp_before = int(card.get_attribute("data-span"))
    card.locator(".rz").scroll_into_view_if_needed(); hb = card.locator(".rz").bounding_box(); e.mouse.move(hb["x"] + hb["width"] / 2, hb["y"] + hb["height"] / 2); e.mouse.down(); e.mouse.move(hb["x"] + 330, hb["y"] + 5, steps=8); e.mouse.up()
    sp_after = int(card.get_attribute("data-span")); assert sp_after > sp_before and "span%d" % sp_after in card.get_attribute("class"), "resized by dragging the edge"
    e.keyboard.press("Control+z"); assert int(card.get_attribute("data-span")) == sp_before, "undo resize"
    card.locator(".rz").focus(); e.keyboard.press("ArrowRight"); assert int(card.get_attribute("data-span")) > sp_before, "keyboard resize"
    assert e.evaluate("(() => { const x = new Event('beforeunload', {cancelable: true}); window.dispatchEvent(x); return x.defaultPrevented; })()"), "unsaved changes warn before leaving"
    want_order, want_spans = order(e), spans(e); v0 = st.dash_get(D_ED)["version"]
    e.click("#savelayout"); e.wait_for_load_state(); e.wait_for_selector(".flash.ok")
    got = widgets_of(st, D_ED); assert [w["id"] for w in got] == want_order and [w["span"] for w in got] == want_spans and st.dash_get(D_ED)["version"] == v0 + 1, "saved to the server"
    loaded(e, 7); assert order(e) == want_order and spans(e) == want_spans and e.is_hidden("#dirty"), "reopened exactly as saved"
    assert not e.evaluate("(() => { const x = new Event('beforeunload', {cancelable: true}); window.dispatchEvent(x); return x.defaultPrevented; })()"), "no warning once saved"
    print("4 drag to move, drag + keyboard resize, undo / redo (buttons and keys), save, reopen, unsaved warning: ok")

    # ---------------------------------------------------------------- 5. no JavaScript: the page still shows everything
    n = login(br, "view", js=False); n.goto(f"{B}/dashboards/{D_LAZY}"); until(n, lambda: "lazy=0" in n.url)
    assert n.locator(".kpi").count() == 4 and n.locator("svg.chart").count() >= 2 and n.locator(".skeleton").count() == 0, "server-rendered fallback"
    print("5 JavaScript disabled: falls back to the server-rendered dashboard: ok")

    # ---------------------------------------------------------------- 6. transformation code editor
    c = login(br, "coder"); c.set_viewport_size({"width": 1400, "height": 1000})
    c.goto(f"{B}/sources/PGW/code/edit"); c.click("text=Start a draft from v1"); c.wait_for_load_state(); until(c, lambda: c.locator("#codearea").count() == 1)
    ta, n = c.locator("#codearea"), len(CODE.splitlines())
    assert c.inner_text("#gutter").split() == [str(i) for i in range(1, n + 1)] and c.is_hidden("#unsaved"), "line numbers match the code"
    ta.click(); c.keyboard.press("Control+End"); c.keyboard.type(f'    out_row["ZZZ"] = 1\n')
    assert c.is_visible("#unsaved") and len(c.inner_text("#gutter").split()) >= n and "Line" in c.inner_text("#cstatus"), "typing updates the gutter, the status line and the unsaved badge"
    ta.press("Control+a"); ta.press("Tab"); assert ta.input_value().startswith("    from LookupsManager"), "Tab with a selection indents every line"
    ta.press("Shift+Tab"); assert ta.input_value().startswith("from LookupsManager"), "Shift+Tab outdents"
    c.keyboard.press("Control+End"); ta.press("Tab"); assert ta.input_value().endswith("    "), "Tab inserts four spaces, it does not leave the box"
    assert c.evaluate("(() => { const x = new Event('beforeunload', {cancelable: true}); window.dispatchEvent(x); return x.defaultPrevented; })()"), "unsaved text warns before leaving"
    c.keyboard.press("Control+s"); c.wait_for_load_state(); until(c, lambda: c.locator(".flash").count() >= 1)
    assert 'out_row["ZZZ"] = 1' in st.transform.draft("PGW")["code"] and st.transform.draft("PGW")["edited_by"] == "coder", "Ctrl+S saved the draft"
    assert c.is_hidden("#unsaved") and not c.evaluate("(() => { const x = new Event('beforeunload', {cancelable: true}); window.dispatchEvent(x); return x.defaultPrevented; })()"), "nothing unsaved after saving"
    c.click("button:has-text('Save & validate')"); c.wait_for_load_state(); until(c, lambda: c.locator("table.findings").count() == 1)
    link = c.locator("table.findings a[data-line]").first; line_no = int(link.get_attribute("data-line")); link.click()
    picked = ta.evaluate("e => e.value.slice(e.selectionStart, e.selectionEnd)")
    assert "ZZZ" in picked and ta.evaluate("e => e.value.slice(0, e.selectionStart).split('\\n').length") == line_no, "clicking a finding selects that line in the editor"
    print("6 code editor: line numbers, status line, Tab / Shift+Tab, unsaved warning, Ctrl+S, jump to the line of a finding: ok")
    br.close()
srv.shutdown()
assert not problems, f"browser console / page / CSP errors: {problems[:5]}"
print("7 no console errors, page errors or CSP violations during all of the above: ok")
print("ALL BROWSER CHECKS PASSED")
