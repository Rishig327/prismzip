"""
Dashboard Studio (Milestone 1): catalog grounded in the real DDL, widget validation, safe SQL, charts, persistence + versions,
creator / publisher / viewer permissions, sharing, separate dashboard-vs-data access, IDOR, cost controls, audit.
In-memory store + SampleRunner + a fake BigQuery client: this proves the CODE, it is not a test against real BigQuery.
    python tests/test_gui_dashboards.py
"""
import json, logging, os, re, sys, threading, types
import _paths  # noqa: F401  (adds common/, orchestrator/, gui/, sources/* to sys.path)

class P:
    def __init__(self, *a, **k): self.a, self.k = a, k
class QJC:
    def __init__(self, **k): self.__dict__.update(k)
bq = types.ModuleType("google.cloud.bigquery")
bq.ScalarQueryParameter = bq.ArrayQueryParameter = lambda *a: tuple(a)
bq.EncryptionConfiguration = bq.Client = P; bq.QueryJobConfig = QJC
g, gc = types.ModuleType("google"), types.ModuleType("google.cloud"); gc.bigquery = bq; g.cloud = gc
sys.modules.update({"google": g, "google.cloud": gc, "google.cloud.bigquery": bq})

from datetime import datetime, timedelta, timezone   # noqa: E402
from decimal import Decimal                          # noqa: E402
import charts, dash_access as acc, dash_catalog as cat, dash_exec, dash_spec as sp, demo, manage, rbac   # noqa: E402
from app import create_app                           # noqa: E402
from store import MemoryStore                        # noqa: E402

ROOT = os.path.join(os.path.dirname(__file__), "..")
PW = "Start-Pass-Word-42!"
NOW = datetime(2026, 10, 30, 12, 0, tzinfo=timezone.utc)

# ============================================================ 1. the catalog only contains what the real DDL contains
def ddl_columns(path):
    tables, cur = {}, None
    for line in open(os.path.join(ROOT, path), encoding="utf-8"):
        m = re.search(r"CREATE TABLE IF NOT EXISTS `[^`]*\.(\w+)`", line)
        if m:
            cur = m.group(1); tables[cur] = set(); line = line.split("(", 1)[1] if "(" in line else ""
        elif cur and line.strip().startswith(")"):
            cur = None; continue
        if cur:
            tables[cur] |= set(re.findall(r"(?:^|,)\s*(\w+)\s+(?:STRING|INT64|FLOAT64|BOOL|TIMESTAMP|DATE|NUMERIC|BYTES|ARRAY|STRUCT|JSON)", line))
    return tables

ddl = {**ddl_columns("sql/ddl.sql"), **ddl_columns("sql/ddl_recon.sql")}
FUNCS = {"count", "sum", "avg", "min", "max", "safe_divide", "nullif", "countif", "timestamp_diff", "minute", "pow"}
for k, d in cat.DATASETS.items():
    cols = ddl[d["table"]]
    assert d["time_field"] in cols, (k, "time_field")
    assert set(d["fields"]) <= cols and set(d["preview"]) <= cols, (k, "fields/preview not in DDL", set(d["fields"]) - cols, set(d["preview"]) - cols)
    for mk, m in d["metrics"].items():
        words = {w.lower() for w in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", re.sub(r"'[^']*'", "", m["expr"]))}
        assert words <= cols | FUNCS, (k, mk, "expression uses unknown names", words - cols - FUNCS)
        assert m["fmt"] in ("int", "pct", "dec") and m["label"] and m["unit"] and m["about"], (k, mk)
    assert all(sp.IDENT.match(c) for c in list(d["fields"]) + d["preview"] + [d["time_field"]]), k
    assert d["module"] in rbac.MODULES and rbac.MODULES[d["module"]]["max"] == rbac.VIEW
print("1 catalog: every table, column and metric expression exists in the DDL: ok")

# ============================================================ 2. widget validation (backend, not the UI)
def ok(**w):
    c, e = sp.validate_widget({"dataset": "file_status", "title": "T", **w}); assert not e, e; return c
def bad(expect, **w):
    c, e = sp.validate_widget({"dataset": "file_status", "title": "T", **w}); assert any(expect in x for x in e), (expect, e)
ok(type="kpi", metrics=["files"]); ok(type="line", metrics=["files"], time_grain="day", dims=["status"]); ok(type="bar", metrics=["files"], dims=["status"])
ok(type="table", metrics=["files", "records_read"], dims=["source_type", "status"], time_grain="week", limit=500)
bad("exactly one metric", type="kpi", metrics=["files", "records_read"]); bad("cannot be grouped", type="kpi", metrics=["files"], dims=["status"])
bad("needs a time granularity", type="line", metrics=["files"]); bad("exactly one metric", type="line", metrics=["files", "records_read"], time_grain="day", dims=["status"])
bad("time granularity or a field", type="bar", metrics=["files"]); bad("not available", type="bar", metrics=["nope"], dims=["status"]); bad("not available", type="bar", metrics=["files"], dims=["password"])
bad("Choose a widget type", type="pie", metrics=["files"]); bad("Row limit", type="table", metrics=["files"], limit=501); bad("Row limit", type="table", metrics=["files"], limit="x")
bad("4 metrics", type="table", metrics=["files", "records_read", "records_loaded", "records_rejected", "reject_pct"])
bad("Filter field", type="kpi", metrics=["files"], filters=[{"field": "file_id", "op": "eq", "value": "x"}]); bad("choose is", type="kpi", metrics=["files"], filters=[{"field": "status", "op": "like", "value": "x"}])
bad("needs a value", type="kpi", metrics=["files"], filters=[{"field": "status", "op": "eq", "value": ""}]); bad("at most 20", type="kpi", metrics=["files"], filters=[{"field": "status", "op": "in", "value": ["a"] * 21}])
bad("true or false", type="kpi", metrics=["files"], dataset="recon_results", filters=[{"field": "provisional", "op": "eq", "value": "maybe"}])
bad("Width", type="kpi", metrics=["files"], span=5); assert ok(type="kpi", metrics=["files"], title="")["title"] == "Files", "empty title falls back to the metric name"; bad("at most 80", type="kpi", metrics=["files"], title="x" * 81)
bad("approved dataset", type="kpi", metrics=["files"], dataset="information_schema")
c = ok(type="kpi", metrics=["files"], sql="DROP TABLE x", table="evil.table", **{"__class__": "x"}); assert "sql" not in c and "table" not in c, "unknown keys are dropped (nothing executable is stored)"
d, e = sp.validate_dashboard({"widgets": [{"type": "kpi", "dataset": "file_status", "metrics": ["files"]}] * 13}); assert any("At most 12" in x for x in e) and len(d["widgets"]) == 12
d, e = sp.validate_dashboard({"widgets": [{"type": "kpi", "dataset": "file_status", "metrics": ["files"], "id": "same"}] * 2}); assert len({w["id"] for w in d["widgets"]}) == 2
for t in demo.tpl.TEMPLATES.values(): assert not sp.validate_dashboard({"widgets": t["widgets"]})[1], "starter templates are valid"
print("2 widget validation: ok")

# ============================================================ 3. safe SQL generation
a, b = sp.resolve_range("last_7_days", now=NOW)
w = ok(type="line", metrics=["files", ], time_grain="week", dims=["status"], filters=[{"field": "source_type", "op": "in", "value": ["PGW", "x' OR 1=1 --", "`; DROP TABLE t;"]}, {"field": "status", "op": "neq", "value": "FAILED"}])
q = sp.build_query(w, a, b)
assert "SELECT *" not in q.sql.upper() and "LIMIT 50" in q.sql and "`discovered_at` >= @range_start" in q.sql and "WEEK(MONDAY)" in q.sql, q.sql
assert "OR 1=1" not in q.sql and "DROP" not in q.sql and "PGW" not in q.sql, "user values are parameters, never SQL text"
assert dict((n, v) for n, _, v in q.params)["f0"][1] == "x' OR 1=1 --" and ("f1", "STRING", "FAILED") in q.params and q.params[2][1] == "ARRAY<STRING>"
q = sp.build_query(ok(type="kpi", metrics=["reject_pct"]), a, b); assert "GROUP BY" not in q.sql and "LIMIT 1" in q.sql and "SAFE_DIVIDE" in q.sql
q = sp.build_query(ok(type="table", metrics=["files"], dims=["status"], sort={"by": "files", "dir": "asc"}, limit=7), a, b); assert "ORDER BY m0 ASC" in q.sql and q.sql.endswith("LIMIT 7")
q = sp.build_query(ok(type="table", metrics=["result_rows"], dataset="recon_results", dims=["recon_id"], filters=[{"field": "provisional", "op": "eq", "value": "TRUE"}]), a, b)
assert ("f0", "BOOL", True) in q.params and "`window_start`" in q.sql and ".recon_result`" in q.sql
q = sp.build_preview("recon_alarms", a, b); assert "SELECT *" not in q.sql and "LIMIT 20" in q.sql and "`window_start` >= @range_start" in q.sql
s, e = sp.resolve_range("last_30_days", now=NOW); assert (e - s).days in (30,) or 30 <= (e - s).days <= 31
s, e = sp.resolve_range(start="2026-10-01", end="2026-10-10", now=NOW); assert (e - s).days == 10
for kw, msg in (({"start": "2026-01-01", "end": "2026-12-31"}, "at most 93"), ({"start": "2026-10-10", "end": "2026-10-01"}, "must not be before"), ({"start": "x", "end": "y"}, "yyyy-mm-dd"), ({"preset": "forever"}, "Unknown")):
    try: sp.resolve_range(now=NOW, **kw); raise SystemExit("expected SpecError")
    except sp.SpecError as err: assert msg in str(err), (msg, str(err))
print("3 SQL generation: parameterised, partition-filtered, no SELECT *, limited, date range capped: ok")

# ============================================================ 4. charts
def render(w, rows):
    q = sp.build_query(w, a, b); return charts.render(w, q.columns, rows)
r = render(ok(type="bar", metrics=["files"], dims=["status"]), [{"d0": '<img src=x onerror=alert(1)>', "m0": 5}, {"d0": "OK", "m0": 3}])
assert r["kind"] == "svg" and "<img" not in str(r["svg"]) and "&lt;img" in str(r["svg"]), "category text is escaped"
r = render(ok(type="line", metrics=["files"], time_grain="day", dims=["status"]), [{"t": f"2026-10-0{d}T00:00:00+00:00", "d0": s_, "m0": d * 3} for d in range(1, 6) for s_ in ("A", "B")])
assert r["kind"] == "svg" and str(r["svg"]).count("<polyline") == 2 and len(r["legend"]) == 2
r = render(ok(type="bar", metrics=["files"], time_grain="day", dims=["status"], stacked=True), [{"t": "2026-10-01T00:00:00+00:00", "d0": s_, "m0": 4} for s_ in "ABC"]); assert r["kind"] == "svg"
r = render(ok(type="bar", metrics=["total_diff"], dataset="recon_results", dims=["recon_id"]), [{"d0": "A", "m0": -50}, {"d0": "B", "m0": 30}]); assert r["kind"] == "svg", "negative values draw"
r = render(ok(type="line", metrics=["files"], time_grain="day", dims=["status"]), [{"t": "2026-10-01T00:00:00+00:00", "d0": f"s{i}", "m0": 1} for i in range(9)]); assert r["kind"] == "error" and "Too many series" in r["message"]
assert render(ok(type="bar", metrics=["files"], dims=["status"]), [])["kind"] == "empty" and render(ok(type="kpi", metrics=["files"]), [{"m0": None}])["kind"] == "empty"
r = render(ok(type="kpi", metrics=["reject_pct"], decimals=2), [{"m0": 3.14159}]); assert r["value"] == "3.14%"
r = render(ok(type="table", metrics=["files"], dims=["status"]), [{"d0": "A", "m0": 12345}]); assert r["rows"][0][1]["v"] == "12,345"
print("4 charts: escaping, series limit, empty, negatives, formatting: ok")

# ============================================================ app fixtures
def fresh(runner=None):
    st = MemoryStore(); demo.seed_roles(st)
    st.put_role("no-data", "dashboards view only", {**rbac.clean({}), "dashboards": rbac.VIEW}, True, "t")
    for u, role in (("admin", "admin"), ("pub", "dashboard-publisher"), ("cre", "dashboard-creator"), ("cre2", "dashboard-creator"), ("view", "viewer"),
                    ("view2", "viewer"), ("nodata", "no-data"), ("ops", "operator")):
        demo.new_user(st, u, PW, role)
    runner = runner or demo.SampleRunner()
    return st, create_app(st, demo.DemoConfig(), "k" * 40, dev=True, cache_seconds=0, runner=runner), runner

def tok(c, path="/"):
    return re.search(r'name="csrf_token" value="([^"]+)"', c.get(path).get_data(as_text=True)).group(1)
def signin(app, user):
    c = app.test_client()
    r = c.post("/login", data={"csrf_token": tok(c, "/login"), "username": user, "password": PW}); assert r.status_code == 302, user
    return c
def post(c, path, data=None):
    return c.post(path, data={"csrf_token": tok(c), **(data or {})})
def text(r): return r.get_data(as_text=True)
def did(r): return re.search(r"/dashboards/(d_[0-9a-f]{12})", r.headers["Location"]).group(1)
def widget(st, dash_id, **w):
    ver = st.dash_get(dash_id)["version"]
    return {"ver": ver, "action": "save", "type": "kpi", "dataset": "file_status", "title": "Files", "metrics": ["files"], "span": "3", "limit": "50", "decimals": "1", **w}

# ============================================================ 5. create, build, save, reopen, versions, restore
st, app, runner = fresh(); cre = signin(app, "cre")
r = post(cre, "/dashboards/new", {"name": "My ops"}); assert r.status_code == 302; D = did(r)
assert text(cre.get(f"/dashboards/{D}/edit")).count("wcard") == 0 and st.dash_get(D)["version"] == 1
r = post(cre, f"/dashboards/{D}/widgets", widget(st, D, action="preview", title="Preview me")); assert r.status_code == 200 and "kpi" in text(r) and st.dash_get(D)["version"] == 1, "preview does not save"
r = post(cre, f"/dashboards/{D}/widgets", widget(st, D)); assert r.status_code == 302 and st.dash_get(D)["version"] == 2
r = post(cre, f"/dashboards/{D}/widgets", widget(st, D, type="line", title="Trend", dim0="status", time_grain="day", span="8")); assert r.status_code == 302
page = text(cre.get(f"/dashboards/{D}/edit?lazy=0")); assert page.count('class="wcard') == 2 and "Trend" in page and "<svg" in page, "save and reopen"
saved = json.loads(st.dash_get(D)["definition"]); assert [x["type"] for x in saved["widgets"]] == ["kpi", "line"]
assert "SELECT" not in st.dash_get(D)["definition"].upper(), "no SQL is stored in a dashboard"
r = post(cre, f"/dashboards/{D}/widgets", widget(st, D, type="line", title="bad")); assert r.status_code == 200 and "time granularity" in text(r) and st.dash_get(D)["version"] == 3, "invalid widget is refused with reasons"
w1 = saved["widgets"][0]["id"]; v = st.dash_get(D)["version"]
r = post(cre, f"/dashboards/{D}/widgets/{w1}/move", {"ver": v, "dir": "down"}); assert [x["id"] for x in json.loads(st.dash_get(D)["definition"])["widgets"]][1] == w1
r = post(cre, f"/dashboards/{D}/settings", {"ver": 1, "name": "Renamed", "preset": "last_30_days"}); assert "changed by someone else" in text(cre.get(f"/dashboards/{D}/edit")) and st.dash_get(D)["name"] == "My ops", "stale edit refused"
r = post(cre, f"/dashboards/{D}/settings", {"ver": st.dash_get(D)["version"], "name": "Renamed", "preset": "last_30_days", "description": "d"}); assert st.dash_get(D)["name"] == "Renamed"
r = post(cre, f"/dashboards/{D}/widgets/{w1}/delete", {"ver": st.dash_get(D)["version"]}); assert len(json.loads(st.dash_get(D)["definition"])["widgets"]) == 1
vp = text(cre.get(f"/dashboards/{D}/versions")); assert "Restore as new draft" in vp and "v2" in vp
r = post(cre, f"/dashboards/{D}/restore/3"); assert st.dash_get(D)["kind"] == "restore" and len(json.loads(st.dash_get(D)["definition"])["widgets"]) == 2, "restore creates a new version from an old one"
for i in range(11): post(cre, f"/dashboards/{D}/widgets", widget(st, D, title=f"x{i}"))
assert len(json.loads(st.dash_get(D)["definition"])["widgets"]) == 12
assert "at most 12 widgets" in text(post(cre, f"/dashboards/{D}/widgets", widget(st, D, title="13th")))
r = post(cre, "/dashboards/new", {"name": "From tpl", "template": "pipeline_ops"}); assert len(json.loads(st.dash_get(did(r))["definition"])["widgets"]) == 7
assert post(cre, "/dashboards/new", {"name": ""}).status_code == 302 and "1-80" in text(cre.get("/dashboards"))
assert cre.post("/dashboards/new", data={"name": "x"}).status_code == 400, "CSRF token required"
print("5 create / build / save / reopen / version / restore / limits / templates: ok")

# ============================================================ 6. who can do what; sharing; draft vs published; revocation
st, app, runner = fresh(); cre, pub, view, view2, adm = (signin(app, u) for u in ("cre", "pub", "view", "view2", "admin"))
D = did(post(pub, "/dashboards/new", {"name": "Secret ops board"}))
post(pub, f"/dashboards/{D}/widgets", widget(st, D, title="Files")); post(pub, f"/dashboards/{D}/widgets", widget(st, D, title="Loaded", metrics=["records_loaded"]))
# creator without Publish & share
C = did(post(cre, "/dashboards/new", {"name": "Creator board"})); post(cre, f"/dashboards/{C}/widgets", widget(st, C))
assert post(cre, f"/dashboards/{C}/publish", {"ver": st.dash_get(C)["version"]}).status_code == 403 and st.dash_get(C)["published_version"] is None, "creator cannot publish"
assert cre.get(f"/dashboards/{C}/share").status_code == 403 and "Publish &amp; share" in text(cre.get(f"/dashboards/{C}/edit")) and cre.get(f"/dashboards/{C}?draft=1").status_code == 200
assert post(cre, f"/dashboards/{C}/share", {"ptype": "role", "principal": "viewer"}).status_code == 403
# viewers: no access to private dashboards, nothing revealed
for u in (view, view2):
    assert "Secret ops board" not in text(u.get("/dashboards")), "private name not listed"
    assert u.get(f"/dashboards/{D}").status_code == 404 and u.get(f"/dashboards/{D}?draft=1").status_code == 404
    assert u.get(f"/dashboards/{D}/edit").status_code == 403 == u.get("/dashboards/d_000000000000/edit").status_code, "no Edit level: same 403 for real and non-existent ids, nothing revealed"
assert post(view, "/dashboards/new", {"name": "x"}).status_code == 403 and "My dashboards" not in text(view.get("/dashboards")) and "Templates" not in text(view.get("/dashboards"))
assert view.get("/dashboards/catalog").status_code == 403
# publish validates; publishing alone does not make it visible
E = did(post(pub, "/dashboards/new", {"name": "Empty"})); post(pub, f"/dashboards/{E}/publish", {"ver": 1}); assert st.dash_get(E)["published_version"] is None, "empty dashboard cannot be published"
assert post(pub, f"/dashboards/{D}/publish", {"ver": st.dash_get(D)["version"]}).status_code == 302 and st.dash_get(D)["published_version"] == 3
assert view.get(f"/dashboards/{D}").status_code == 404, "published is NOT automatically visible to everyone"
# share with a role
assert post(pub, f"/dashboards/{D}/share", {"ptype": "role", "principal": "nonexistent"}).status_code == 302 and not st.share_list(D)
post(pub, f"/dashboards/{D}/share", {"ptype": "role", "principal": "viewer"})
for u in (view, view2):
    r = u.get(f"/dashboards/{D}?lazy=0"); t = text(r); assert r.status_code == 200 and "Secret ops board" in text(u.get("/dashboards")) and "kpi" in t, "role share works"
    assert "/edit" not in t and "Duplicate" not in t and "Publish" not in t, "viewer sees no edit controls"
    assert u.get(f"/dashboards/{D}/edit").status_code == 403 and post(u, f"/dashboards/{D}/widgets", widget(st, D)).status_code == 403
    assert post(u, f"/dashboards/{D}/publish", {"ver": 3}).status_code == 403 and post(u, f"/dashboards/{D}/archive").status_code == 403 and u.get(f"/dashboards/{D}/share").status_code == 403
    assert u.get(f"/dashboards/{D}/versions").status_code == 403 and u.get(f"/dashboards/{D}?draft=1").status_code == 404
assert signin(app, "ops").get(f"/dashboards/{D}").status_code == 404, "operator role is not in the share"
# draft changes do not reach viewers until republished
post(pub, f"/dashboards/{D}/widgets", widget(st, D, title="Rejected", metrics=["records_rejected"]))
assert text(view.get(f"/dashboards/{D}")).count('class="wcard') == 2 and text(pub.get(f"/dashboards/{D}?draft=1")).count('class="wcard') == 3
post(pub, f"/dashboards/{D}/publish", {"ver": st.dash_get(D)["version"]}); assert text(view.get(f"/dashboards/{D}")).count('class="wcard') == 3
# user share + revoke
post(pub, f"/dashboards/{D}/share/revoke", {"ptype": "role", "principal": "viewer"}); assert view.get(f"/dashboards/{D}").status_code == 404 and "Secret ops board" not in text(view.get("/dashboards"))
post(pub, f"/dashboards/{D}/share", {"ptype": "user", "principal": "view2"}); assert view2.get(f"/dashboards/{D}").status_code == 200 and view.get(f"/dashboards/{D}").status_code == 404
assert "you" in text(view2.get("/dashboards"))
# unpublish / archive hide it again
post(pub, f"/dashboards/{D}/unpublish"); assert view2.get(f"/dashboards/{D}").status_code == 404 and pub.get(f"/dashboards/{D}").status_code == 302, "owner of an unpublished dashboard is sent to the draft preview"
post(pub, f"/dashboards/{D}/publish", {"ver": st.dash_get(D)["version"]}); assert view2.get(f"/dashboards/{D}").status_code == 200
post(pub, f"/dashboards/{D}/archive"); assert view2.get(f"/dashboards/{D}").status_code == 404 and "Secret ops board" not in text(pub.get("/dashboards")) and "Secret ops board" in text(pub.get("/dashboards?archived=1"))
assert pub.get(f"/dashboards/{D}/edit").status_code == 403, "archived dashboards cannot be edited"
# losing the role / permission revokes access immediately
post(pub, f"/dashboards/{C}/unpublish"); 
st.put_user("view2", {**st.get_user("view2"), "role": "no-data"}, by="t"); assert view2.get("/dashboards").status_code == 200
st.put_user("view2", {**st.get_user("view2"), "role": "dashboard-creator", "overrides": json.dumps({"dashboards": 0})}, by="t"); assert view2.get("/dashboards").status_code == 403
print("6 creator/publisher/viewer rules, sharing, draft vs published, unpublish/archive, revocation: ok")

# ============================================================ 7. dashboard access and DATA access are separate
st, app, runner = fresh(); pub, nod, adm = signin(app, "pub"), signin(app, "nodata"), signin(app, "admin")
D = did(post(pub, "/dashboards/new", {"name": "Mixed", "template": "recon_overview"})); post(pub, f"/dashboards/{D}/publish", {"ver": 1}); post(pub, f"/dashboards/{D}/share", {"ptype": "role", "principal": "no-data"})
before = len(runner.queries); r = nod.get(f"/dashboards/{D}?lazy=0"); t = text(r)
assert r.status_code == 200 and t.count("You do not have access to the data") == 6 and len(runner.queries) == before, "a share never grants data; no query is even run"
st.put_role("pipe-only", "d", {**rbac.clean({}), "dashboards": 1, "data_pipeline": 1}, True, "t"); demo.new_user(st, "pipe", PW, "pipe-only"); pubb = signin(app, "pipe"); post(pub, f"/dashboards/{D}/share", {"ptype": "user", "principal": "pipe"})
before = len(runner.queries); t = text(pubb.get(f"/dashboards/{D}?lazy=0")); assert t.count("You do not have access to the data") == 6 and len(runner.queries) == before, "recon widgets need the Recon data module"
D2 = did(post(pub, "/dashboards/new", {"name": "Pipe", "template": "pipeline_ops"})); post(pub, f"/dashboards/{D2}/publish", {"ver": 1}); post(pub, f"/dashboards/{D2}/share", {"ptype": "user", "principal": "pipe"})
before = len(runner.queries); t = text(pubb.get(f"/dashboards/{D2}?lazy=0")); assert "do not have access" not in t and len(runner.queries) == before + 7
st.put_role("cre-nodata", "d", {**rbac.clean({}), "dashboards": 2}, True, "t"); demo.new_user(st, "crend", PW, "cre-nodata"); cn = signin(app, "crend")
C = did(post(cn, "/dashboards/new", {"name": "NoData"})); assert cn.get(f"/dashboards/{C}/widgets/new?type=kpi&dataset=file_status").status_code == 403, "creator cannot build on data they cannot read"
assert "no access" in text(cn.get("/dashboards/catalog")).lower() or "more dataset" in text(cn.get("/dashboards/catalog"))
assert post(cn, f"/dashboards/{C}/widgets", widget(st, C)).status_code == 403
cr = signin(app, "cre"); cat_page = text(cr.get("/dashboards/catalog")); assert "File processing status" in cat_page and "Reconciliation alarms" in cat_page and "COUNT(" not in cat_page
r = cr.get("/dashboards/catalog/file_status/preview"); assert r.status_code == 200 and "<table" in text(r) and runner.queries[-1].meta["type"] == "preview"
assert signin(app, "view").get("/dashboards/catalog/file_status/preview").status_code == 403 and cn.get("/dashboards/catalog/file_status/preview").status_code == 404
print("7 dashboard access vs data access, catalog + preview: ok")

# ============================================================ 8. cross-user access (IDOR), admin override, malformed ids, audit
st, app, runner = fresh(); cre, cre2, pub, adm = (signin(app, u) for u in ("cre", "cre2", "pub", "admin"))
C = did(post(cre, "/dashboards/new", {"name": "Mine"})); post(cre, f"/dashboards/{C}/widgets", widget(st, C))
for method, path in (("get", f"/dashboards/{C}"), ("get", f"/dashboards/{C}/edit"), ("get", f"/dashboards/{C}/versions"), ("get", f"/dashboards/{C}/share"), ("get", f"/dashboards/{C}/widgets/new?type=kpi&dataset=file_status"),
                     ("post", f"/dashboards/{C}/widgets"), ("post", f"/dashboards/{C}/settings"), ("post", f"/dashboards/{C}/publish"), ("post", f"/dashboards/{C}/unpublish"), ("post", f"/dashboards/{C}/archive"),
                     ("post", f"/dashboards/{C}/duplicate"), ("post", f"/dashboards/{C}/restore/1"), ("post", f"/dashboards/{C}/share"), ("post", f"/dashboards/{C}/share/revoke"), ("get", "/dashboards/d_000000000000"), ("get", "/dashboards/nope"), ("get", "/dashboards/..%2f..%2fetc")):
    for who in (cre2, pub):
        r = getattr(who, method)(path) if method == "get" else post(who, path, {"ver": 2})
        assert r.status_code == 404, (method, path, r.status_code)
assert "Mine" not in text(cre2.get("/dashboards")) and "Mine" not in text(cre2.get("/dashboards?tab=all"))
assert adm.get("/dashboards?tab=all").status_code == 200 and "Mine" in text(adm.get("/dashboards?tab=all")) and adm.get(f"/dashboards/{C}/edit").status_code == 200, "dashboard admin sees and edits all"
assert post(adm, f"/dashboards/{C}/share", {"ptype": "role", "principal": "viewer"}).status_code == 302 and post(adm, f"/dashboards/{C}/publish", {"ver": st.dash_get(C)["version"]}).status_code == 302 and signin(app, "view").get(f"/dashboards/{C}").status_code == 200
assert cre2.get("/dashboards?tab=all").status_code == 200 and "Mine" not in text(cre2.get("/dashboards?tab=all")), "non-admin cannot list everything"
ev = {e["event"] for e in st.events}
for need in ("DASHBOARD_CREATED", "DASHBOARD_SAVED", "DASHBOARD_PUBLISHED", "DASHBOARD_SHARED", "DASHBOARD_VIEWED"): assert need in ev, need
viewed = [e for e in st.events if e["event"] == "DASHBOARD_VIEWED"][-1]; assert "bytes=" in viewed["detail"] and "queries=" in viewed["detail"], "query telemetry audited"
assert post(signin(app, "view"), f"/dashboards/{C}/publish", {"ver": 1}).status_code == 403 and any(e["event"] == "ACCESS_DENIED" for e in st.events)
assert "SELECT" not in json.dumps([e["detail"] for e in st.events]).upper(), "no SQL in the audit log"
print("8 cross-user access, admin override, malformed ids, audit: ok")

# ============================================================ 9. a failing widget does not break the page
class Flaky(demo.SampleRunner):
    def run(self, q):
        if "records_loaded" in q.sql or "SUM(records_loaded)" in q.sql: raise dash_exec.QueryError("This query would scan more than 5 GB. Choose a shorter date range.")
        return super().run(q)
st, app, runner = fresh(Flaky()); pub = signin(app, "pub"); D = did(post(pub, "/dashboards/new", {"name": "F", "template": "pipeline_ops"})); t = text(pub.get(f"/dashboards/{D}/edit?lazy=0"))
assert pub.get(f"/dashboards/{D}/edit?lazy=0").status_code == 200 and "would scan more than 5 GB" in t and t.count("<svg") >= 2 and t.count('class="kpi"') == 3, "one failing widget, the rest still render"
print("9 widget failure isolation: ok")

logging.getLogger("prism.dashboards").setLevel(logging.CRITICAL)      # the runner logs unexpected errors server-side (by design)
# ============================================================ 10. cost / load controls of the real runner (fake BigQuery client)
class Job:
    def __init__(self, rows, billed=1234, exc=None): self.rows, self.total_bytes_processed, self.cache_hit, self.exc, self.cancelled = rows, billed, False, exc, False
    def result(self, timeout=None):
        self.timeout = timeout
        if self.exc: raise self.exc
        return self.rows
    def cancel(self): self.cancelled = True
class Helper:
    enc = "CMEK"
    def __init__(self, job): self.job, self.seen = job, []; self.client = self
    def query(self, sql, job_config=None): self.seen.append((sql, job_config)); return self.job
q = sp.build_query(ok(type="table", metrics=["files"], dims=["status"], filters=[{"field": "source_type", "op": "in", "value": ["PGW"]}]), a, b)
h = Helper(Job([{"d0": "OK", "m0": Decimal("7.5")}, {"d0": "X", "m0": 1}])); res = dash_exec.BigQueryRunner(h).run(q)
sql, cfg = h.seen[0]; assert cfg.maximum_bytes_billed == dash_exec.MAX_BYTES_BILLED and cfg.labels == {"app": "prism-gui", "feature": "dashboards"} and cfg.destination_encryption_configuration == "CMEK"
assert h.job.timeout == dash_exec.TIMEOUT_SECONDS and res.rows[0]["m0"] == 7.5 and res.bytes_processed == 1234
assert ("range_start", "TIMESTAMP", a) in cfg.query_parameters and ("f0", "STRING", ["PGW"]) in cfg.query_parameters
class Forbidden(Exception): pass
class NotFound(Exception): pass
for exc, expect in ((Exception("400 Query exceeded limit for bytesBilled: 5368709120"), "scan more than 5 GB"), (TimeoutError("x"), "longer than 30 seconds"), (Forbidden("403"), "no permission"),
                    (NotFound("404 table"), "not found"), (Exception("Quota exceeded: concurrent queries"), "quota"), (Exception("secret-internal-detail project/table xyz"), "reference")):
    j = Job([], exc=exc)
    try: dash_exec.BigQueryRunner(Helper(j)).run(q); raise SystemExit("expected QueryError")
    except dash_exec.QueryError as e: assert expect in str(e) and "secret-internal-detail" not in str(e), (expect, str(e)); assert j.cancelled, "job cancelled on failure"
r = dash_exec.BigQueryRunner(Helper(Job([])), max_concurrent=1); r.slots.acquire(); old = dash_exec.BUSY_WAIT_SECONDS; dash_exec.BUSY_WAIT_SECONDS = 0.05
try: r.run(q); raise SystemExit("expected busy")
except dash_exec.QueryError as e: assert "busy" in str(e)
finally: dash_exec.BUSY_WAIT_SECONDS = old
print("10 cost caps, timeout, labels, params, concurrency, error hygiene: ok")

# ============================================================ 11. role upgrade for installations that already have roles
old = MemoryStore(); old.put_role("admin", "old admin", {m: 2 for m in ("sources", "lookups", "recon", "audit", "users", "roles")}, True, "t")
old.put_role("custom", "mine", {"lookups": 2}, True, "t"); import io, contextlib
with contextlib.redirect_stdout(io.StringIO()) as out: manage.main(["seed-roles"], store=old)
adm_p, cus_p = rbac.loads(old.get_role("admin")["permissions"]), rbac.loads(old.get_role("custom")["permissions"])
assert adm_p["dashboards"] == 2 and adm_p["dash_admin"] == 2 and adm_p["data_pipeline"] == 1 and adm_p["users"] == 2, "built-in role gains the new modules"
assert cus_p["lookups"] == 2 and cus_p["dashboards"] == 0 and cus_p["dash_publish"] == 0, "custom role keeps its levels; new modules are No access"
assert old.get_role("dashboard-creator") and old.get_role("viewer")
print("11 seed-roles upgrade of existing roles: ok")
print("ALL DASHBOARD STUDIO CHECKS PASSED")
