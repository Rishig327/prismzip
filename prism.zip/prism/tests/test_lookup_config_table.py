"""LookupManager reads its definitions from prism_lookup_config (fake BigQuery).   python tests/test_lookup_config_table.py"""
import os, sys, types
import _paths  # noqa: F401  (adds common/, orchestrator/, sources/* to sys.path)

class R:                                   # BigQuery-row stand-in
    def __init__(self, **k): self.__dict__.update(k)
class Q:
    def __init__(self, rows): self.rows = rows
    def result(self): return self.rows
class P:
    def __init__(self, *a, **k): self.a, self.k = a, k
ALL = [R(lookup_name="lk_a", table_name="T_A", key_fields=["NAME"], value_fields=["VALUE"], match_type="exact", enabled=True),
       R(lookup_name="lk_p", table_name="T_P", key_fields=["PFX", "TYPE"], value_fields=["VALUE"], match_type="PREFIX", enabled=True),
       R(lookup_name="lk_bad", table_name="T_X", key_fields=[], value_fields=["V"], match_type="regex", enabled=True),   # wrong, not used
       R(lookup_name="lk_off", table_name="T_O", key_fields=["K"], value_fields=["V"], match_type="exact", enabled=False)]
class FakeClient:
    config_queries = []
    def __init__(self, *a, **k): pass
    def query(self, sql, job_config=None):
        if "prism_lookup_config" in sql:
            names = [p.a[2] for p in job_config.k["query_parameters"]]
            names = names[0] if names else None
            FakeClient.config_queries.append(names)
            return Q([r for r in ALL if names is None or r.lookup_name in names])
        if "T_A" in sql: return Q([R(NAME="x", VALUE="1")])
        return Q([R(PFX="4478", TYPE="M", VALUE="VF"), R(PFX="44", TYPE="M", VALUE="UK")])
bq = types.ModuleType("google.cloud.bigquery"); bq.Client = FakeClient
bq.QueryJobConfig = bq.EncryptionConfiguration = bq.ArrayQueryParameter = P
g, gc = types.ModuleType("google"), types.ModuleType("google.cloud"); gc.bigquery = bq; g.cloud = gc
sys.modules.update({"google": g, "google.cloud": gc, "google.cloud.bigquery": bq})

from LookupsManager import LookupManager as LM
assert "Lookups_config" not in sys.modules
# only the SELECTED lookups are read and validated: lk_bad has a wrong definition but is not requested -> no error
LM.load_selected(["lk_a", "lk_p"])
assert FakeClient.config_queries == [["lk_a", "lk_p"]], FakeClient.config_queries      # one query, only those names
assert sorted(LM.LOOKUP_CONFIGS) == ["lk_a", "lk_p"]
assert LM.get_lookup("lk_a", "x") == {"VALUE": "1"}
assert LM.get_lookup("lk_p", "447812", "M") == {"VALUE": "VF"}          # longest prefix, match_type lower-cased
assert LM.LOOKUP_CONFIGS["lk_p"]["match_type"] == "prefix"
# a wrong definition fails only when THAT lookup is requested, and names it
try: LM.load_lookup("lk_bad"); raise SystemExit("expected ValueError")
except ValueError as e: assert "lk_bad" in str(e) and "key_fields" in str(e) and "match_type" in str(e)
# disabled / unknown lookups are reported as missing
for n in ("lk_off", "lk_missing"):
    try: LM.load_lookup(n); raise SystemExit("expected ValueError")
    except ValueError as e: assert n in str(e) and "enabled = FALSE" in str(e)
# load_all reads every enabled lookup, so it does surface the wrong one
LM.clear()
try: LM.load_all(); raise SystemExit("expected ValueError")
except ValueError as e: assert "lk_bad" in str(e)
print("OK")
