"""
Dashboard Studio, JavaScript phase - SERVER side: new widget types, lazy-load fragments, viewer filters, previous-period KPI,
layout saving, CSV export (separate permission), CSP. (The browser behaviour is tested in tests/test_gui_browser.py.)
In-memory store + sample runner: proves the code, not real BigQuery.      python tests/test_gui_phase2.py
"""
import json, re
from _gui_helpers import *                        # noqa: F401,F403
from _gui_helpers import fresh, signin, post, text, widgets_of, tok
import charts, dash_catalog as cat, dash_exec, dash_spec as sp, demo, manage, rbac
from store import MemoryStore

# ============================================================ 1. every template widget renders (regression: time-only line chart crashed)
st, app, runner = fresh(); pub = signin(app, "pub")
for tid in demo.tpl.TEMPLATES:
    D = demo.new_dashboard(st, "pub", tid, tid)
    page = text(pub.get(f"/dashboards/{D}/edit?lazy=0"))
    assert page.count('class="wcard') == len(widgets_of(st, D)) and 'class="wmsg err"' not in page, (tid, "a widget failed to render")
print("1 all template widgets render (time-only line, area, donut ...): ok")

# ============================================================ 2. lazy loading: page is instant, fragments carry the data
st, app, runner = fresh(); pub, view, cre2, nod, adm = (signin(app, u) for u in ("pub", "view", "cre2", "nodata", "admin"))
defn = {"filters": ["source"], "refresh": 5, "widgets": [
    {"type": "kpi", "title": "Rejects", "dataset": "file_status", "metrics": ["reject_pct"], "compare": True, "span": 3},
    {"type": "bar", "title": "By source", "dataset": "file_status", "metrics": ["files"], "dims": ["source_type"], "span": 6},
    {"type": "donut", "title": "Status", "dataset": "file_status", "metrics": ["files"], "dims": ["status"], "span": 3},
    {"type": "area", "title": "Area", "dataset": "file_status", "metrics": ["files"], "time_grain": "day", "span": 6},
    {"type": "heatmap", "title": "Heat", "dataset": "file_status", "metrics": ["files"], "dims": ["status"], "time_grain": "day", "span": 6},
    {"type": "pivot", "title": "Pivot", "dataset": "file_status", "metrics": ["files"], "dims": ["status", "source_type"], "span": 12},
    {"type": "kpi", "title": "Recon", "dataset": "recon_results", "metrics": ["mismatch_pct"], "span": 3}]}
D = demo.new_dashboard(st, "pub", "Lazy", definition=defn, publish=True, share=[("role", "viewer"), ("role", "no-data")])
W = {w["title"]: w["id"] for w in widgets_of(st, D)}
n0 = len(runner.queries); page = text(view.get(f"/dashboards/{D}"))
assert len(runner.queries) == n0, "the page itself runs no query"
assert page.count('data-render="') == 7 and 'src="/static/dash.js"' in page and '<noscript><meta http-equiv="refresh"' in page and "skeleton" in page and 'data-refresh="5"' in page
frag = lambda c, wid, q="": c.get(f"/dashboards/{D}/widgets/{wid}/render{q}")
for title, wid in W.items():
    n0 = len(runner.queries); r = frag(view, wid); t = text(r)
    if title == "Recon":
        assert r.status_code == 200 and "do not have access" not in t, "viewer has Recon data"
    assert r.status_code == 200 and "Updated " in t and 'class="wmsg err"' not in t, (title, t[:200])
    assert len(runner.queries) - n0 == (2 if title == "Rejects" else 1), (title, "queries")
t = text(frag(view, W["Rejects"])); assert "vs previous period" in t and 'class="delta ' in t
r = frag(view, W["Rejects"]); a_, b_ = runner.queries[-2], runner.queries[-1]
pa, pb = dict((n, v) for n, _, v in a_.params), dict((n, v) for n, _, v in b_.params)
assert pb["range_end"] == pa["range_start"] and (pb["range_end"] - pb["range_start"]) == (pa["range_end"] - pa["range_start"]), "previous period = same length, directly before"
assert 'data-fk="source"' in text(frag(view, W["By source"])) and 'data-fv="PGW"' in text(frag(view, W["By source"]))
assert 'data-fk="file_status.status"' in text(frag(view, W["Status"]))
# access: not shared / other users / draft / unknown / anonymous
n0 = len(runner.queries)
assert frag(cre2, W["Rejects"]).status_code == 404 and frag(view, "w000000").status_code == 404 and frag(view, W["Rejects"], "?draft=1").status_code == 404
assert view.get("/dashboards/nope/widgets/x/render").status_code == 404 and app.test_client().get(f"/dashboards/{D}/widgets/{W['Rejects']}/render").status_code == 302
assert frag(pub, W["Rejects"], "?draft=1").status_code == 200 and frag(adm, W["Rejects"], "?draft=1").status_code == 200
assert len(runner.queries) - n0 == 4, "only the allowed requests ran queries (2 KPIs x 2 queries)"
n0 = len(runner.queries); t = text(frag(nod, W["Rejects"])); assert "do not have access to the data" in t and len(runner.queries) == n0, "data access is the user's own: no query"
print("2 lazy fragments: queries only on request, comparison query, access control, data access: ok")

# ============================================================ 3. viewer filters
n0 = len(runner.queries); t = text(frag(view, W["By source"], "?f_source=PGW"))
p = dict((n, v) for n, _, v in runner.queries[-1].params); assert p["f0"] == ["PGW"] and "IN UNNEST(@f0)" in runner.queries[-1].sql
text(frag(view, W["By source"], "?f_source=" + "x'; DROP TABLE t;--")); assert "DROP" not in runner.queries[-1].sql and "x'; DROP TABLE t;--" in dict((n, v) for n, _, v in runner.queries[-1].params)["f0"][0]
text(frag(view, W["Recon"], "?f_source=PGW")); assert "f0" not in dict((n, v) for n, _, v in runner.queries[-1].params), "a filter only applies to datasets that have that field"
text(frag(view, W["By source"], "?f_recon=r1")); assert "f0" not in dict((n, v) for n, _, v in runner.queries[-1].params), "a filter the creator did not enable is ignored"
text(frag(view, W["By source"], "?f_source=" + ",".join(f"v{i}" for i in range(25)))); assert "f0" not in dict((n, v) for n, _, v in runner.queries[-1].params), "more than 20 values ignored"
t = text(view.get(f"/dashboards/{D}?f_source=" + "a" * 101)); assert "at most 20 values of 100 characters" in t, "the page tells the user why a filter was ignored"
t = text(view.get(f"/dashboards/{D}?f_source=PGW")); assert 'name="f_source" value="PGW"' in t and "Source" in t
# settings: filters + refresh validated and saved
E = demo.new_dashboard(st, "pub", "Settings", template="pipeline_ops"); v = st.dash_get(E)["version"]
post(pub, f"/dashboards/{E}/settings", {"ver": v, "name": "Settings", "preset": "last_7_days", "dfilter": ["source", "pipeline_runs.status"], "refresh": "5"})
d = json.loads(st.dash_get(E)["definition"]); assert d["filters"] == ["source", "pipeline_runs.status"] and d["refresh"] == 5 and st.dash_get(E)["version"] == v + 1
v = st.dash_get(E)["version"]
post(pub, f"/dashboards/{E}/settings", {"ver": v, "name": "Settings", "dfilter": ["nonsense"], "refresh": "7"})
assert st.dash_get(E)["version"] == v, "invalid settings are refused"
t = text(pub.get(f"/dashboards/{E}/edit"))
assert "Unknown dashboard filter" in t and "Refresh interval" in t, "the reasons are shown"
print("3 viewer filters (parameters only, dataset-aware, validated) and dashboard settings: ok")

# ============================================================ 4. layout saving
st, app, runner = fresh(); pub, cre, cre2, view, adm = (signin(app, u) for u in ("pub", "cre", "cre2", "view", "admin"))
D = demo.new_dashboard(st, "pub", "Layout", template="pipeline_ops"); ws = widgets_of(st, D); ids = [w["id"] for w in ws]; v = st.dash_get(D)["version"]
new_order = ids[::-1]; spans = ",".join(f"{i}:{s}" for i, s in zip(new_order, [12, 8, 6, 4, 3, 3, 6]))
r = post(pub, f"/dashboards/{D}/layout", {"ver": v, "order": ",".join(new_order), "spans": spans}); assert r.status_code == 302
got = widgets_of(st, D); assert [w["id"] for w in got] == new_order and [w["span"] for w in got] == [12, 8, 6, 4, 3, 3, 6] and st.dash_get(D)["version"] == v + 1 and st.dash_get(D)["note"] == "layout"
assert [w["title"] for w in got] == [{x["id"]: x["title"] for x in ws}[i] for i in new_order], "widgets themselves unchanged, only order and width"
v = st.dash_get(D)["version"]
post(pub, f"/dashboards/{D}/layout", {"ver": v, "order": ",".join(new_order), "spans": spans}); assert st.dash_get(D)["version"] == v, "unchanged layout creates no version"
for bad in (",".join(new_order[:-1]), ",".join(new_order + ["extra"]), ",".join(["w1"] + new_order[1:]), ""):
    post(pub, f"/dashboards/{D}/layout", {"ver": v, "order": bad, "spans": ""}); assert st.dash_get(D)["version"] == v and [w["id"] for w in widgets_of(st, D)] == new_order, ("tampered order refused", bad)
post(pub, f"/dashboards/{D}/layout", {"ver": v, "order": ",".join(new_order), "spans": f"{new_order[0]}:5,{new_order[1]}:abc,zz:6,{new_order[2]}:3"})
assert [w["span"] for w in widgets_of(st, D)][:3] == [12, 8, 3], "invalid widths ignored, valid ones applied"
post(pub, f"/dashboards/{D}/layout", {"ver": v, "order": ",".join(ids), "spans": ""}); assert "changed by someone else" in text(pub.get(f"/dashboards/{D}/edit")), "stale layout refused"
v = st.dash_get(D)["version"]
assert post(view, f"/dashboards/{D}/layout", {"ver": v, "order": ",".join(ids)}).status_code == 403 and post(cre, f"/dashboards/{D}/layout", {"ver": v, "order": ",".join(ids)}).status_code == 404 and post(cre2, f"/dashboards/{D}/layout", {}).status_code == 404
assert post(adm, f"/dashboards/{D}/layout", {"ver": v, "order": ",".join(ids), "spans": ""}).status_code == 302 and [w["id"] for w in widgets_of(st, D)] == ids, "dashboard admin may"
page = text(pub.get(f"/dashboards/{D}/edit")); assert 'id="layoutbar"' in page and 'class="rz"' in page and 'class="dh"' in page and 'src="/static/dash_editor.js"' in page
print("4 layout saving: validated order and widths, unchanged / tampered / stale / permissions: ok")

# ============================================================ 5. CSV export: separate permission, own data access, injection-safe, audited
class Evil(demo.SampleRunner):
    def run(self, q):
        res = super().run(q)
        for r in res.rows:
            for c in q.columns:
                if c["kind"] == "dim": r[c["alias"]] = "=HYPERLINK(\"http://evil\")"
                if c["kind"] == "metric": r[c["alias"]] = -5
        return res
st, app, runner = fresh(Evil()); pub, exp, view, nod = (signin(app, u) for u in ("pub", "exp", "view", "nodata"))
D = demo.new_dashboard(st, "pub", "Export me", definition={"widgets": [
    {"type": "table", "title": "Files / by status", "dataset": "file_status", "metrics": ["files"], "dims": ["status"], "limit": 3},
    {"type": "table", "title": "Recon", "dataset": "recon_results", "metrics": ["result_rows"], "dims": ["recon_id"]}]}, publish=True,
    share=[("role", "viewer"), ("role", "exporter"), ("role", "no-data")])
W0, W1 = [w["id"] for w in widgets_of(st, D)]
url = lambda w, q="": f"/dashboards/{D}/widgets/{w}/export.csv{q}"
assert view.get(url(W0)).status_code == 403 and any(e["event"] == "ACCESS_DENIED" and "export" in e["detail"] for e in st.events), "viewing is not exporting"
assert "Export CSV" not in text(view.get(f"/dashboards/{D}/widgets/{W0}/render")) and "Export CSV" in text(exp.get(f"/dashboards/{D}/widgets/{W0}/render"))
r = exp.get(url(W0)); body = text(r)
assert r.status_code == 200 and r.mimetype == "text/csv" and 'attachment; filename="export_me_files_by_status.csv"' in r.headers["Content-Disposition"]
lines = body.strip().splitlines(); assert lines[0] == "File status,Files (files)" and len(lines) <= 4 and all(l.startswith("\"'=HYPERLINK") or l.startswith("'=HYPERLINK") for l in lines[1:]), lines
assert all(l.endswith(",-5") for l in lines[1:]), "numbers stay numbers (a negative number is not a formula)"
ev = [e for e in st.events if e["event"] == "DATA_EXPORTED"][-1]; assert W0 in ev["detail"] and "rows=" in ev["detail"] and ev["actor"] == "exp"
n0 = len(runner.queries); r = exp.get(url(W0, "?f_source=PGW")); assert r.status_code == 200
assert signin(app, "nodata").get(url(W0)).status_code == 403, "no export permission"
assert exp.get(url("w999999")).status_code == 404 and signin(app, "cre2").get(url(W0)).status_code == 403 and app.test_client().get(url(W0)).status_code == 302
st.put_user("nodata", {**st.get_user("nodata"), "role": "exporter"}, by="t"); st.put_role("exp-nodata", "d", {**rbac.clean({}), "dashboards": 1, "dash_export": 1}, True, "t"); st.put_user("nodata", {**st.get_user("nodata"), "role": "exp-nodata"}, by="t"); st.share_put(D, "role", "exp-nodata", True, "pub")
assert signin(app, "nodata").get(url(W0)).status_code == 403, "export permission without the data permission still gets nothing"
print("5 CSV export: separate permission, data access, injection guard, audit: ok")

# ============================================================ 6. CSP: scripts only on dashboard pages, only our files, never inline
st, app, runner = fresh(); pub = signin(app, "pub"); D = demo.new_dashboard(st, "pub", "CSP", template="pipeline_ops", publish=True)
wid = widgets_of(st, D)[0]["id"]
for path in ("/dashboards", f"/dashboards/{D}", f"/dashboards/{D}?lazy=0", f"/dashboards/{D}/edit", f"/dashboards/{D}/widgets/new?type=donut&dataset=file_status", f"/dashboards/{D}/widgets/{wid}",
             f"/dashboards/{D}/share", f"/dashboards/{D}/versions", "/dashboards/catalog", f"/dashboards/{D}/widgets/{wid}/render"):
    r = pub.get(path); html = text(r); csp = r.headers["Content-Security-Policy"]
    assert r.status_code == 200 and "script-src 'self';" in csp and "unsafe-inline" not in csp.split("script-src")[1].split(";")[0] and "unsafe-eval" not in csp, (path, csp)
    for m in re.finditer(r"<script\b[^>]*>", html): assert re.search(r'src="/static/dash(_editor)?\.js"', m.group(0)), (path, "inline or foreign script", m.group(0))
    assert not re.search(r"\son[a-z]+\s*=", html) and "javascript:" not in html.lower(), (path, "inline event handler")
for path in ("/", "/lookups", "/users", "/roles", "/account/password", "/sources"):
    assert "script-src 'none'" in pub.get(path).headers["Content-Security-Policy"], (path, "no scripts outside Dashboard Studio")
assert "script-src 'none'" in app.test_client().get("/login").headers["Content-Security-Policy"]
print("6 CSP: scripts allowed only on dashboard pages, only /static/dash*.js, no inline code: ok")

# ============================================================ 7. error auditing + role upgrade for the export module
class Flaky(demo.SampleRunner):
    def run(self, q): raise dash_exec.QueryError("This query would scan more than 5 GB.")
st, app, runner = fresh(Flaky()); pub = signin(app, "pub"); D = demo.new_dashboard(st, "pub", "F", template="pipeline_ops"); wid = widgets_of(st, D)[0]["id"]
assert "scan more than 5 GB" in text(pub.get(f"/dashboards/{D}/widgets/{wid}/render?draft=1")) and any(e["event"] == "WIDGET_QUERY" and "FAILED" in e["detail"] for e in st.events)
old = MemoryStore(); old.put_role("admin", "old", {m: 2 for m in ("sources", "lookups", "recon", "audit", "users", "roles", "dashboards", "dash_publish", "dash_admin", "data_pipeline", "data_recon")}, True, "t")
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()): manage.main(["seed-roles"], store=old)
assert rbac.loads(old.get_role("admin")["permissions"])["dash_export"] == 1 and rbac.loads(old.get_role("viewer")["permissions"])["dash_export"] == 0
print("7 failure auditing, seed-roles adds the export module (off for viewers): ok")
print("ALL PHASE 2 SERVER CHECKS PASSED")
