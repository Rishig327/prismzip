"""GUI: sign-in, lock-out, forced password change, roles + module access, overrides, admin safeguards, audit.
No Google access (in-memory store, demo config).   python tests/test_gui_auth.py"""
import os, re, sys, types
import _paths  # noqa: F401  (adds common/, orchestrator/, gui/, sources/* to sys.path)

class P:                                                  # config_store needs the bigquery names to exist; nothing is called
    def __init__(self, *a, **k): pass
bq = types.ModuleType("google.cloud.bigquery")
for n in ("ScalarQueryParameter", "ArrayQueryParameter", "EncryptionConfiguration", "QueryJobConfig", "Client"):
    setattr(bq, n, P)
g, gc = types.ModuleType("google"), types.ModuleType("google.cloud"); gc.bigquery = bq; g.cloud = gc
sys.modules.update({"google": g, "google.cloud": gc, "google.cloud.bigquery": bq})

from datetime import datetime, timedelta, timezone      # noqa: E402
import demo, rbac, security as sec                      # noqa: E402
from app import create_app                              # noqa: E402
from store import MemoryStore                           # noqa: E402

PW = "Start-Pass-Word-42!"

def fresh():
    st = MemoryStore(); demo.seed_roles(st)
    demo.new_user(st, "admin", PW, "admin"); demo.new_user(st, "ops", PW, "operator"); demo.new_user(st, "view", PW, "viewer")
    app = create_app(st, demo.DemoConfig(), "k" * 40, dev=True, cache_seconds=0)
    return st, app

def token(client, path="/login"):
    html = client.get(path).get_data(as_text=True)
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)

def post(client, path, data=None, follow=False, path_for_token="/login"):
    return client.post(path, data={"csrf_token": token(client, path_for_token), **(data or {})}, follow_redirects=follow)

def signin(app, user="admin", pw=PW):
    c = app.test_client(); r = post(c, "/login", {"username": user, "password": pw}); return c, r

def text(r): return r.get_data(as_text=True)

# 1. anonymous access, CSRF, generic errors, safe redirect
st, app = fresh(); c = app.test_client()
r = c.get("/lookups"); assert r.status_code == 302 and "/login?next=/lookups" in r.headers["Location"]
r = c.get("/login"); assert r.status_code == 200 and "logo-full.png" in text(r) and "Predictive Revenue-Insights" in text(r)
assert c.post("/login", data={"username": "admin", "password": PW}).status_code == 400, "login POST without CSRF token must fail"
assert c.get("/healthz").status_code == 200
for u, p in (("admin", "wrong-password-1A!"), ("nobody", "whatever-1A!x")):
    r = post(c, "/login", {"username": u, "password": p}); assert "Incorrect username or password." in text(r), u     # same text for both
r = post(c, "/login", {"username": "admin", "password": PW, "next": "//evil.example"}); assert r.headers["Location"].endswith("/") and "evil" not in r.headers["Location"]
c3 = app.test_client(); r = post(c3, "/login", {"username": "admin", "password": PW, "next": "/lookups"}); assert r.headers["Location"].endswith("/lookups")
cookie = [h for h in r.headers.getlist("Set-Cookie") if h.startswith("prism_session")][0]; assert "HttpOnly" in cookie and "SameSite=Lax" in cookie
r = c3.get("/"); h = r.headers; assert "script-src 'none'" in h["Content-Security-Policy"] and h["X-Frame-Options"] == "DENY" and h["Cache-Control"] == "no-store"
print("1 sign-in, CSRF, generic errors, safe redirect, cookie + headers: ok")

# 2. lock-out after 5 wrong passwords; unlock; failures do not count after a success
st, app = fresh(); c = app.test_client()
for _ in range(5): post(c, "/login", {"username": "view", "password": "wrong-password-1A!"})
r = post(c, "/login", {"username": "view", "password": PW}); assert "Too many wrong passwords" in text(r) and "view" not in c.get("/").headers.get("Location", "x")
assert any(e["event"] == "LOGIN_BLOCKED" for e in st.events)
ca, _ = signin(app); r = post(ca, "/users/view/unlock", path_for_token="/users/view"); assert r.status_code == 302
cv, r = signin(app, "view"); assert r.status_code == 302 and cv.get("/").status_code == 200, "unlocked user can sign in"
st, app = fresh(); c = app.test_client()
for _ in range(4): post(c, "/login", {"username": "ops", "password": "wrong-password-1A!"})
signin(app, "ops")                                                         # success ends the run of failures
for _ in range(4): post(c, "/login", {"username": "ops", "password": "wrong-password-1A!"})
assert signin(app, "ops")[1].status_code == 302, "4+4 failures with a success between must not lock"
now = datetime.now(timezone.utc); ev = [("LOGIN_FAIL", now - timedelta(minutes=i)) for i in range(5)]
assert sec.lock_until(ev, now) and not sec.lock_until(ev, now + timedelta(minutes=20)), "lock ends after LOCK_MINUTES"
print("2 lock-out, unlock, reset by success, expiry: ok")

# 3. forced password change: new user, policy, history, other sessions end
st, app = fresh(); ca, _ = signin(app)
r = post(ca, "/users/new", {"username": "newbie", "display_name": "New B", "role": "viewer", "enabled": "on"}, path_for_token="/users/new")
assert r.status_code == 200 and "shown only once" in text(r); temp = re.search(r'class="secret">([^<]+)<', text(r)).group(1)
assert not sec.policy_problems(temp, "newbie")
cn, r = signin(app, "newbie", temp); assert r.status_code == 302 and cn.get("/").headers["Location"].endswith("/account/password")
assert cn.get("/lookups").headers["Location"].endswith("/account/password"), "every page redirects until the password is changed"
def change(c, cur, new, again=None): return post(c, "/account/password", {"current": cur, "new": new, "again": again or new}, path_for_token="/account/password")
for bad, why in (("short1A!", "at least 12"), ("alllowercaseletters", "at least 3 of"), ("Newbie-Pass-123!", "username"), ("My-Vodafone-Pass9!", "easy words")):
    assert why in text(change(cn, temp, bad)), why
assert "not the same" in text(change(cn, temp, "Fine-New-Pass-77!", "Fine-New-Pass-78!"))
assert "current password is not correct" in text(change(cn, "nope-nope-1A!x", "Fine-New-Pass-77!"))
r = change(cn, temp, "Fine-New-Pass-77!"); assert r.status_code == 302 and cn.get("/").status_code == 200
for i in range(5):                                                         # history: the old password cannot come back
    change(cn, "Fine-New-Pass-77!" if i == 0 else f"Round-Pass-{i-1}-xZ!", f"Round-Pass-{i}-xZ!")
assert "was used recently" in text(change(cn, "Round-Pass-4-xZ!", "Round-Pass-0-xZ!")), "one of the last 5 passwords (current included) is refused"
assert "was used recently" in text(change(cn, "Round-Pass-4-xZ!", "Round-Pass-4-xZ!")), "the current password cannot be set again"
assert cn.get("/").status_code == 200
other = app.test_client(); post(other, "/login", {"username": "newbie", "password": "Round-Pass-4-xZ!"}); assert other.get("/").status_code == 200
change(cn, "Round-Pass-4-xZ!", "Brand-New-Pass-5-xZ!"); assert other.get("/").status_code == 302, "password change ends the user's other sessions"
assert cn.get("/").status_code == 200, "the session that changed it stays signed in"
st.put_user("view", {**st.get_user("view"), "password_changed_at": datetime.now(timezone.utc) - timedelta(days=91)}, by="t")
cv, _ = signin(app, "view"); assert cv.get("/lookups").headers["Location"].endswith("/account/password"), "expired password forces a change"
print("3 temp password, forced change, policy, history, session end, expiry: ok")

# 4. RBAC: roles, module visibility, 403s, edit rights, overrides, max level
st, app = fresh(); cv, _ = signin(app, "view"); co, _ = signin(app, "ops"); ca, _ = signin(app)
home = text(cv.get("/")); assert "Lookups" in home and "Users" not in home and "Roles" not in home
assert cv.get("/lookups").status_code == 200 and cv.get("/users").status_code == 403 and cv.get("/audit").status_code == 403
assert "New lookup" not in text(cv.get("/lookups")) and "disabled" in text(cv.get("/lookups/lk_VFUK_R_UC_MVNO_IMSI"))
form = {"table_name": "T1", "key_fields": "A, B", "value_fields": "V", "match_type": "exact", "enabled": "on", "note": "t"}
assert post(cv, "/lookups/lk_VFUK_R_UC_MVNO_IMSI", form, path_for_token="/lookups").status_code == 403, "view-only user cannot edit"
r = post(co, "/lookups/lk_VFUK_R_UC_MVNO_IMSI", form, path_for_token="/lookups"); assert r.status_code == 302
assert "T1" in text(co.get("/lookups")) and any(e["event"] == "LOOKUP_CHANGED" for e in st.events)
r = post(co, "/lookups/lk_VFUK_R_UC_MVNO_IMSI", {**form, "match_type": "regex"}, path_for_token="/lookups"); assert "must be one of" in text(r), "validation message shown"
r = post(co, "/lookups/new", {**form, "lookup_name": "lk_NEW1"}, path_for_token="/lookups"); assert r.status_code == 302 and "lk_NEW1" in text(co.get("/lookups"))
assert co.get("/users").status_code == 403 and co.get("/sources").status_code == 200 and co.get("/recon").status_code == 200
# per-user override: viewer + lookups edit
u = st.get_user("view"); st.put_user("view", {**u, "overrides": '{"lookups": 2, "audit": 1}'}, by="t")
assert post(cv, "/lookups/lk_NEW1", {**form, "table_name": "T2"}, path_for_token="/lookups").status_code == 302 and cv.get("/audit").status_code == 200, "override applies at the next click"
st.put_user("view", {**st.get_user("view"), "overrides": '{"sources": 2}'}, by="t"); assert rbac.effective({}, {"sources": 2})["sources"] == rbac.VIEW, "never above the module max"
# role changes apply immediately; disabled role = no access
r = post(ca, "/roles/viewer", {"description": "x", "p_lookups": "0", "p_sources": "1", "p_recon": "1", "p_audit": "0", "p_users": "0", "p_roles": "0", "enabled": "on"}, path_for_token="/roles/viewer")
assert r.status_code == 302 and cv.get("/lookups").status_code == 403
st.put_user("view", {**st.get_user("view"), "overrides": "{}"}, by="t")
post(ca, "/roles/viewer", {"description": "x", "p_sources": "1"}, path_for_token="/roles/viewer"); assert cv.get("/sources").status_code == 403, "disabled role gives no access"
r = post(ca, "/roles/new", {"role_name": "recon-only", "description": "d", "p_recon": "1", "enabled": "on"}, path_for_token="/roles/new"); assert r.status_code == 302 and st.get_role("recon-only")
assert "already exists" in text(post(ca, "/roles/new", {"role_name": "admin", "enabled": "on"}, path_for_token="/roles/new"))
print("4 module access, 403, edit rights, overrides, max level, role changes: ok")

# 5. admin safeguards, reset, disable, audit
st, app = fresh(); ca, _ = signin(app)
full = {"display_name": "A", "role": "admin", "enabled": "on"}
assert "cannot disable your own" in text(post(ca, "/users/admin", {"display_name": "A", "role": "admin"}, path_for_token="/users/admin"))
r = post(ca, "/users/admin", {"display_name": "A", "role": "viewer", "enabled": "on"}, path_for_token="/users/admin"); assert "no enabled user who can manage" in text(r)
r = post(ca, "/roles/admin", {"description": "", "p_users": "1", "p_roles": "2", "p_lookups": "2", "enabled": "on"}, path_for_token="/roles/admin"); assert "remove your own access" in text(r)
r = post(ca, "/users/new", {"username": "view", "role": "viewer", "enabled": "on"}, path_for_token="/users/new"); assert "already exists" in text(r)
r = post(ca, "/users/new", {"username": "Bad Name!", "role": "viewer", "enabled": "on"}, path_for_token="/users/new"); assert "Username:" in text(r)
cv, _ = signin(app, "view"); assert cv.get("/").status_code == 200
r = post(ca, "/users/view/reset-password", path_for_token="/users/view"); assert "Password reset" in text(r); newtemp = re.search(r'class="secret">([^<]+)<', text(r)).group(1)
assert cv.get("/").status_code == 302, "reset ends the user's open sessions"
assert signin(app, "view", PW)[1].status_code == 200, "old password no longer works"
cv, r = signin(app, "view", newtemp); assert r.status_code == 302 and cv.get("/").headers["Location"].endswith("/account/password")
post(ca, "/users/ops", {"display_name": "O", "role": "operator"}, path_for_token="/users/ops")           # disable
co, r = signin(app, "ops"); assert r.status_code == 200 and "Incorrect username or password." in text(r), "disabled user: same generic message"
aud = text(ca.get("/audit")); assert all(x in aud for x in ("LOGIN_OK", "LOGIN_FAIL", "PASSWORD_RESET", "USER_CHANGED"))
assert "LOGIN_FAIL" in text(ca.get("/audit?event=login_fail")) and "LOGOUT" not in text(ca.get("/audit?event=login_fail"))
assert "PWD" not in aud and PW not in aud and "scrypt" not in aud, "no secrets in the audit log"
post(ca, "/logout", path_for_token="/"); assert ca.get("/").status_code == 302
print("5 admin safeguards, reset, disable, audit, logout: ok")
print("ALL GUI AUTH CHECKS PASSED")
