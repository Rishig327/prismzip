"""lookup-seed / lookup-set / lookup-show against an in-memory fake BigQuery.   python tests/test_lookup_admin.py"""
import datetime as dt, io, os, sys, types, contextlib
import _paths  # noqa: F401  (adds common/, orchestrator/, sources/* to sys.path)

class P:
    def __init__(self, *a, **k): self.a, self.k = a, k
bq = types.ModuleType("google.cloud.bigquery")
for n in ("ScalarQueryParameter", "ArrayQueryParameter", "StructQueryParameter", "ConnectionProperty",
          "EncryptionConfiguration", "QueryJobConfig", "Client"):
    setattr(bq, n, P)
st_ = types.ModuleType("google.cloud.storage"); st_.Client = P
g, gc = types.ModuleType("google"), types.ModuleType("google.cloud"); gc.bigquery, gc.storage = bq, st_; g.cloud = gc
sys.modules.update({"google": g, "google.cloud": gc, "google.cloud.bigquery": bq, "google.cloud.storage": st_})
gd = types.ModuleType("googleapiclient.discovery"); gd.build = lambda *a, **k: None
sys.modules.update({"googleapiclient": types.ModuleType("googleapiclient"), "googleapiclient.discovery": gd})

import config, config_store as cs, config_admin as ca      # noqa: E402

class Row(dict):
    def __getattr__(self, k): return self[k]
    def items(self): return dict.items(self)

class FakeBq:
    def __init__(self): self.rows_, self.clock = [], dt.datetime(2026, 10, 27, 8, tzinfo=dt.timezone.utc)
    def rows(self, sql, params=None):
        p = {x.a[0]: x.a[2] for x in (params or [])}
        rows = sorted(self.rows_, key=lambda r: r["changed_at"])
        if "LIMIT" in sql:
            return [Row(r) for r in reversed(rows) if r["lookup_name"] == p["k"]]
        cur = {}
        for r in rows: cur[r["lookup_name"]] = r
        return [Row(r) for r in cur.values()]
    def run(self, sql, params=None):
        assert sql.startswith("INSERT INTO") and "prism_lookup_config" in sql
        p = {x.a[0]: x.a[2] for x in params}
        self.clock += dt.timedelta(minutes=1)
        self.rows_.append({**{k: p[k] for k in ("lookup_name", "enabled", "table_name", "key_fields", "value_fields",
                                                  "match_type", "changed_by", "note")}, "changed_at": self.clock})

fake = FakeBq()
ca.store = lambda: cs.ConfigStore(fake, "p", "VPDB_ADM")
def cli(*args):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        rc = ca.main(list(args))
    return rc, out.getvalue(), err.getvalue()

st = ca.store()
# seed copies LOOKUP_SEEDS once, never overwrites
done = st.seed_lookups(config.LOOKUP_SEEDS, "t")
assert len(done) == len(config.LOOKUP_SEEDS) == 17 and st.seed_lookups(config.LOOKUP_SEEDS, "t") == []
assert st.latest_lookups()["lk_VFUK_R_UC_APN_LIST"]["key_fields"] == ["APN", "TYPE", "NETWORK"]

# show
rc, out, _ = cli("lookup-show", "lk_VFUK_R_UC_APN_LIST"); assert rc == 0 and "key=APN,TYPE,NETWORK" in out
# set: change, dry-run, no-op, history
rc, out, _ = cli("lookup-set", "lk_VFUK_R_UC_MVNO_IMSI", "match_type=EXACT", "--by", "me", "--dry-run")
assert rc == 0 and "dry run" in out and len(fake.rows_) == 17
rc, out, _ = cli("lookup-set", "lk_VFUK_R_UC_MVNO_IMSI", "match_type=exact", "--by", "me", "--note", "why")
assert "prefix' -> 'exact'" in out and len(fake.rows_) == 18
assert "no change" in cli("lookup-set", "lk_VFUK_R_UC_MVNO_IMSI", "match_type=exact", "--by", "me")[1]
rc, out, _ = cli("lookup-history", "lk_VFUK_R_UC_MVNO_IMSI"); assert "match_type" in out and "why" in out
# disable hides it from the default show
cli("lookup-set", "lk_VFUK_C_UC_PORTED", "enabled=false", "--by", "me")
assert "lk_VFUK_C_UC_PORTED" not in cli("lookup-show")[1] and "OFF" in cli("lookup-show", "--all")[1]
# errors: unknown name, bad values (all listed), --new needs every column
rc, _, err = cli("lookup-set", "lk_typo", "enabled=true", "--by", "me"); assert rc == 2 and "does not exist" in err
rc, _, err = cli("lookup-set", "lk_VFUK_C_UC_APN", "match_type=like", "key_fields=A B", "--by", "me")
assert rc == 2 and "match_type" in err and "key_fields" in err
rc, _, err = cli("lookup-set", "lk_new", "table_name=T", "--new", "--by", "me"); assert rc == 2 and "empty column key_fields" in err
rc, out, _ = cli("lookup-set", "lk_new", "table_name=T", "key_fields=K", "value_fields=V", "match_type=contains", "--new", "--by", "me")
assert rc == 0 and st.latest_lookups()["lk_new"]["enabled"] is True
print("OK")
