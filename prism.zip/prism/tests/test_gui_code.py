"""
Sources -> <source> -> Transformation code: permissions, view / download / XSS, the whole draft -> validate -> approve workflow with several
people, validation through the GUI, version history / diff / restore / discard, and the real PGW code from "edited in the GUI" to
"loadable by a worker".  In-memory table + sample runner; proves the code, not real BigQuery.      python tests/test_gui_code.py
"""
import json, re, sys
from _gui_helpers import fresh, signin, post, text, tok, PW
import code_dryrun, demo, pgw_schema, rbac
import transform_loader, transform_store as ts
import types
_beam = types.ModuleType("apache_beam"); _beam.DoFn = type("DoFn", (), {}); sys.modules.setdefault("apache_beam", _beam)      # not installed here; the worker image has the real one
LK = "lk_VFUK_R_UC_APN_LIST"
COL = [c for c, _ in pgw_schema.DETAIL_SCHEMA][0]
SMALL = f'''from LookupsManager import LookupManager


class transform_record:
    def setup(self):
        LookupManager.load_selected(["{LK}"])

    def process(self, row):
        out_row = {{}}
        out_row["{COL}"] = (row.get("a") or "").upper()
        yield dict(out_row)
'''
code_dryrun.TIMEOUT_SECONDS = 3

def build(seed=SMALL, many_lookups=False):
    cfg = demo.DemoConfig()
    if many_lookups:
        for n in re.findall(r'"(lk_[A-Za-z0-9_]+)": \{"table_name"', open("orchestrator/config.py", encoding="utf-8").read()):
            cfg.lookups[n] = {"enabled": True, "table_name": "T", "key_fields": ["K"], "value_fields": ["V"], "match_type": "exact", "changed_at": None, "changed_by": "t", "note": None}      # all 17, enabled (the demo config retires one)
    st, app, runner = fresh(cfg=cfg)
    base = rbac.clean({})
    st.put_role("code-view", "d", {**base, "sources": 1, "transform": 1}, True, "t")
    st.put_role("code-both", "d", {**base, "sources": 1, "transform": 2, "transform_approve": 2}, True, "t")
    for u, role in (("coder", "code-editor"), ("coder2", "code-editor"), ("appr", "code-approver"), ("tview", "code-view"), ("both", "code-both")):
        demo.new_user(st, u, PW, role)
    st.transform.seed("PGW", seed, "seed", "initial import")
    return st, app, cfg

def draft_rev(st): return st.transform.draft("PGW")["code_sha256"]
def save(c, st, body, action="save", rev=None, sample=""):
    return post(c, "/sources/PGW/code/save", {"code": body, "rev": rev or draft_rev(st), "action": action, "sample_rows": sample})
def step_ok(r): assert r.status_code in (200, 302), r.status_code; return r

st, app, cfg = build()
adm, coder, coder2, appr, tview, both, view = (signin(app, u) for u in ("admin", "coder", "coder2", "appr", "tview", "both", "view"))
tt = st.transform

# ============================================================ 1. permissions
READ = ["/sources/PGW/code", "/sources/PGW/code/view", "/sources/PGW/code/history", "/sources/PGW/code/diff", "/sources/PGW/code/download"]
for u in READ: assert view.get(u).status_code == 403, ("no Transformation code module", u)
for u in READ: assert tview.get(u).status_code == 200 and coder.get(u).status_code == 200 and appr.get(u).status_code == 200 and adm.get(u).status_code == 200, u
for who in (tview, appr): assert who.get("/sources/PGW/code/edit").status_code == 403, "viewing or approving is not editing"
for who in (coder, coder2, both, adm): assert who.get("/sources/PGW/code/edit").status_code == 200
for path in ("start", "save", "discard"): assert post(tview, f"/sources/PGW/code/{path}", {"code": SMALL}).status_code == 403, path
assert post(tview, "/sources/PGW/code/approve").status_code == 403 and post(coder, "/sources/PGW/code/approve").status_code == 403, "editing is not approving"
assert post(tview, "/sources/PGW/code/restore/1").status_code == 403 and post(appr, "/sources/PGW/code/start").status_code == 403 and post(appr, "/sources/PGW/code/save", {"code": SMALL}).status_code == 403
assert post(view, "/sources/PGW/code/start").status_code == 403
for bad in ("/sources/NOPE/code", "/sources/PGW%2F..%2Fx/code", "/sources/1bad/code", "/sources/PGW/code/view?version=9", "/sources/PGW/code/view?version=abc", "/sources/PGW/code/view?version=draft"):
    assert tview.get(bad).status_code == 404, bad
assert "Transformation code" in text(tview.get("/sources/PGW")) and "Transformation code" not in text(view.get("/sources/PGW"))
assert coder.post("/sources/PGW/code/start", data={}).status_code == 400, "CSRF token required"
print("1 permissions: View / Edit / Approve are separate; unknown sources and versions are 404; CSRF: ok")

# ============================================================ 2. view, download, escaping
p = text(tview.get("/sources/PGW/code/view")); assert 'class="kw">class</span>' in p and 'id="L1"' in p and f'id="L{len(SMALL.splitlines())}"' in p and "v1" in p and "seed" in p
r = tview.get("/sources/PGW/code/download"); assert r.mimetype == "text/x-python" and r.get_data(as_text=True) == SMALL and 'filename="transformation_PGW_v1.py"' in r.headers["Content-Disposition"]
assert any(e["event"] == "TRANSFORM_DOWNLOADED" for e in st.events)
tt.seed("XSS", 'x = "</pre><script>alert(1)</script><img src=x onerror=alert(2)>"\nclass transform_record:\n    def process(self, row):\n        yield {}\n', "seed")
p = text(adm.get("/sources/XSS/code/view")); assert "<script>alert" not in p and "&lt;script&gt;alert(1)" in p and "<img src=x" not in p, "code is shown as text, never as markup"
home = text(tview.get("/sources/PGW/code")); assert "v1" in home and "current" in home.lower() and "No draft" in home and "Edit" not in home.split("Versions")[0].replace("Editing", ""), "a viewer sees no edit button"
print("2 highlighted viewer with line numbers, download, HTML in code is escaped: ok")

# ============================================================ 3. the workflow with several people
assert "Start a draft from v1" in text(coder.get("/sources/PGW/code/edit"))
step_ok(post(coder, "/sources/PGW/code/start")); d = tt.draft("PGW"); assert d["edited_by"] == "coder" and d["version"] == 1 and d["code"] == SMALL
assert "already open" in text(coder2.get(post(coder2, "/sources/PGW/code/start").headers["Location"])), "only one draft at a time"
page = text(coder2.get("/sources/PGW/code/edit")); assert "class transform_record" in page and f'name="rev" value="{d["code_sha256"]}"' in page and "last change by <b>coder</b>" in page.replace("Last change by", "last change by"), "everyone edits the same draft"
old_rev = draft_rev(st)
step_ok(save(coder2, st, SMALL + "# coder2 was here\n", rev=old_rev)); d2 = tt.draft("PGW"); assert d2["edited_by"] == "coder2" and d2["code"].endswith("# coder2 was here\n") and d2["validation_ok"] is None
r = save(coder, st, SMALL + "# coder wanted this\n", rev=old_rev)                       # coder still has the old text
assert r.status_code == 409 and "Not saved" in text(r) and "# coder wanted this" in text(r) and f'name="rev" value="{d2["code_sha256"]}"' in text(r) and tt.draft("PGW")["edited_by"] == "coder2", "stale save: nothing written, your text kept"
assert any(e["event"] == "TRANSFORM_SAVE_CONFLICT" for e in st.events)
step_ok(save(coder, st, SMALL + "# coder wanted this\n", rev=d2["code_sha256"])); assert tt.draft("PGW")["edited_by"] == "coder", "after seeing it, saving again is the user's decision"
assert "No changes to save" in text(coder.get(save(coder, st, tt.draft("PGW")["code"]).headers["Location"]))
# validation: a broken draft cannot be approved
r = save(coder, st, "def (:\n    pass\n", action="validate"); t = text(r); assert r.status_code == 200 and "Failed" in t and "Syntax error" in t and "Test run:" not in t
assert tt.draft("PGW")["validation_ok"] is False
def approve_button(c): return re.search(r'<button class="btn"([^>]*)>Approve as v\d+</button>', text(c.get("/sources/PGW/code"))).group(1)
assert "disabled" in approve_button(appr), "the Approve button is disabled while validation has not passed"
assert "not passed validation" in text(appr.get(post(appr, "/sources/PGW/code/approve").headers["Location"])) and tt.current_approved("PGW")["version"] == 1
good = SMALL + "# approved change\n"
r = save(coder, st, good, action="validate"); t = text(r); assert "Validation passed" in t and "Passed" in t and "Test run:" in t and tt.draft("PGW")["validation_ok"] is True
step_ok(save(both, st, good + "# one more\n")); assert tt.draft("PGW")["validation_ok"] is None, "any edit clears the validation"
assert "Test run:" in text(save(both, st, good + "# one more\n", action="validate"))
assert "someone else must approve" in text(both.get(post(both, "/sources/PGW/code/approve").headers["Location"])) and tt.current_approved("PGW")["version"] == 1, "four eyes: the last editor cannot approve"
assert "disabled" not in approve_button(appr) and "disabled" in approve_button(both), "enabled for a different approver, disabled for the last editor"
assert "Approve as" not in text(coder.get("/sources/PGW/code")) and "Approve as" not in text(tview.get("/sources/PGW/code")), "editors and viewers get no approve button"
r = post(appr, "/sources/PGW/code/approve", {"note": "reviewed the diff"}); step_ok(r)
cur = tt.current_approved("PGW"); assert cur["version"] == 2 and cur["approved_by"] == "appr" and cur["edited_by"] == "both" and cur["note"] == "reviewed the diff" and cur["code"] == good + "# one more\n" and tt.draft("PGW") is None
assert "v2" in text(tview.get("/sources/PGW/code")) and "reviewed the diff" in text(tview.get("/sources/PGW/code")) and "Start a draft from v2" in text(coder.get("/sources/PGW/code/edit"))
h = text(tview.get("/sources/PGW/code/history")); assert "v1" in h and "v2" in h and "APPROVED / approve" in h and "DRAFT / validate" in h and "DRAFT / save" in h and "Restore as draft" not in h, "a viewer cannot restore"
df = text(tview.get("/sources/PGW/code/diff?a=1&b=2")); assert 'class="add"' in df and "# approved change" in df and "# one more" in df and 'class="del"' not in df
assert text(tview.get("/sources/PGW/code/view?version=1")) != text(tview.get("/sources/PGW/code/view?version=2")) and tview.get("/sources/PGW/code/diff?a=2&b=2").status_code == 200 and "identical" in text(tview.get("/sources/PGW/code/diff?a=2&b=2"))
print("3 one shared draft, save conflict keeps your text, validation clears on edit, four-eyes, approve -> v2, history and diff: ok")

# ============================================================ 4. restore, discard, identical, stale lookups
assert "Restore as draft" in text(coder.get("/sources/PGW/code/history"))
step_ok(post(coder, "/sources/PGW/code/restore/1")); assert tt.draft("PGW")["code"] == SMALL and tt.draft("PGW")["kind"] == "restore"
assert "already open" in text(coder.get(post(coder, "/sources/PGW/code/restore/1").headers["Location"])) and "Restore as draft" not in text(coder.get("/sources/PGW/code/history"))
step_ok(save(coder, st, SMALL, action="validate")); step_ok(post(appr, "/sources/PGW/code/approve", {"note": "back to the original"}))
assert tt.current_approved("PGW")["version"] == 3 and tt.current_approved("PGW")["code"] == SMALL and [v["version"] for v in tt.approved_versions("PGW")] == [3, 2, 1], "restoring approves as a NEW version"
step_ok(post(coder, "/sources/PGW/code/start")); assert post(tview, "/sources/PGW/code/discard").status_code == 403
step_ok(post(appr, "/sources/PGW/code/discard")); assert tt.draft("PGW") is None and tt.current_approved("PGW")["version"] == 3, "an approver may discard; the current version is untouched"
step_ok(post(coder, "/sources/PGW/code/start")); step_ok(save(coder, st, SMALL, action="validate"))
assert "identical to version 3" in text(appr.get(post(appr, "/sources/PGW/code/approve").headers["Location"])) and tt.current_approved("PGW")["version"] == 3
step_ok(save(coder, st, SMALL + "# lookups may change\n", action="validate")); assert tt.draft("PGW")["validation_ok"]
cfg.lookups[LK]["enabled"] = False                                                      # someone disables the lookup the code uses AFTER validation
r = appr.post("/sources/PGW/code/approve", data={"csrf_token": tok(appr)}); assert r.status_code == 302 and tt.current_approved("PGW")["version"] == 3, "approval re-checks the code against today's lookups"
assert "no longer passes the checks" in text(appr.get(r.headers["Location"]))
cfg.lookups[LK]["enabled"] = True
step_ok(post(coder, "/sources/PGW/code/discard"))
print("4 restore -> new version, discard, identical code refused, a lookup disabled after validation blocks approval: ok")

# ============================================================ 5. validation through the GUI
step_ok(post(coder, "/sources/PGW/code/start"))
def validate(body, sample=""): return text(save(coder, st, body, action="validate", sample=sample))
t = validate(SMALL.replace("from LookupsManager", "import os\nfrom LookupsManager")); assert "not allowed in transformation code" in t and "Test run:" not in t and tt.draft("PGW")["validation_ok"] is False, "a static error stops before the test run"
t = validate(SMALL.replace(LK, "lk_DOES_NOT_EXIST")); assert "lk_DOES_NOT_EXIST" in t and "not defined (or is disabled)" in t and tt.draft("PGW")["validation_ok"] is False
t = validate(SMALL.replace(f'out_row["{COL}"]', 'out_row["NOT_A_COLUMN"]')); assert tt.draft("PGW")["validation_ok"] is True and "NOT_A_COLUMN" in t and "ignored" in t, "an output column outside the schema is a warning, not a blocker"
t = validate(SMALL, sample="not json"); assert "not valid JSON" in t and tt.draft("PGW")["code"] == SMALL, "bad sample text is reported; the code was still saved"
t = validate(SMALL, sample='[{"a": "x"}]'); assert "your record 1" not in t and "Test run:" in t and tt.draft("PGW")["validation_ok"] is True
t = validate(SMALL.replace("yield dict(out_row)", "while True:\n            pass\n        yield dict(out_row)")); assert "longer than 3 seconds" in t and tt.draft("PGW")["validation_ok"] is False, "an endless loop cannot hang the GUI"
t = validate(SMALL.replace("yield dict(out_row)", "yield 5")); assert "not dicts" in t and tt.draft("PGW")["validation_ok"] is False
t = validate(SMALL.replace('(row.get("a") or "")', 'typo_variable')); assert "typo_variable" in t and "never defined" in t and "Test run:" not in t
step_ok(post(coder, "/sources/PGW/code/discard"))
ev = {e["event"] for e in st.events}
for need in ("TRANSFORM_DRAFT_STARTED", "TRANSFORM_DRAFT_SAVED", "TRANSFORM_VALIDATED", "TRANSFORM_APPROVED", "TRANSFORM_DRAFT_DISCARDED", "TRANSFORM_RESTORED", "TRANSFORM_SAVE_CONFLICT", "TRANSFORM_APPROVE_REFUSED"): assert need in ev, need
assert "class transform_record" not in json.dumps([e["detail"] for e in st.events]) and "# approved change" not in json.dumps([e["detail"] for e in st.events]), "the audit log records WHO and WHICH version, never the code"
print("5 validation in the GUI: forbidden imports, unknown lookups, schema warnings, bad sample JSON, endless loop, non-dict yield, typos; audit has no code: ok")

# ============================================================ 6. CSP / scripts on the code pages
r = coder.get("/sources/PGW/code/edit"); assert r.status_code == 200
step_ok(post(coder, "/sources/PGW/code/start")); r = coder.get("/sources/PGW/code/edit"); html = text(r)
assert "script-src 'self';" in r.headers["Content-Security-Policy"] and "unsafe-inline" not in r.headers["Content-Security-Policy"].split("script-src")[1].split(";")[0]
for m in re.finditer(r"<script\b[^>]*>", html): assert 'src="/static/code_editor.js"' in m.group(0), m.group(0)
assert not re.search(r"\son[a-z]+\s*=", html) and "javascript:" not in html.lower()
assert "script-src 'none'" in coder.get("/sources").headers["Content-Security-Policy"] and "script-src 'none'" in coder.get("/").headers["Content-Security-Policy"]
step_ok(post(coder, "/sources/PGW/code/discard"))
print("6 only /static/code_editor.js may run, and only on the code pages: ok")

# ============================================================ 7. the REAL PGW code: edited in the GUI, approved, loadable by a worker
real = open("sources/pgw/seed/transformation_PGW.v1.py", encoding="utf-8").read()
st, app, cfg = build(seed=real, many_lookups=True); tt = st.transform
coder, appr = signin(app, "coder"), signin(app, "appr")
step_ok(post(coder, "/sources/PGW/code/start"))
code2 = real.replace("class transform_record", "# approved in the GUI\nclass transform_record", 1)
r = save(coder, st, code2, action="validate", rev=tt.draft("PGW")["code_sha256"]); t = text(r)
assert tt.draft("PGW")["validation_ok"] is True and "Passed" in t and "filename" in t and "PORTED" in t and "Test run: 3 of 4" in t and "0 error" in t, t[t.find("Validation"):][:600]
rep = json.loads(tt.draft("PGW")["validation_report"]); assert rep["errors"] == 0 and rep["stats"]["lines"] == len(code2.splitlines()) and len(rep["stats"]["lookups"]) == 17
step_ok(post(appr, "/sources/PGW/code/approve", {"note": "comment only"})); cur = tt.current_approved("PGW"); assert cur["version"] == 2 and cur["code"] == code2
transform_loader.set_table(tt)
from LookupsManager import LookupManager
LookupManager.load_selected = classmethod(lambda cls, names: None)
LookupManager.get_lookup = classmethod(lambda cls, name, *k, default=None: {"VALUE": "7"} if name.startswith("lk_VFUK_C_UC_") else (default if default is not None else {}))
inst = transform_loader.load_transform("PGW", 2, cur["code_sha256"]); out = list(inst.process({})); assert out and isinstance(out[0], dict), "version 2, approved in the GUI, runs on a worker"
assert transform_loader.load_transform("PGW", 1, ts.sha256(real)) is not None
print("7 real PGW code: edit -> validate (0 errors; the 2 known schema warnings; test run) -> approve -> loaded and run by the worker loader: ok")
print("ALL GUI CODE CHECKS PASSED")
