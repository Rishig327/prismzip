"""Imported first by every test and check: puts common/, orchestrator/, gui/ and sources/* on sys.path, the same way
the images put them side by side. (Production code never imports this.)"""
import glob
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
FOLDERS = [os.path.join(ROOT, "common"), os.path.join(ROOT, "orchestrator"), os.path.join(ROOT, "gui")] + sorted(glob.glob(os.path.join(ROOT, "sources", "*")))
for _p in reversed(FOLDERS):
    if _p not in sys.path:
        sys.path.insert(0, _p)
