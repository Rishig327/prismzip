"""
Transformation code table: the draft / validate / approve / restore rules (in memory) and the BigQuery SQL plumbing (fake client).
    python tests/test_transform_store.py
"""
import types, sys
import _paths  # noqa: F401

class _P:
    def __init__(self, *a, **k): self.a, self.k = a, k
class _QJC:
    def __init__(self, **k): self.__dict__.update(k)
bq = types.ModuleType("google.cloud.bigquery")
bq.ScalarQueryParameter = bq.ArrayQueryParameter = lambda *a: tuple(a)
bq.EncryptionConfiguration = lambda **k: ("ENC", k.get("kms_key_name")); bq.QueryJobConfig = _QJC
class _Client:
    def __init__(self, **k): self.k, self.seen = k, []
    def query(self, sql, job_config=None):
        self.seen.append((sql, job_config))
        return types.SimpleNamespace(result=lambda: [])
bq.Client = _Client
g, gc = types.ModuleType("google"), types.ModuleType("google.cloud"); gc.bigquery = bq; g.cloud = gc
sys.modules.update({"google": g, "google.cloud": gc, "google.cloud.bigquery": bq})

import transform_store as ts                                  # noqa: E402

CODE = "class transform_record:\n    def process(self, row):\n        yield {}\n"
def fails(fn, exc, text, *a, **k):
    try: fn(*a, **k)
    except exc as e: assert text in str(e), (text, str(e)); return
    raise AssertionError(f"expected {exc.__name__} containing {text!r}")

# ============================================================ 1. the rules
t = ts.MemoryTransformTable()
fails(t.require_current, ts.TransformUnavailable, "no approved transformation code", "PGW")
for bad, why in (("", "empty"), ("   \n", "empty"), ("x\x00y", "NUL"), ("a" * (ts.MAX_CODE_BYTES + 1), "larger than")):
    fails(t.seed, ts.TransformError, why, "PGW", bad, "seed")
assert t.seed("PGW", CODE, "seed") == 1 and t.current_approved("PGW")["version"] == 1 and t.draft("PGW") is None
fails(t.seed, ts.TransformError, "already has", "PGW", CODE, "seed")
assert t.current_approved("PGW")["approved_by"] == "seed" and t.get_approved("PGW", 1)["code_sha256"] == ts.sha256(CODE) and t.get_approved("PGW", 9) is None

d = t.start_draft("PGW", "alice"); assert d["version"] == 1 and d["code"] == CODE and d["edited_by"] == "alice" and d["validation_ok"] is None and t.draft("PGW")
fails(t.start_draft, ts.TransformError, "already open", "PGW", "bob")
n = len(t.rows["PGW"]); same = t.save_draft("PGW", CODE, "alice", d["code_sha256"]); assert len(t.rows["PGW"]) == n, "saving unchanged text writes nothing"
code2 = CODE + "# change 1\n"
d2 = t.save_draft("PGW", code2, "alice", d["code_sha256"]); assert d2["code"] == code2 and d2["kind"] == "save" and d2["version"] == 1
fails(t.save_draft, ts.Conflict, "changed by alice", "PGW", "x = 1\n", "bob", d["code_sha256"])           # bob still has the OLD text
d3 = t.save_draft("PGW", code2 + "# bob\n", "bob", d2["code_sha256"]); assert d3["edited_by"] == "bob", "same draft, now edited by bob"
assert sum(1 for r in t.rows["PGW"] if r["state"] == "DRAFT" and r["kind"] == "start") == 1, "there is still only one draft"
fails(t.approve, ts.TransformError, "not passed validation", "PGW", "carol")
v = t.record_validation("PGW", "bob", False, {"errors": 1}); assert v["validation_ok"] is False and v["edited_by"] == "bob" and v["changed_by"] == "bob"
fails(t.approve, ts.TransformError, "not passed validation", "PGW", "carol")
d4 = t.save_draft("PGW", code2 + "# bob 2\n", "bob", t.draft("PGW")["code_sha256"]); assert d4["validation_ok"] is None, "any edit clears the validation"
t.record_validation("PGW", "dave", True, {"errors": 0}); assert t.draft("PGW")["edited_by"] == "bob", "validating does not change who edited"
fails(t.approve, ts.TransformError, "someone else must approve", "PGW", "bob")

n = len(t.rows["PGW"]); v2 = t.approve("PGW", "carol", "reviewed"); assert v2 == 2 and t.draft("PGW") is None, "approving closes the draft"
cur = t.current_approved("PGW"); assert cur["version"] == 2 and cur["approved_by"] == "carol" and cur["edited_by"] == "bob" and cur["code"] == code2 + "# bob 2\n" and cur["validation_ok"] is True and cur["note"] == "reviewed"
assert t.get_approved("PGW", 1)["code"] == CODE, "the old version is untouched"
fails(t.approve, ts.TransformError, "no open draft", "PGW", "carol"); fails(t.discard, ts.TransformError, "no open draft", "PGW", "carol")
fails(t.save_draft, ts.TransformError, "no open draft", "PGW", CODE, "bob", None); fails(t.record_validation, ts.TransformError, "no open draft", "PGW", "bob", True, {})

# next edit starts from the new current version; discard leaves the current version alone
d = t.start_draft("PGW", "alice"); assert d["version"] == 2 and d["code"] == cur["code"]
fails(t.approve, ts.TransformError, "not passed validation", "PGW", "carol")
t.record_validation("PGW", "alice", True, {}); fails(t.approve, ts.TransformError, "identical to version 2", "PGW", "carol")
t.discard("PGW", "alice"); assert t.draft("PGW") is None and t.current_approved("PGW")["version"] == 2 and t.latest("PGW")["state"] == "DISCARDED"

# restore an old version: it becomes a draft, and approving it creates a NEW number (history stays linear)
r = t.restore_as_draft("PGW", 1, "alice"); assert r["code"] == CODE and r["kind"] == "restore" and r["version"] == 2
fails(t.restore_as_draft, ts.TransformError, "already open", "PGW", 1, "bob")
t.record_validation("PGW", "alice", True, {}); assert t.approve("PGW", "carol") == 3 and t.current_approved("PGW")["code"] == CODE
fails(t.restore_as_draft, ts.TransformUnavailable, "does not exist", "PGW", 7, "bob")
assert [v["version"] for v in t.approved_versions("PGW")] == [3, 2, 1] and all("code" not in v for v in t.approved_versions("PGW"))
ev = t.events("PGW", 100); assert all("code" not in e and "validation_report" not in e for e in ev) and ev[0]["kind"] == "approve"
# one source never sees another's rows
t.seed("TAP", CODE, "seed"); assert t.current_approved("TAP")["version"] == 1 and t.draft("PGW") is None and len(t.approved_versions("TAP")) == 1
t.start_draft("TAP", "x"); assert t.draft("PGW") is None and t.draft("TAP")
print("1 draft / save / conflict / validate / four-eyes / approve / discard / restore rules: ok")

# ============================================================ 2. BigQuery plumbing (fake client)
class Row(dict):
    def items(self): return dict.items(self)
class FakeBq:
    def __init__(self): self.sql, self.params, self.result = [], [], []
    def run(self, sql, params=None): self.sql.append(sql); self.params.append({p[0]: p[2] for p in (params or [])})
    def rows(self, sql, params=None): self.sql.append(sql); self.params.append({p[0]: p[2] for p in (params or [])}); return self.result
fb = FakeBq(); bt = ts.TransformTable(fb, "proj", "VPDB_ADM")
bt._insert(bt._row("PGW", "DRAFT", "save", 3, CODE, "alice", "n", edited_by="alice"))
sql, p = fb.sql[-1], fb.params[-1]
import re
m = re.search(r"\(([^)]*)\) VALUES \((.*)\)$", sql); names = [x.strip() for x in m.group(1).split(",")]; vals = [x.strip() for x in m.group(2).split(",")]
assert names[-1] == "changed_at" and vals[-1] == "CURRENT_TIMESTAMP()" and [v[1:] for v in vals[:-1]] == names[:-1] and set(p) == set(names[:-1]), sql
assert "`proj.VPDB_ADM.prism_transform_code`" in sql and p["source_type"] == "PGW" and p["version"] == 3 and p["code"] == CODE and p["code_sha256"] == ts.sha256(CODE) and p["edited_by"] == "alice"
fb.result = [Row(source_type="PGW", state="APPROVED", version=4, code=CODE, code_sha256=ts.sha256(CODE))]
assert bt.current_approved("PGW")["version"] == 4 and "state = 'APPROVED'" in fb.sql[-1] and "ORDER BY version DESC" in fb.sql[-1] and fb.params[-1] == {"s": "PGW"}
bt.get_approved("PGW", "5"); assert fb.params[-1] == {"s": "PGW", "v": 5} and "version = @v" in fb.sql[-1]
bt.latest("PGW"); assert "ORDER BY changed_at DESC LIMIT 1" in fb.sql[-1]
fb.result = [Row(state="DRAFT", code="x")]; assert bt.draft("PGW")["state"] == "DRAFT"
fb.result = [Row(state="APPROVED", code="x")]; assert bt.draft("PGW") is None, "a draft is open only when the NEWEST row is a draft"
bt.approved_versions("PGW", 5); assert "EXCEPT(code)" in fb.sql[-1] and "LIMIT 5" in fb.sql[-1]; bt.events("PGW", 7); assert "EXCEPT(code, validation_report)" in fb.sql[-1] and "LIMIT 7" in fb.sql[-1]
fb.result = []; assert bt.current_approved("PGW") is None
fails(bt.require_current, ts.TransformUnavailable, "no approved transformation code", "PGW")
sb = ts.SimpleBq("proj", "europe-west2", "projects/k"); sb.rows("SELECT 1", []); sql, cfg = sb.client.seen[-1]
assert cfg.destination_encryption_configuration == ("ENC", "projects/k") and sb.client.k == {"project": "proj", "location": "europe-west2"}, "CMEK key attached like every other PRISM job"
print("2 BigQuery SQL, parameters, newest-row-decides rule, CMEK: ok")
print("ALL TRANSFORM STORE CHECKS PASSED")
