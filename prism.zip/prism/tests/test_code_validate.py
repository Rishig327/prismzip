"""
Validator (static checks), sandboxed test run, highlighter and diff - and: the REAL PGW transformation code passes them.
    python tests/test_code_validate.py
"""
import re, sys
import _paths  # noqa: F401
import code_dryrun as dr, code_validate as cv, pyhighlight as hl
import pgw_schema

GOOD = '''
import re
from LookupsManager import LookupManager

class transform_record:
    def setup(self):
        LookupManager.load_selected(["lk_APN"])

    def process(self, row):
        out_row = {}
        out_row["APN"] = (row.get("apn") or "").upper()
        out_row["COUNT"] = int(row["n"]) if row.get("n") else 0
        out_row["GROUP"] = LookupManager.get_lookup("lk_APN", out_row["APN"], default={}).get("G")
        yield dict(out_row)
'''
SCHEMA = ["APN", "COUNT", "GROUP", "OTHER"]
LK = {"lk_APN", "lk_B"}

def rep(code, schema=SCHEMA, lk=LK): return cv.validate(code, schema, lk)
def has(r, level, rule, text=""): return any(f["level"] == level and f["rule"] == rule and text in f["message"] for f in r["findings"])
def clean(r, *rules): return not any(f["rule"] in rules and f["level"] in ("error", "warning") for f in r["findings"])

# ============================================================ 1. the good example and the basics
r = rep(GOOD); assert r["ok"] and r["errors"] == 0 and r["stats"]["output_columns"] == ["APN", "COUNT", "GROUP"] and r["stats"]["input_fields"] == ["apn", "n"] and r["stats"]["lookups"] == ["lk_APN"], r
assert has(r, "info", "schema", "OTHER"), "a column nobody sets is mentioned as a note"
for bad, text in (("", "empty"), ("   \n", "empty"), ("x" * (cv.MAX_BYTES + 1), "larger than")):
    r = rep(bad); assert not r["ok"] and has(r, "error", "syntax", text), text
r = rep("def broken(:\n    pass\n"); assert not r["ok"] and has(r, "error", "syntax", "Syntax error") and r["findings"][0]["line"] == 1
r = rep("class transform_record:\n    def process(self, row):\n        if row:\n            yield {}\n          bad = 1\n"); assert has(r, "error", "syntax")
print("1 good code passes; empty / too large / syntax errors are errors with a line: ok")

# ============================================================ 2. interface
r = rep("x = 1\n"); assert has(r, "error", "interface", "class named transform_record")
r = rep("class transform_record:\n    pass\n"); assert has(r, "error", "interface", "no process")
r = rep("class transform_record:\n    def process(self):\n        yield {}\n"); assert has(r, "error", "interface", "must take the record")
r = rep("class transform_record:\n    def process(self, row):\n        return [{}]\n"); assert r["ok"] and has(r, "warning", "interface", "never yields")
r = rep("class transform_record:\n    def setup(self, extra):\n        pass\n    def process(self, row):\n        yield {}\n"); assert has(r, "warning", "interface", "without arguments")
print("2 class transform_record, process(self, row), yields, setup(self): ok")

# ============================================================ 3. imports, calls, dunders
def body(extra): return "import re\n" + extra + "\nclass transform_record:\n    def process(self, row):\n        yield {}\n"
for imp in ("import os", "import subprocess", "import sys, re", "from os import path", "from urllib.request import urlopen", "import socket as s", "import pickle", "from pathlib import Path"):
    assert has(rep(body(imp)), "error", "imports", "not allowed"), imp
assert has(rep(body("from . import x")), "error", "imports", "Relative")
r = rep(body("import numpy")); assert r["ok"] and has(r, "warning", "imports", "numpy")
for ok_imp in ("import math", "import json", "from datetime import datetime", "import apache_beam as beam", "from LookupsManager import LookupManager", "from decimal import Decimal", "import collections"):
    assert clean(rep(body(ok_imp)), "imports"), ok_imp
for call in ("eval('1')", "exec('x=1')", "open('/etc/passwd')", "__import__('os')", "compile('1','a','eval')", "input()", "globals()", "breakpoint()"):
    assert has(rep(body(f"x = {call}")), "error", "calls", "not allowed") or has(rep(body(f"x = {call}")), "error", "calls"), call
assert clean(rep(body("p = re.compile('a')")), "calls"), "re.compile is fine"
for d in ("x = ().__class__.__bases__", "y = [].__class__.__subclasses__", "z = __builtins__"):
    assert has(rep(body(d)), "error", "calls"), d
print("3 forbidden imports / calls / dunders are errors, usual imports pass, unusual ones warn: ok")

# ============================================================ 4. undefined names (typos), without false alarms
def names_of(code): return {f["message"].split("'")[1] for f in cv.validate(code)["findings"] if f["rule"] == "names"}
def mod(inner): return "class transform_record:\n    def process(self, row):\n" + "".join("        " + l + "\n" for l in inner.strip().split("\n")) + "        yield {}\n"
assert names_of(mod("out_row = {}\nout_rwo = 1\nprint_me = out_rwo + typo_name")) == {"typo_name"}
r = cv.validate(mod("out_row = {}\nout_row['a'] = out_rw")); f = [x for x in r["findings"] if x["rule"] == "names"][0]; assert "did you mean 'out_row'" in f["message"] and f["line"] == 4 and not r["ok"]
OKS = ["x = [i * 2 for i in range(3)]", "x = {k: v for k, v in zip('ab', 'cd')}", "f = lambda a, b=2: a + b + len('x')", "try:\n    pass\nexcept Exception as e:\n    y = str(e)",
       "def inner(a):\n    return a + 1\nz = inner(2)", "for i, (a, b) in enumerate([(1, 2)]):\n    z = a + b + i", "if (n := 3) > 2:\n    z = n", "import re as r2\nz = r2.compile('a')",
       "z = sum(x for x in range(3) if x)", "a = b = 1\nz = a + b", "with_ = 1\nz = with_", "total = 0\ndef bump():\n    nonlocal_ = 1\n    return nonlocal_\nz = bump() + total",
       "z = [(i, j) for i in range(2) for j in range(i)]", "z = __name__"]
for ok in OKS: assert names_of(mod(ok)) == set(), (ok, names_of(mod(ok)))
assert names_of("HELPER = {'a': 1}\ndef helper(x):\n    return HELPER.get(x)\nclass transform_record:\n    def process(self, row):\n        yield {'v': helper('a')}\n") == set(), "module-level names are visible in methods"
assert names_of("def late():\n    return LATER\nLATER = 1\nclass transform_record:\n    def process(self, row):\n        yield {}\n") == set(), "defined later at module level is fine"
assert names_of("def f(x=missing_default):\n    return x\nclass transform_record:\n    def process(self, row):\n        yield {}\n") == {"missing_default"}, "defaults are evaluated outside"
assert names_of("from os import *\nclass transform_record:\n    def process(self, row):\n        yield {'a': whatever}\n") == set(), "a star import makes names unknowable: not judged"
assert names_of(mod("match row:\n    case {'a': v}:\n        z = v\n    case _:\n        z = 0")) == set(), "match captures bind names"
print("4 undefined-name check: finds typos with a suggestion, no false alarms on the usual constructs: ok")

# ============================================================ 5. output columns vs schema, lookups
SRC = lambda lines: "class transform_record:\n    def process(self, row):\n        out_row = {}\n" + "".join("        " + l + "\n" for l in lines) + "        yield dict(out_row)\n"
r = rep(SRC(['out_row["APN"] = 1', 'out_row["COUNTT"] = 2', 'out_row["file_id"] = 3'])); assert r["ok"]
assert has(r, "warning", "schema", "COUNTT") and has(r, "warning", "schema", "did you mean 'COUNT'") and has(r, "warning", "schema", "added by PRISM"), r["findings"]
r = rep(SRC(['out_row.update({"APN": 1, "ZZ": 2})', 'out_row.setdefault("COUNT", 0)'])); assert has(r, "warning", "schema", "ZZ") and r["stats"]["output_columns"] == ["APN", "COUNT", "ZZ"]
r = rep("class transform_record:\n    def process(self, row):\n        result = {'APN': 1}\n        result['NOPE'] = 2\n        yield result\n"); assert r["stats"]["output_columns"] == ["APN", "NOPE"], "follows the variable that is yielded"
r = rep(SRC(['for col in ("GROUP", "OTHER"):', '    out_row[col] = 1'])); assert not has(r, "info", "schema", "OTHER"), "columns named in the code are not reported as never set"
r = cv.validate(GOOD, None, LK); assert has(r, "info", "schema", "not available") and r["ok"]
r = rep(SRC(['out_row["APN"] = LookupManager.get_lookup("lk_UNKNOWN", 1)', '# lk_ONLY_IN_A_COMMENT'])); assert has(r, "error", "lookups", "lk_UNKNOWN") and not any("COMMENT" in f["message"] for f in r["findings"]) and not r["ok"]
assert [f["line"] for f in r["findings"] if f["rule"] == "lookups"] == [4]
assert has(rep(SRC(['x = "lk_B"'])), "info", "schema") and clean(rep(SRC(['x = "lk_B"'])), "lookups")
r = cv.validate(SRC(['x = "lk_B"']), SCHEMA, None); assert has(r, "info", "lookups", "not available") and r["ok"]
print("5 output columns vs schema (did you mean), lookup names vs the lookup table: ok")

# ============================================================ 6. style warnings
def sty(code): return {f["message"][:14] for f in cv.validate(code)["findings"] if f["rule"] == "style"}
S = lambda l: SRC([l]); T = lambda l: "class transform_record:\n    def process(self, row):\n" + "".join("        " + x + "\n" for x in l) + "        yield {}\n"
assert has(cv.validate(T(["try:", "    pass", "except:", "    pass"])), "warning", "style", "Bare 'except:'")
assert clean(cv.validate(T(["try:", "    pass", "except Exception:", "    pass"])), "style")
assert has(cv.validate(S("print(1)")), "warning", "style", "print()") and has(cv.validate("g = 1\nclass transform_record:\n    def process(self, row):\n        global g\n        yield {}\n"), "warning", "style", "global")
assert has(cv.validate("class transform_record:\n    def process(self, row, acc=[]):\n        yield {}\n"), "warning", "style", "Mutable default")
assert has(cv.validate(T(["while True:", "    x = 1"])), "warning", "style", "loop forever") and clean(cv.validate(T(["while True:", "    break"])), "style")
assert has(cv.validate("import time\n" + T(["time.sleep(1)"])), "warning", "style", "sleep")
print("6 style warnings (bare except, print, global, mutable default, endless loop, sleep): ok")

# ============================================================ 7. the REAL PGW code
code = open("sources/pgw/seed/transformation_PGW.v1.py", encoding="utf-8").read()
schema = [c for c, _ in pgw_schema.DETAIL_SCHEMA]
seeded = set(re.findall(r'"(lk_[A-Za-z0-9_]+)": \{"table_name"', open("orchestrator/config.py", encoding="utf-8").read()))
r = cv.validate(code, schema, seeded)
assert r["ok"] and r["errors"] == 0, [f for f in r["findings"] if f["level"] == "error"]
assert set(r["stats"]["lookups"]) <= seeded and len(r["stats"]["lookups"]) == 17 and len(r["stats"]["output_columns"]) > 40 and len(r["stats"]["input_fields"]) >= 10
unk = {m.split("'")[1] for f in r["findings"] if f["rule"] == "schema" and f["level"] == "warning" for m in [f["message"]]}
assert unk == {"filename", "PORTED"}, unk
r2 = cv.validate(code, schema, seeded - {"lk_VFUK_R_UC_APN_LIST"}); assert not r2["ok"] and has(r2, "error", "lookups", "lk_VFUK_R_UC_APN_LIST"), "a disabled lookup the code uses is an error"
print(f"7 the real PGW code ({r['stats']['lines']} lines): 0 errors, {r['warnings']} warnings (output columns not in the schema: {', '.join(sorted(unk))}), uses {len(r['stats']['lookups'])} lookups: ok")

# ============================================================ 8. sandboxed test run
dr.TIMEOUT_SECONDS = 3
types_ = dict(pgw_schema.DETAIL_SCHEMA)
f = dr.dry_run(GOOD, [], {"APN": "STRING", "COUNT": "INT64", "GROUP": "STRING"})
assert not any(x["level"] == "error" for x in f), f
assert [x for x in f if x["level"] == "info" and x["message"].startswith("Test run:")], f
assert {w["message"].split(":")[1].strip() for w in f if w["level"] == "warning"} == {"ValueError"} and all("reject" in w["message"] for w in f if w["level"] == "warning"), \
    "int('abc') on an invented record is a warning (PRISM would reject that record), nothing worse"
rows = dr.sample_rows(GOOD, [{"apn": "x"}]); assert [l for l, _ in rows][0] == "empty record" and any("your record 1" == l for l, _ in rows) and ({"apn": "1", "n": "1"} in [r for _, r in rows])
f = dr.dry_run("class transform_record:\n    def process(self, row):\n        yield {'v': zzz}\n"); assert any(x["level"] == "error" and "NameError" in x["message"] and x["line"] == 3 for x in f), f
f = dr.dry_run("class transform_record:\n    def process(self, row):\n        yield 'not a dict'\n"); assert any(x["level"] == "error" and "not dicts" in x["message"] for x in f), f
f = dr.dry_run("class transform_record:\n    def process(self, row):\n        yield {'v': int(row['n'])}\n", [{"n": "5"}])
assert any(x["level"] == "warning" and "KeyError" in x["message"] and "reject" in x["message"] for x in f) and not any(x["level"] == "error" for x in f)
assert "1 of 5 sample records ran" in [x for x in f if x["level"] == "info"][0]["message"] or "2 of 5" in [x for x in f if x["level"] == "info"][0]["message"], f
f = dr.dry_run("import definitely_not_installed\nclass transform_record:\n    def process(self, row):\n        yield {}\n"); assert any(x["level"] == "error" and "ModuleNotFoundError" in x["message"] for x in f), f
f = dr.dry_run("class transform_record:\n    def process(self, row):\n        while True:\n            pass\n        yield {}\n"); assert any(x["level"] == "error" and "longer than" in x["message"] for x in f), f
f = dr.dry_run("class transform_record:\n    def process(self, row):\n        yield {'COUNT': 'abc', 'APN': 'ok'}\n", [], {"COUNT": "INT64", "APN": "STRING"}); assert any(x["level"] == "warning" and "COUNT='abc' for INT64" in x["message"] for x in f), f
f = dr.dry_run("class transform_record:\n    def setup(self):\n        from LookupsManager import LookupManager\n        LookupManager.load_selected(['lk_x'])\n    def process(self, row):\n        yield {'v': LookupManager_get()}\n"); assert any("NameError" in x["message"] for x in f)
print("8 test run: finds runtime NameError, non-dict yields, import errors, endless loops, values that do not fit the column; crash on an invented record is only a warning: ok")
dr.TIMEOUT_SECONDS = 15
f = dr.dry_run(code, [], types_); assert not any(x["level"] == "error" for x in f), f
assert any("Test run:" in x["message"] and "56 column(s) set" in x["message"] for x in f), [x["message"] for x in f]
print("   the real PGW code runs in the test run:", [x["message"][:90] for x in f if x["level"] == "info"][0])
ex, err = dr.parse_extra('{"a": 1}'); assert ex == [{"a": 1}] and err is None
ex, err = dr.parse_extra('[{"a": 1}, {"b": 2}]'); assert len(ex) == 2
for bad in ("not json", "[1, 2]", '"x"'): assert dr.parse_extra(bad)[1], bad
assert len(dr.parse_extra(str([{"a": i} for i in range(50)]).replace("'", '"'))[0]) == dr.MAX_SAMPLE_ROWS and dr.parse_extra("")[0] == []

# ============================================================ 9. highlighter and diff
html = [str(x) for x in hl.highlight_lines('x = "<script>alert(1)</script>"  # a <b> comment\nif True:\n    pass\n')]
assert "<script>" not in html[0] and "&lt;script&gt;" in html[0] and '<span class="st">' in html[0] and '<span class="cm">' in html[0] and '<span class="kw">if</span>' in html[1] and len(html) == 3
assert len(hl.highlight_lines("s = '''a\nb\nc'''\nz = 1\n")) == 4
assert [str(x) for x in hl.highlight_lines("s = '''unterminated\nx = 1\n")] and len(hl.highlight_lines("def (:\n  x = ")) == 2, "a tokenizer error never breaks the viewer"
assert len(hl.highlight_lines(code)) == len(code.splitlines())
rows = hl.diff_rows("a\nb\nc\nd\ne\nf\ng\nh\n", "a\nb\nc\nD\ne\nf\ng\nh\ni\n")
assert [r["kind"] for r in rows if r["kind"] in ("add", "del")] == ["del", "add", "add"] and rows[0]["kind"] == "hunk" and hl.diff_rows("x\n", "x\n") == []
d = [r for r in rows if r["kind"] == "del"][0]; assert d["a"] == 4 and d["text"] == "d" and [r for r in rows if r["kind"] == "add"][0]["b"] == 4
print("9 highlighter escapes HTML and survives bad code; diff: ok")
print("ALL CODE VALIDATION CHECKS PASSED")
