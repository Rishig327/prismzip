"""
Guards against "No module named X" in the GUI image.   python tests/check_gui_imports.py
The image = gui/*.py + two shared files (orchestrator/config_store.py, common/prism_settings.py).
Every module reachable from gui/app.py, gui/manage.py and gui/demo.py must be one of those, and none may be Dataflow-worker code.
"""
import ast
import glob
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SHARED = {"config_store": "orchestrator", "prism_settings": "common", "transform_store": "common"}   # copied by gui/Dockerfile
where = {}
for label in ["gui", "orchestrator", "common"] + [f"sources/{os.path.basename(d)}" for d in sorted(glob.glob(os.path.join(ROOT, "sources", "*")))]:
    for f in glob.glob(os.path.join(ROOT, label.replace("/", os.sep), "*.py")):
        where.setdefault(os.path.basename(f)[:-3], label)          # gui/ wins on a name clash (none today)


lazy = set()                                              # orchestrator modules only imported INSIDE functions of a shared file


def imports(mod):
    """gui/ modules: every import. Shared files: top-level imports only (their function-level imports are for orchestrator
    functions such as code_defaults / recon_put, which the GUI never calls) - those are listed in `lazy` for the report."""
    p = os.path.join(ROOT, where[mod].replace("/", os.sep), mod + ".py")
    tree = ast.parse(open(p, encoding="utf-8").read())
    top = where[mod] == "gui"
    nodes = list(ast.walk(tree)) if top else list(tree.body)
    out, inner = set(), set()
    for n in ast.walk(tree):
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            names = {a.name.split(".")[0] for a in n.names} if isinstance(n, ast.Import) else ({n.module.split(".")[0]} if n.module and n.level == 0 else set())
            (out if n in nodes else inner).update(names)
    if not top:
        lazy.update(inner & set(where) - out)
    return out & set(where)


need, todo = set(), ["app", "manage", "demo"]
while todo:
    m = todo.pop()
    if m not in need:
        need.add(m); todo += list(imports(m))

lines = [l.strip() for l in open(os.path.join(ROOT, "gui", "Dockerfile"), encoding="utf-8").read().splitlines()
         if l.strip() and not l.strip().startswith("#")]
copy = " ".join(l for l in lines if l.startswith("COPY"))
problems = []
if "gui/*.py" not in copy:
    problems.append("gui/Dockerfile must COPY gui/*.py")
for t in ("templates", "static"):
    if f"gui/{t}" not in copy:
        problems.append(f"gui/Dockerfile must COPY gui/{t}")
if "sources/*/*_schema.py" not in copy:                      # code_routes imports <source>_schema dynamically, so the import graph cannot see it
    problems.append("gui/Dockerfile must COPY sources/*/*_schema.py (the code validator compares the output columns with the detail table schema)")
for m in sorted(need):
    if where[m] == "gui":
        continue
    if SHARED.get(m) == where[m]:
        if f"{where[m]}/{m}.py" not in copy:
            problems.append(f"{m}: gui/Dockerfile must COPY {where[m]}/{m}.py")
    else:
        problems.append(f"{m} ({where[m]}): module outside gui/ and not one of the shared files {sorted(SHARED)}")
print("gui modules:", ", ".join(sorted(need)))
if lazy:
    print("note: shared files import", ", ".join(sorted(lazy)), "only inside orchestrator-only functions (not available in the GUI image; do not call them from the GUI)")
if problems:
    print("PROBLEMS:"); [print("  -", p) for p in problems]; sys.exit(1)
print("OK: gui/Dockerfile contains every module the GUI needs")
