"""
Guards against "No module named X" in the Cloud Run image.   python tests/check_orchestrator_imports.py
The image = orchestrator/*.py + common/prism_settings.py (the only shared file). Every module reachable from
run_prism_batch.py, recon_runner.py and config_admin.py must be one of those, and none may be Dataflow-worker code
(those need Apache Beam, which this image does not install).
"""
import ast
import glob
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
where = {}
for label in ["common", "orchestrator", "gui"] + [f"sources/{os.path.basename(d)}" for d in sorted(glob.glob(os.path.join(ROOT, "sources", "*")))]:
    for f in glob.glob(os.path.join(ROOT, label.replace("/", os.sep), "*.py")):
        where[os.path.basename(f)[:-3]] = label
SHARED_WITH_ORCHESTRATOR = {"prism_settings", "transform_store"}          # copied from common/ by orchestrator/Dockerfile


def imports(mod):
    p = os.path.join(ROOT, where[mod].replace("/", os.sep), mod + ".py")
    names = set()
    for n in ast.walk(ast.parse(open(p, encoding="utf-8").read())):
        if isinstance(n, ast.Import):
            names |= {a.name.split(".")[0] for a in n.names}
        elif isinstance(n, ast.ImportFrom) and n.module and n.level == 0:
            names.add(n.module.split(".")[0])
    return names & set(where)


need, todo = set(), ["run_prism_batch", "recon_runner", "config_admin"]
while todo:
    m = todo.pop()
    if m not in need:
        need.add(m); todo += list(imports(m))

lines = [l.strip() for l in open(os.path.join(ROOT, "orchestrator", "Dockerfile"), encoding="utf-8").read().splitlines()
         if l.strip() and not l.strip().startswith("#")]
problems = []
if not any(l.startswith("COPY orchestrator/*.py") for l in lines):
    problems.append("orchestrator/Dockerfile must contain:  COPY orchestrator/*.py ... ./")
for m in sorted(need):
    if where[m] == "orchestrator":
        continue
    if m in SHARED_WITH_ORCHESTRATOR:
        if not any(f"common/{m}.py" in l for l in lines):
            problems.append(f"{m}: orchestrator/Dockerfile must COPY common/{m}.py")
    else:
        problems.append(f"{m} ({where[m]}): worker-side module reachable from the orchestrator")
print("orchestrator modules:", ", ".join(sorted(need)))
if problems:
    print("PROBLEMS:"); [print("  -", p) for p in problems]; sys.exit(1)
print("OK: orchestrator/Dockerfile contains every module the orchestrator and recon need")
