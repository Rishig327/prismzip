"""
Guards against "No module named X" on Dataflow workers and keeps the folder/image split clean.
    python tests/check_worker_imports.py

Layout:  common/             -> image prism-common   (code shared by every source; the Dockerfile copies common/*.py)
         sources/<source>/   -> image prism-<source> (FROM common; the Dockerfile copies sources/<source>/*.py)
Rules
  * every module the workers import (reachable from common/dataflow_pipeline.py and from each <source>_plugin.py) lives
    in common/ or in THAT source's folder
  * common/ never imports a source module; a source never imports another source
  * no worker module imports orchestrator code (orchestrator/ folder)
  * each Dockerfile copies its own folder with a wildcard (so a new file in the folder is in the image automatically)
  * every source folder has a Dockerfile, a <source>_plugin.py and a requirements.txt
  * common/setup.py discovers modules (a fixed list would break when a source image adds files)
"""
import ast
import glob
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
where = {}                                   # module -> folder label ("common", "orchestrator", "sources/pgw")
for label, folder in [("common", "common"), ("orchestrator", "orchestrator"), ("gui", "gui")] + \
        [(f"sources/{os.path.basename(d)}", d) for d in sorted(glob.glob(os.path.join(ROOT, "sources", "*")))]:
    for f in glob.glob(os.path.join(ROOT, folder, "*.py")):
        where[os.path.basename(f)[:-3]] = label
path = lambda m: os.path.join(ROOT, where[m].replace("/", os.sep), m + ".py")      # noqa: E731


def imports(mod):
    names = set()
    for n in ast.walk(ast.parse(open(path(mod), encoding="utf-8").read())):
        if isinstance(n, ast.Import):
            names |= {a.name.split(".")[0] for a in n.names}
        elif isinstance(n, ast.ImportFrom) and n.module and n.level == 0:
            names.add(n.module.split(".")[0])
    return names & set(where)


def closure(root):
    need, todo = set(), [root]
    while todo:
        m = todo.pop()
        if m not in need:
            need.add(m)
            todo += list(imports(m))
    return need


def code_lines(p):
    return [l.strip() for l in open(p, encoding="utf-8").read().splitlines() if l.strip() and not l.strip().startswith("#")]


problems = []
sources = sorted(l.split("/")[1] for l in set(where.values()) if l.startswith("sources/"))

# folder -> image wiring
if not any(l.startswith("COPY common/*.py") for l in code_lines(os.path.join(ROOT, "common", "Dockerfile"))):
    problems.append("common/Dockerfile must contain:  COPY common/*.py /template/")
if "listdir" not in open(os.path.join(ROOT, "common", "setup.py"), encoding="utf-8").read():
    problems.append("common/setup.py must discover modules (os.listdir) instead of a fixed list")
if "setup" not in where:
    problems.append("common/setup.py is missing")
for s in sources:
    d = os.path.join(ROOT, "sources", s)
    for need_file in ("Dockerfile", f"{s}_plugin.py", "requirements.txt"):
        if not os.path.exists(os.path.join(d, need_file)):
            problems.append(f"sources/{s}/{need_file} is missing")
    df = os.path.join(d, "Dockerfile")
    if os.path.exists(df) and not any(l.startswith(f"COPY sources/{s}/*.py") for l in code_lines(df)):
        problems.append(f"sources/{s}/Dockerfile must contain:  COPY sources/{s}/*.py /template/")

# common: only itself
for m in sorted(closure("dataflow_pipeline")):
    if where[m] != "common":
        problems.append(f"{m} ({where[m]}) is reachable from dataflow_pipeline: common/ must not depend on {where[m]}")

# each source: common + its own folder
for s in sources:
    if f"{s}_plugin" not in where:
        continue
    for m in sorted(closure(f"{s}_plugin")):
        if where[m] not in ("common", f"sources/{s}"):
            problems.append(f"{m} ({where[m]}) is used by {s}_plugin: allowed only from common/ or sources/{s}/")

# no orchestrator / gui code in worker folders
for m, label in sorted(where.items()):
    if label in ("orchestrator", "gui"):
        continue
    bad = sorted(i for i in imports(m) if where[i] in ("orchestrator", "gui"))
    if bad:
        problems.append(f"{m} ({label}) imports orchestrator module(s) {bad}")

print("common :", ", ".join(sorted(m for m, l in where.items() if l == "common")))
for s in sources:
    print(f"{s:7}:", ", ".join(sorted(m for m, l in where.items() if l == f'sources/{s}')))
if problems:
    print("\nPROBLEMS:"); [print("  -", p) for p in problems]; sys.exit(1)
print("OK: every worker module is in the right folder/image; common is source-free; no orchestrator imports")
