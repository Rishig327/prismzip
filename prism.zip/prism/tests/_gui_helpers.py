"""Shared fixtures for the GUI tests: stubs the Google libraries, builds an app with an in-memory store, a sample-data runner and users."""
import json, re, sys, types
import _paths  # noqa: F401

class _QJC:
    def __init__(self, **k): self.__dict__.update(k)
_bq = types.ModuleType("google.cloud.bigquery")
_bq.ScalarQueryParameter = _bq.ArrayQueryParameter = lambda *a: tuple(a)
_bq.EncryptionConfiguration = _bq.Client = type("P", (), {"__init__": lambda self, *a, **k: None}); _bq.QueryJobConfig = _QJC
_g, _gc = types.ModuleType("google"), types.ModuleType("google.cloud"); _gc.bigquery = _bq; _g.cloud = _gc
sys.modules.setdefault("google.cloud.bigquery", _bq); sys.modules.setdefault("google.cloud", _gc); sys.modules.setdefault("google", _g)

import demo, rbac                                    # noqa: E402
from app import create_app                           # noqa: E402
from store import MemoryStore                        # noqa: E402

PW = "Start-Pass-Word-42!"

def fresh(runner=None, cfg=None):
    st = MemoryStore(); demo.seed_roles(st)
    base = rbac.clean({})
    st.put_role("no-data", "dashboards view only", {**base, "dashboards": rbac.VIEW}, True, "t")
    st.put_role("exporter", "viewer + export", {**base, "dashboards": rbac.VIEW, "data_pipeline": 1, "data_recon": 1, "dash_export": 1}, True, "t")
    for u, role in (("admin", "admin"), ("pub", "dashboard-publisher"), ("cre", "dashboard-creator"), ("cre2", "dashboard-creator"), ("view", "viewer"),
                    ("view2", "viewer"), ("nodata", "no-data"), ("ops", "operator"), ("exp", "exporter")):
        demo.new_user(st, u, PW, role)
    runner = runner or demo.SampleRunner()
    return st, create_app(st, cfg or demo.DemoConfig(), "k" * 40, dev=True, cache_seconds=0, runner=runner), runner

def tok(c, path="/"):
    return re.search(r'name="csrf_token" value="([^"]+)"', c.get(path).get_data(as_text=True)).group(1)
def signin(app, user):
    c = app.test_client()
    assert c.post("/login", data={"csrf_token": tok(c, "/login"), "username": user, "password": PW}).status_code == 302, user
    return c
def post(c, path, data=None):
    return c.post(path, data={"csrf_token": tok(c), **(data or {})})
def text(r): return r.get_data(as_text=True)
def widgets_of(st, dash_id): return json.loads(st.dash_get(dash_id)["definition"])["widgets"]
