"""
Worker side of the table-stored transformation: the loader, the equivalence with the old file, and the contract between
orchestrator -> Flex Template parameters -> pipeline arguments -> plugin.      python tests/test_transform_loader.py
"""
import ast, importlib.util, json, os, random, re, sys, traceback, types
import _paths  # noqa: F401

# stand-ins for libraries that are not installed here (same approach as the other tests)
class _P:
    def __init__(self, *a, **k): pass
bq = types.ModuleType("google.cloud.bigquery")
for n in ("ScalarQueryParameter", "ArrayQueryParameter", "EncryptionConfiguration", "QueryJobConfig", "Client"): setattr(bq, n, _P)
st_ = types.ModuleType("google.cloud.storage"); st_.Client = _P
g, gc = types.ModuleType("google"), types.ModuleType("google.cloud"); gc.bigquery, gc.storage = bq, st_; g.cloud = gc
gd = types.ModuleType("googleapiclient.discovery"); gd.build = lambda *a, **k: None
beam = types.ModuleType("apache_beam"); beam.DoFn = type("DoFn", (), {})
sys.modules.update({"google": g, "google.cloud": gc, "google.cloud.bigquery": bq, "google.cloud.storage": st_, "googleapiclient": types.ModuleType("googleapiclient"),
                    "googleapiclient.discovery": gd, "apache_beam": beam})

import transform_loader as tl, transform_store as ts       # noqa: E402
import LookupsManager                                      # noqa: E402
import code_dryrun                                         # noqa: E402

LookupManager = LookupsManager.LookupManager             # no BigQuery: the same lookup fakes the existing PGW local test uses
LookupManager.load_selected = classmethod(lambda cls, names: None)
LookupManager.get_lookup = classmethod(lambda cls, name, *keys, default=None: {"VALUE": "7"} if name.startswith("lk_VFUK_C_UC_") else (default if default is not None else {}))
SEED = os.path.join(os.path.dirname(__file__), "..", "sources", "pgw", "seed", "transformation_PGW.v1.py")
code = open(SEED, encoding="utf-8").read()
SHA = ts.sha256(code)

class Counting(ts.MemoryTransformTable):
    reads = 0
    def get_approved(self, source, version):
        Counting.reads += 1
        return super().get_approved(source, version)
def table(**extra):
    t = Counting(); t.seed("PGW", code, "seed")
    for src, c in extra.items(): t.seed(src, c, "seed")
    return t
def fails(fn, exc, text):
    try: fn()
    except exc as e: assert text in str(e), (text, str(e)); return e
    raise AssertionError(f"expected {exc.__name__} containing {text!r}")

# ============================================================ 1. the code from the TABLE behaves exactly like the old FILE
spec = importlib.util.spec_from_file_location("seed_pgw_file", SEED); old_mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(old_mod)
old = old_mod.transform_record(); old.setup()
tl.set_table(table()); new = tl.load_transform("PGW", 1, SHA)
assert type(new).__name__ == "transform_record" and type(new) is not old_mod.transform_record
fields = code_dryrun.cv.input_fields(code_dryrun.cv.find_process(ast.parse(code))[1])
rng, VALUES = random.Random(7), ["", "0", "1", "2", "12345", "447700900123", "a|b|c", "20250101123000", "internet", "TRUE", "-5", "1.5", "abc"]
rows = [r for _, r in code_dryrun.sample_rows(code)] + [{f: rng.choice(VALUES) for f in fields if rng.random() < 0.7} for _ in range(80)]
same = diff_exc = 0
for r in rows:
    def run(inst):
        try: return ("ok", [dict(x) for x in inst.process(dict(r))])
        except Exception as e: return ("exc", type(e).__name__, str(e))
    a, b = run(old), run(new)
    assert a == b, (r, a, b)
    same += a[0] == "ok"; diff_exc += a[0] == "exc"
assert same >= 10 and len(rows) == 84
print(f"1 table code == file code on {len(rows)} records ({same} produced rows, {diff_exc} raised the same error in both): ok")

# ============================================================ 2. the loader: hash, missing version, compile errors, caching, tracebacks
t = table(); tl.set_table(t); Counting.reads = 0
CNT = "CALLS = []\nclass transform_record:\n    def setup(self):\n        CALLS.append(1)\n    def process(self, row):\n        yield {'setup_calls': len(CALLS)}\n"
t.seed("CNT", CNT, "seed"); tl.set_table(t)
a, b = tl.load_transform("CNT", 1, ts.sha256(CNT)), tl.load_transform("CNT", 1, ts.sha256(CNT))      # a worker always passes the same version + hash
assert Counting.reads == 1 and list(a.process({})) == [{"setup_calls": 2}], "one read and one compile per worker; setup() runs once per instance"
fails(lambda: tl.load_transform("PGW", 1, "0" * 64), ts.TransformError, "does not match the hash the orchestrator launched with")
fails(lambda: tl.load_transform("PGW", 9, SHA), ts.TransformUnavailable, "was not found")
fails(lambda: tl.load_transform("NOPE", 1), ts.TransformUnavailable, "was not found")
for none in (0, None, ""): fails(lambda: tl.load_transform("PGW", none), ts.TransformError, "No transform version was passed")
t2 = table(); tl.set_table(t2); t2.rows["PGW"][0]["code"] += "\n# edited behind the table's back\n"      # code changed without its hash
fails(lambda: tl.load_transform("PGW", 1), ts.TransformError, "does not match")
bad = ts.MemoryTransformTable(); bad._insert(bad._row("BAD", "APPROVED", "approve", 1, "x = (1,\n", "x", None, approved_by="x")); tl.set_table(bad)
e = fails(lambda: tl.load_transform("BAD", 1), ts.TransformError, "does not compile: line"); assert "BAD v1" in str(e)
nocls = ts.MemoryTransformTable(); nocls.seed("NC", "x = 1\n", "seed"); tl.set_table(nocls); fails(lambda: tl.load_transform("NC", 1), ts.TransformError, "does not define the class transform_record")
BOOM = "class transform_record:\n    def process(self, row):\n        marker = 1\n        raise ValueError('boom here')\n        yield {}\n"
bm = ts.MemoryTransformTable(); bm.seed("BM", BOOM, "seed"); tl.set_table(bm); inst = tl.load_transform("BM", 1)
try: list(inst.process({}))
except ValueError: tb = traceback.format_exc(); assert "boom here" in tb and "raise ValueError('boom here')" in tb and "<prism-transform BM v1>" in tb, tb
else: raise AssertionError("expected ValueError")
two = ts.MemoryTransformTable(); two.seed("V", CNT, "seed"); two.start_draft("V", "a"); two.save_draft("V", CNT + "# v2\n", "a", None); two.record_validation("V", "a", True, {}); two.approve("V", "b")
tl.set_table(two); assert tl.load_transform("V", 1) is not None and tl.load_transform("V", 2) is not None, "every approved version stays loadable"
print("2 loader: one read + compile, hash check, missing / no version, compile errors with line, tracebacks show the code, old versions: ok")

# ============================================================ 3. the contract orchestrator -> template -> pipeline -> plugin
import run_prism_batch as rpb                                # noqa: E402
rpb.TRANSFORM_VERSION, rpb.TRANSFORM_SHA = 7, "ab" * 32
captured = {}
class Chain:
    def __init__(self, name=None): self.name = name
    def __getattr__(self, n): return lambda *a, **k: self if n != "launch" else self._launch(**k)
    def _launch(self, **k): captured.update(k); return types.SimpleNamespace(execute=lambda: {"job": {"id": "J-1"}})
rpb.build = lambda *a, **k: Chain()
cfg = types.SimpleNamespace(src=types.SimpleNamespace(source_type="PGW"), target=types.SimpleNamespace(staging_table="proj.ds.stg"), reject_table="proj.ds.rej",
                            read_counts_table="proj.ds.rc", kms_key_name="projects/k", dataflow_env={}, flex_template_gcs_path="gs://b/t.json")
rpb.launch_dataflow(cfg, "gs://b/m.json", "PGW-1")
params = captured["body"]["launchParameter"]["parameters"]
assert params["transform_version"] == "7" and params["transform_sha"] == "ab" * 32, params
pipeline_args = set(re.findall(r'add_argument\("--([a-z_]+)"', open("common/dataflow_pipeline.py", encoding="utf-8").read()))
meta = {p["name"] for p in json.load(open("sources/pgw/metadata.json"))["parameters"]}
assert set(params) == meta, ("the template metadata and the launcher disagree", set(params) ^ meta)
assert set(params) <= pipeline_args, ("the launcher sends a parameter the pipeline does not accept", set(params) - pipeline_args)
cmds = []
class FakeProc:
    returncode = 0
    def __init__(self, cmd, cwd=None): cmds.append(cmd)
    def poll(self): return 0
rpb.subprocess = types.SimpleNamespace(Popen=FakeProc)
here_ok = rpb._run_pipeline_process(types.SimpleNamespace(), cfg, "gs://b/m.json", "PGW-1", "/tmp/stage"); assert here_ok
flags = {c.split("=")[0][2:]: c.split("=", 1)[1] for c in cmds[0] if c.startswith("--") and "=" in c}
assert flags["transform_version"] == "7" and flags["transform_sha"] == "ab" * 32 and set(params) - {"manifest"} <= set(flags) | {"manifest"}, flags
src = open("common/dataflow_pipeline.py", encoding="utf-8").read()
assert "ProcessFileDoFn(known.source_type, known.transform_version, known.transform_sha)" in src and "self.plugin.transform_version = self.transform_version" in src and "self.plugin.transform_sha = self.transform_sha" in src
plug = ast.parse(open("sources/pgw/pgw_plugin.py", encoding="utf-8").read())
imports = {n.module for n in ast.walk(plug) if isinstance(n, ast.ImportFrom)} | {a.name for n in ast.walk(plug) if isinstance(n, ast.Import) for a in n.names}
assert "transformation_PGW" not in imports and "transform_loader" in imports, "the plugin no longer imports a transformation file"
assert 'load_transform("PGW", self.transform_version, self.transform_sha)' in open("sources/pgw/pgw_plugin.py", encoding="utf-8").read()
assert not os.path.exists("sources/pgw/transformation_PGW.py") and os.path.exists("sources/pgw/seed/transformation_PGW.v1.py")
assert not any("transformation_PGW" in l for l in open("sources/pgw/Dockerfile", encoding="utf-8").read().splitlines() if not l.lstrip().startswith("#"))
print("3 launcher parameters == template metadata, accepted by the pipeline, version + hash reach the job (flex and vm); plugin has no file import: ok")
print("ALL TRANSFORM LOADER CHECKS PASSED")
