transformation_PGW.v1.py is the ONE-TIME SEED of version 1 of the PGW transformation code.
It is not part of any image (sources/pgw/Dockerfile copies sources/pgw/*.py only) and nothing imports it.
The source of truth is the table VPDB_ADM.prism_transform_code, edited and approved in the GUI (Sources -> PGW -> Transformation code).

Load it once:   python gui/manage.py seed-transform PGW sources/pgw/seed/transformation_PGW.v1.py
After that this folder can be deleted from the repository.
