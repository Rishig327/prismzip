"""
code_dryrun.py - runs the transformation on a few sample records in a SEPARATE Python process, to catch mistakes the static checks cannot
(a typo in a rarely used branch, a wrong type, an endless loop). The code is executed, so this is only offered to people who may edit code.

  * its own process (python -I) with a time limit, and on Linux CPU and memory limits; nothing is shared with the GUI
  * apache_beam and LookupsManager are replaced by small stand-ins: lookups return the default you pass (or an empty dict), nothing reads BigQuery
  * records: an empty record, plus records built from the fields the code reads (set to "1", "abc" and "1|2"), plus any JSON records you paste
What it tells you: the code runs, yields dicts, which columns it sets, and whether the values fit the column types. It cannot tell you the
business result is right. A crash on an invented record is a WARNING (PRISM would reject such a record and carry on); a missing name or
import is an ERROR.
"""
import json
import subprocess
import sys
import tempfile
import threading

import code_validate as cv

TIMEOUT_SECONDS = 15
MEMORY_MB = 1024
MAX_SAMPLE_ROWS = 20
_slots = threading.BoundedSemaphore(2)               # at most two test runs at once on this server

_HARNESS = r'''
import json, sys, time, traceback, types
payload = json.loads(sys.stdin.read())
class _Any(types.ModuleType):
    def __getattr__(self, name):
        if name.startswith("__"): raise AttributeError(name)
        return type(name, (), {})
beam = _Any("apache_beam"); beam.DoFn = type("DoFn", (), {})
class LookupManager:
    @classmethod
    def load_all(cls, *a, **k): pass
    @classmethod
    def load_selected(cls, *a, **k): pass
    @classmethod
    def load_lookup(cls, *a, **k): pass
    @classmethod
    def clear(cls, *a, **k): pass
    @classmethod
    def get_lookup(cls, name, *keys, default=None, **k): return default if default is not None else {}
lm = types.ModuleType("LookupsManager"); lm.LookupManager = LookupManager
sys.modules["apache_beam"], sys.modules["LookupsManager"] = beam, lm
FILE = "<transform>"
def where(tb):
    frames = [f for f in traceback.extract_tb(tb) if f.filename == FILE]
    return frames[-1].lineno if frames else None
result = {"setup": None, "rows": [], "fatal": None}
try:
    mod = types.ModuleType("t"); mod.__file__ = FILE
    exec(compile(payload["code"], FILE, "exec"), mod.__dict__)
    inst = mod.__dict__["transform_record"]()
    if hasattr(inst, "setup"): inst.setup()
except BaseException as e:
    result["fatal"] = {"type": type(e).__name__, "message": str(e)[:300], "line": where(e.__traceback__)}
    print("@@RESULT@@" + json.dumps(result)); sys.exit(0)
for label, row in payload["rows"]:
    t0 = time.time(); entry = {"label": label, "outputs": 0, "columns": [], "error": None, "bad_type": 0, "sample": None}
    try:
        outs = list(inst.process(dict(row)))
        cols = {}
        for o in outs:
            if not isinstance(o, dict): entry["bad_type"] += 1; continue
            for k, v in o.items(): cols.setdefault(k, v)
        entry.update(outputs=len(outs), columns=sorted(cols), sample={k: (v if isinstance(v, (int, float, bool, type(None))) else str(v)[:40]) for k, v in list(cols.items())[:80]})
    except BaseException as e:
        entry["error"] = {"type": type(e).__name__, "message": str(e)[:300], "line": where(e.__traceback__)}
    entry["ms"] = int((time.time() - t0) * 1000); result["rows"].append(entry)
print("@@RESULT@@" + json.dumps(result))
'''


def sample_rows(code: str, extra=None):
    """[(label, record)]: empty, one built from the fields the code reads in three flavours, and the user's own records."""
    import ast
    try:
        _, proc = cv.find_process(ast.parse(code))
        fields = cv.input_fields(proc)
    except SyntaxError:
        fields = []
    rows = [("empty record", {})]
    if fields:
        rows += [(f'all fields = "{v}"', {f: v for f in fields}) for v in ("1", "abc", "1|2")]
    for i, r in enumerate((extra or [])[:MAX_SAMPLE_ROWS], 1):
        rows.append((f"your record {i}", r))
    return rows


def parse_extra(text: str):
    """The optional pasted JSON (one object or a list of objects) -> (list, error message or None)."""
    text = (text or "").strip()
    if not text:
        return [], None
    try:
        v = json.loads(text)
    except ValueError as e:
        return [], f"The sample records are not valid JSON: {e}"
    v = [v] if isinstance(v, dict) else v
    if not isinstance(v, list) or not all(isinstance(x, dict) for x in v):
        return [], "Sample records must be a JSON object or a list of objects."
    return v[:MAX_SAMPLE_ROWS], None


def _limits():
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (TIMEOUT_SECONDS, TIMEOUT_SECONDS))
        resource.setrlimit(resource.RLIMIT_AS, (MEMORY_MB * 1024 ** 2, MEMORY_MB * 1024 ** 2))
    except Exception:                                  # Windows / restricted: the time limit below still applies
        pass


def _coerces(value, typ):
    """Mirrors what loading needs: would this value fit the column type?"""
    if value is None or value == "":
        return True
    try:
        if typ == "INT64":
            int(str(value).strip().split(".")[0]) if not isinstance(value, bool) else None
        elif typ in ("FLOAT64", "NUMERIC"):
            float(str(value).strip())
        elif typ == "BOOL":
            return str(value).strip().lower() in ("true", "false", "0", "1", "t", "f", "y", "n")
        elif typ == "TIMESTAMP" or typ == "DATE":
            return len(str(value)) >= 8
    except (ValueError, TypeError):
        return False
    return True


def dry_run(code: str, extra_rows=None, schema_types=None) -> list:
    """-> findings (same shape as code_validate, rule 'dryrun'). schema_types: {column: type} to check the produced values against."""
    F = []
    rows = sample_rows(code, extra_rows)
    if not _slots.acquire(timeout=5):
        return [cv._f("warning", "dryrun", None, "The test run was skipped: other test runs are busy. Try again in a moment.")]
    try:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                p = subprocess.run([sys.executable, "-I", "-c", _HARNESS], input=json.dumps({"code": code, "rows": rows}), capture_output=True, text=True,
                                   timeout=TIMEOUT_SECONDS, cwd=tmp, env={"PATH": "/usr/bin:/bin", "PYTHONHASHSEED": "0"}, preexec_fn=_limits if sys.platform != "win32" else None)
            except subprocess.TimeoutExpired:
                return [cv._f("error", "dryrun", None, f"The test run took longer than {TIMEOUT_SECONDS} seconds and was stopped. Look for an endless or very slow loop.")]
    finally:
        _slots.release()
    out = next((ln for ln in p.stdout.splitlines() if ln.startswith("@@RESULT@@")), None)
    if out is None:
        tail = (p.stderr or "").strip().splitlines()[-1:] or ["no output"]
        return [cv._f("error", "dryrun", None, f"The test run stopped unexpectedly (exit {p.returncode}): {tail[0][:200]}. A memory or CPU limit may have been hit.")]
    res = json.loads(out[len("@@RESULT@@"):])
    fatal = res["fatal"]
    if fatal:
        lvl = "error"
        return [cv._f(lvl, "dryrun", fatal["line"], f"The code could not be loaded in the test run: {fatal['type']}: {fatal['message']}")]
    produced, bad_types = set(), []
    for r in res["rows"]:
        if r["error"]:
            e = r["error"]
            lvl = "error" if e["type"] in ("NameError", "ImportError", "ModuleNotFoundError", "SyntaxError") else "warning"
            F.append(cv._f(lvl, "dryrun", e["line"], f"On the {r['label']}: {e['type']}: {e['message']}" + ("" if lvl == "error" else " (PRISM would reject such a record and carry on.)")))
        elif r["bad_type"]:
            F.append(cv._f("error", "dryrun", None, f"On the {r['label']}: process yielded {r['bad_type']} value(s) that are not dicts."))
        else:
            produced |= set(r["columns"])
            if schema_types:
                for k, v in (r["sample"] or {}).items():
                    if k in schema_types and not _coerces(v, schema_types[k]):
                        bad_types.append(f"{k}={v!r} for {schema_types[k]}")
    ran = [r for r in res["rows"] if not r["error"]]
    F.append(cv._f("info", "dryrun", None, f"Test run: {len(ran)} of {len(res['rows'])} sample records ran without an error; {sum(r['outputs'] for r in ran)} output row(s); "
                                           f"{len(produced)} column(s) set; slowest record {max([r['ms'] for r in res['rows']] or [0])} ms."))
    if bad_types:
        F.append(cv._f("warning", "dryrun", None, "Values that do not fit their column type in the test run: " + "; ".join(sorted(set(bad_types))[:8])))
    return F
