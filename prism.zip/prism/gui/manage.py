"""
manage.py - bootstrap and rescue commands for the PRISM GUI (run by an administrator with BigQuery access, not by users).

    python gui/manage.py seed-roles                      create the built-in roles admin / operator / viewer (only those missing)
    python gui/manage.py create-admin NAME               first administrator; prints a TEMPORARY password once (must be changed at first sign-in)
    python gui/manage.py reset-password NAME             new temporary password for a user (also for a locked-out administrator)
    python gui/manage.py unlock NAME                     clears a lock-out
    python gui/manage.py list-users
    python gui/manage.py seed-transform SOURCE FILE      load version 1 of a source's transformation code into the table (once)

Use Cloud Shell or a trusted workstation: the temporary password is printed to the screen (do not run it where output is logged).
"""
import argparse
import os
import sys
from datetime import datetime, timezone

for _d in ("orchestrator", "common"):                    # local run from the project folder (in the image everything sits beside this file)
    _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", _d)
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.append(_p)

import rbac                                              # noqa: E402
import security as sec                                   # noqa: E402


def connect():
    from prism_settings import bq_kms_key_name, my_ctl_dataset, my_project
    import config_store as cs
    from store import BigQueryStore
    return BigQueryStore(cs.BqHelper(my_project, os.environ.get("PRISM_LOCATION", "europe-west2"), bq_kms_key_name), my_project, my_ctl_dataset)


def who():
    return "manage.py:" + os.environ.get("USER", os.environ.get("USERNAME", "admin"))


def main(argv=None, store=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("seed-roles"); sub.add_parser("list-users")
    s = sub.add_parser("seed-transform"); s.add_argument("source"); s.add_argument("file"); s.add_argument("--note", default="initial import")
    s = sub.add_parser("create-admin"); s.add_argument("username"); s.add_argument("--name", default="")
    for c in ("reset-password", "unlock"):
        sub.add_parser(c).add_argument("username")
    a = ap.parse_args(argv)
    st = store or connect()
    now = datetime.now(timezone.utc)

    if a.cmd == "seed-roles":
        made, updated = [], []
        for name, r in rbac.BUILTIN_ROLES.items():
            cur = st.get_role(name)
            if not cur:
                st.put_role(name, r["description"], r["permissions"], True, who(), "built-in role"); made.append(name)
                continue
            have = rbac.loads(cur["permissions"])                    # upgrade: ADD modules the role does not know yet, never change a level that is set
            missing = {m: lv for m, lv in r["permissions"].items() if m not in have}
            if missing:
                st.put_role(name, cur["description"], {**have, **missing}, cur["enabled"], who(), "new modules added by seed-roles: " + ", ".join(missing))
                updated.append(f"{name} (+{len(missing)} modules)")
        for cur in st.list_roles():                                  # custom roles: new modules default to No access (made explicit)
            if cur["role_name"] not in rbac.BUILTIN_ROLES:
                have = rbac.loads(cur["permissions"])
                missing = {m: rbac.NONE for m in rbac.MODULES if m not in have}
                if missing:
                    st.put_role(cur["role_name"], cur["description"], {**have, **missing}, cur["enabled"], who(), "new modules set to No access by seed-roles")
                    updated.append(f"{cur['role_name']} (+{len(missing)} modules, No access)")
        print("roles created:", ", ".join(made) or "none")
        print("roles upgraded:", ", ".join(updated) or "none")
    elif a.cmd == "seed-transform":
        import code_validate as cv
        code = open(a.file, encoding="utf-8").read()
        rep = cv.validate(code)                                  # syntax / interface / forbidden calls only (no schema or lookup list here)
        if not rep["ok"]:
            raise SystemExit("the file does not pass the basic checks:\n" + "\n".join(f"  line {f['line']}: {f['message']}" for f in rep["findings"] if f["level"] == "error"))
        try:
            v = st.transform.seed(a.source, code, who(), a.note)
        except Exception as e:
            raise SystemExit(str(e))
        st.audit("TRANSFORM_SEEDED", username=None, actor=who(), detail=f"{a.source} v{v} {len(code.splitlines())} lines")
        print(f"{a.source} transformation code loaded as version {v} ({len(code.splitlines())} lines). The GUI now owns it: edit and approve changes under Sources -> {a.source} -> Transformation code.")
    elif a.cmd == "create-admin":
        name = a.username.strip().lower()
        if st.get_user(name):
            raise SystemExit(f"user {name!r} already exists (use reset-password)")
        if not st.get_role("admin"):
            raise SystemExit("role 'admin' does not exist: run  seed-roles  first")
        temp = sec.generate_temp_password()
        st.put_user(name, {"display_name": a.name or name, "email": None, "role": "admin", "overrides": "{}", "enabled": True,
                           "password_hash": sec.hash_password(temp), "must_change_password": True, "password_changed_at": now},
                    by=who(), note="created by manage.py")
        st.audit("USER_CREATED", username=name, actor=who(), detail="role=admin (bootstrap)")
        print(f"administrator {name!r} created.\nTemporary password (shown once, must be changed at first sign-in):\n\n    {temp}\n")
    elif a.cmd == "reset-password":
        u = st.get_user(a.username.strip().lower())
        if not u:
            raise SystemExit("no such user")
        temp = sec.generate_temp_password()
        st.put_user(u["username"], {**u, "password_hash": sec.hash_password(temp), "must_change_password": True, "password_changed_at": now},
                    by=who(), note="password reset by manage.py")
        st.audit("PASSWORD_RESET", username=u["username"], actor=who())
        print(f"Temporary password for {u['username']} (shown once):\n\n    {temp}\n")
    elif a.cmd == "unlock":
        if not st.get_user(a.username.strip().lower()):
            raise SystemExit("no such user")
        st.audit("UNLOCK", username=a.username.strip().lower(), actor=who())
        print("unlocked")
    else:
        for u in st.list_users():
            print(f"{u['username']:24} {u['role']:12} {'enabled ' if u['enabled'] else 'DISABLED'} {u.get('display_name') or ''}")


if __name__ == "__main__":
    main()
