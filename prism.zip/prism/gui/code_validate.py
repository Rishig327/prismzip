"""
code_validate.py - general checks of a transformation's Python code BEFORE it can be approved. Static: the code is parsed, never run here
(code_dryrun.py runs it on sample records in a separate process).

What is checked (level: error blocks approval, warning / info do not)
  syntax      does it parse                                                                     error
  interface   class transform_record with process(self, row) that yields rows; setup(self)     error / warning
  imports     forbidden modules (os, sys, subprocess, socket, ...) error; modules outside the usual list warn
  calls       eval / exec / compile / __import__ / open / input ...                            error
  names       a name that is used but never defined anywhere it could come from (typos)        error
  schema      columns set in the output that are not in the detail table schema               warning (the plugin ignores them), with "did you mean"
  lookups     "lk_..." names used in the code that are not defined and enabled in the lookup table   error
  style       bare except, print, global, mutable default argument, while True without exit    warning
This catches mistakes; it cannot prove the business logic is right. Approval by a second person is the control for that.
"""
import ast
import builtins
import difflib
import re

MAX_BYTES = 500_000
ADDED_BY_PIPELINE = {"file_id", "attempt_no", "loaded_at"}            # PRISM adds these itself when it loads a row
FORBIDDEN_IMPORTS = {"os", "sys", "subprocess", "socket", "shutil", "ctypes", "importlib", "pickle", "marshal", "multiprocessing", "threading",
                     "signal", "requests", "urllib", "http", "ftplib", "smtplib", "telnetlib", "pathlib", "glob", "tempfile", "builtins", "gc",
                     "inspect", "code", "pdb", "webbrowser", "pty", "fcntl", "resource"}
USUAL_IMPORTS = {"re", "math", "json", "datetime", "decimal", "string", "typing", "collections", "itertools", "functools", "operator", "hashlib",
                 "base64", "logging", "time", "random", "apache_beam", "LookupsManager", "decode_functions", "__future__"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__", "open", "input", "breakpoint", "exit", "quit", "globals", "locals", "vars"}
FORBIDDEN_DUNDERS = {"__builtins__", "__subclasses__", "__globals__", "__code__", "__import__", "__loader__", "__bases__"}
LOOKUP_NAME = re.compile(r"^lk_[A-Za-z0-9_]+$")
_MODULE_NAMES = {"__name__", "__file__", "__doc__", "__package__", "__spec__", "__loader__", "__builtins__", "__class__", "__debug__"}


def _f(level, rule, line, message):
    return {"level": level, "rule": rule, "line": line, "message": message}


# ---------------------------------------------------------------------------------------------------- scope analysis (undefined names)
def _bound_in(node, include_nested_defs=True):
    """Names bound directly in this scope (not inside nested functions / classes / lambdas, except the name of the def / class itself)."""
    names, stack = set(), list(ast.iter_child_nodes(node))
    while stack:
        n = stack.pop()
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(n.name)
            continue                                         # its body is a scope of its own
        if isinstance(n, ast.Lambda):
            continue
        if isinstance(n, ast.Name) and isinstance(n.ctx, (ast.Store, ast.Del)):
            names.add(n.id)
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                names.add((a.asname or a.name).split(".")[0])
        elif isinstance(n, ast.ExceptHandler) and n.name:
            names.add(n.name)
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            names.update(n.names)
        elif isinstance(n, ast.arg):
            names.add(n.arg)
        elif hasattr(ast, "MatchAs") and isinstance(n, (ast.MatchAs, ast.MatchStar)) and n.name:
            names.add(n.name)
        elif hasattr(ast, "MatchMapping") and isinstance(n, ast.MatchMapping) and n.rest:
            names.add(n.rest)
        stack.extend(ast.iter_child_nodes(n))
    return names


def _args(fn):
    a = fn.args
    return {x.arg for x in a.posonlyargs + a.args + a.kwonlyargs} | ({a.vararg.arg} if a.vararg else set()) | ({a.kwarg.arg} if a.kwarg else set())


def undefined_names(tree):
    """[(line, name)] for names that are loaded but bound in no enclosing scope and are not builtins. Deliberately conservative: it may miss a
    problem (class scopes, comprehensions and lambdas are folded into their enclosing scope) but should not report a name that exists."""
    if any(isinstance(n, ast.ImportFrom) and any(a.name == "*" for a in n.names) for n in ast.walk(tree)):
        return []                                            # a star import defines unknown names: cannot judge
    known_builtins = set(dir(builtins)) | _MODULE_NAMES
    out = []

    def walk(scope_node, visible):
        bound = _bound_in(scope_node) | visible
        if isinstance(scope_node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            bound |= _args(scope_node)
        stack = list(ast.iter_child_nodes(scope_node))
        while stack:
            n = stack.pop()
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                for dec in n.decorator_list:                  # decorators / defaults / bases are evaluated in the OUTER scope
                    stack.append(dec)
                if isinstance(n, ast.ClassDef):
                    stack.extend(n.bases + [k.value for k in n.keywords])
                else:
                    stack.extend(d for d in n.args.defaults + n.args.kw_defaults if d is not None)
                walk(n, bound)
                continue
            if isinstance(n, ast.Lambda):
                walk(n, bound)
                continue
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in bound and n.id not in known_builtins:
                out.append((n.lineno, n.id))
            stack.extend(ast.iter_child_nodes(n))

    walk(tree, set())
    return sorted(set(out))


# ---------------------------------------------------------------------------------------------------- helpers over the tree
def _own_nodes(fn):
    """Nodes of a function body without descending into nested functions / classes."""
    stack = list(ast.iter_child_nodes(fn))
    while stack:
        n = stack.pop()
        yield n
        if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            stack.extend(ast.iter_child_nodes(n))


def _yielded_names(fn):
    names = set()
    for n in _own_nodes(fn):
        if isinstance(n, ast.Yield) and n.value is not None:
            v = n.value
            if isinstance(v, ast.Call) and isinstance(v.func, ast.Name) and v.func.id == "dict" and v.args:
                v = v.args[0]
            if isinstance(v, ast.Name):
                names.add(v.id)
    return names


def output_columns(tree, process_fn):
    """{column: first line} the code writes into the row it yields: out[...] = ..., out.update({...}), out = {...}, out.setdefault("X", ...)."""
    outs = (_yielded_names(process_fn) if process_fn else set()) or {"out_row"}
    cols = {}

    def add(key, line):
        if isinstance(key, ast.Constant) and isinstance(key.value, str):
            cols.setdefault(key.value, line)

    for n in ast.walk(tree):
        if isinstance(n, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
            targets = n.targets if isinstance(n, ast.Assign) else [n.target]
            for t in targets:
                if isinstance(t, ast.Subscript) and isinstance(t.value, ast.Name) and t.value.id in outs:
                    add(t.slice, n.lineno)
                if isinstance(t, ast.Name) and t.id in outs and isinstance(getattr(n, "value", None), ast.Dict):
                    for k in n.value.keys:
                        add(k, n.lineno)
        elif isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id in outs:
            if n.func.attr == "update" and n.args and isinstance(n.args[0], ast.Dict):
                for k in n.args[0].keys:
                    add(k, n.lineno)
            elif n.func.attr == "setdefault" and n.args:
                add(n.args[0], n.lineno)
    return cols


def input_fields(process_fn):
    """Names of the record fields the code reads: row.get("X") / row["X"], where row is process()'s first argument."""
    if process_fn is None or len(process_fn.args.args) < 2:
        return []
    row, found = process_fn.args.args[1].arg, []
    for n in ast.walk(process_fn):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "get" and isinstance(n.func.value, ast.Name) \
                and n.func.value.id == row and n.args and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str):
            found.append(n.args[0].value)
        elif isinstance(n, ast.Subscript) and isinstance(n.value, ast.Name) and n.value.id == row and isinstance(n.slice, ast.Constant) \
                and isinstance(n.slice.value, str):
            found.append(n.slice.value)
    return sorted(set(found))


def find_process(tree):
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "transform_record"), None)
    if cls is None:
        return None, None
    return cls, next((n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "process"), None)


# ---------------------------------------------------------------------------------------------------- the checks
def validate(code: str, schema_columns=None, known_lookups=None) -> dict:
    """-> {"ok", "errors", "warnings", "infos", "findings": [{level, rule, line, message}], "stats": {...}}. schema_columns: the detail table's
    column names; known_lookups: names of lookups that are defined AND enabled. None = that check is skipped (and an info says so)."""
    F = []
    stats = {"lines": 0, "output_columns": [], "input_fields": [], "lookups": []}

    def done():
        order = {"error": 0, "warning": 1, "info": 2}
        F.sort(key=lambda x: (order[x["level"]], x["line"] or 0))
        n = {lv: sum(1 for x in F if x["level"] == lv) for lv in order}
        return {"ok": n["error"] == 0, "errors": n["error"], "warnings": n["warning"], "infos": n["info"], "findings": F, "stats": stats}

    if not isinstance(code, str) or not code.strip():
        F.append(_f("error", "syntax", None, "The code is empty."))
        return done()
    if len(code.encode("utf-8")) > MAX_BYTES:
        F.append(_f("error", "syntax", None, f"The code is larger than {MAX_BYTES // 1000} KB."))
        return done()
    stats["lines"] = len(code.splitlines())
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        F.append(_f("error", "syntax", e.lineno, f"Syntax error: {e.msg}" + (f" (near: {e.text.strip()[:60]})" if e.text else "")))
        return done()

    # ---- interface
    cls, proc = find_process(tree)
    if cls is None:
        F.append(_f("error", "interface", None, "The code must define a class named transform_record (the plugin creates it and calls process(row))."))
    elif proc is None:
        F.append(_f("error", "interface", cls.lineno, "class transform_record has no process(self, row) method."))
    else:
        if len(proc.args.args) < 2:
            F.append(_f("error", "interface", proc.lineno, "process must take the record: def process(self, row)."))
        if not any(isinstance(n, (ast.Yield, ast.YieldFrom)) for n in _own_nodes(proc)):
            F.append(_f("warning", "interface", proc.lineno, "process never yields. The plugin expects it to yield one dict per output row."))
        setup = next((n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "setup"), None)
        if setup is not None and len(setup.args.args) != 1:
            F.append(_f("warning", "interface", setup.lineno, "setup is called without arguments: def setup(self)."))

    # ---- imports / calls / dunders
    for n in ast.walk(tree):
        if isinstance(n, (ast.Import, ast.ImportFrom)):
            mods = [a.name for a in n.names] if isinstance(n, ast.Import) else [("." * n.level) + (n.module or "")]
            for m in mods:
                root = m.split(".")[0]
                if m.startswith("."):
                    F.append(_f("error", "imports", n.lineno, f"Relative import {m!r}: the code is not part of a package."))
                elif root in FORBIDDEN_IMPORTS:
                    F.append(_f("error", "imports", n.lineno, f"Import of {root!r} is not allowed in transformation code (files, processes, network and low-level access)."))
                elif root not in USUAL_IMPORTS:
                    F.append(_f("warning", "imports", n.lineno, f"Import of {root!r} is not in the usual list ({', '.join(sorted(USUAL_IMPORTS - {'__future__'}))}). Make sure the worker image has it."))
        elif isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in FORBIDDEN_CALLS:
            F.append(_f("error", "calls", n.lineno, f"{n.func.id}() is not allowed in transformation code."))
        elif isinstance(n, ast.Name) and n.id in FORBIDDEN_DUNDERS or isinstance(n, ast.Attribute) and n.attr in FORBIDDEN_DUNDERS:
            F.append(_f("error", "calls", n.lineno, f"Use of {getattr(n, 'id', None) or n.attr} is not allowed."))

    # ---- undefined names
    everywhere = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)} | {n.arg for n in ast.walk(tree) if isinstance(n, ast.arg)} \
        | {n.name for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.ClassDef))} | _bound_in(tree)            # for "did you mean": names bound in ANY scope
    for line, name in undefined_names(tree):
        hint = difflib.get_close_matches(name, sorted(everywhere | set(dir(builtins))), n=1, cutoff=0.75)
        F.append(_f("error", "names", line, f"Name {name!r} is used but never defined" + (f" (did you mean {hint[0]!r}?)" if hint else "") + "."))

    # ---- output columns vs the detail table schema
    cols = output_columns(tree, proc)
    stats["output_columns"], stats["input_fields"] = sorted(cols), input_fields(proc)
    if schema_columns is None:
        F.append(_f("info", "schema", None, "The detail table schema is not available here, so the output columns were not compared with it."))
    else:
        schema = set(schema_columns)
        for c, line in sorted(cols.items(), key=lambda kv: kv[1]):
            if c in ADDED_BY_PIPELINE:
                F.append(_f("warning", "schema", line, f"Column {c} is added by PRISM when it loads the row; the value set here is overwritten."))
            elif c not in schema:
                hint = difflib.get_close_matches(c, schema, n=1, cutoff=0.7)
                F.append(_f("warning", "schema", line, f"Output column {c!r} is not in the detail table schema, so it is ignored" + (f" (did you mean {hint[0]!r}?)" if hint else "") + "."))
        mentioned = {n.value for n in ast.walk(tree) if isinstance(n, ast.Constant) and isinstance(n.value, str)}      # e.g. columns filled from a mapping in a loop
        unset = sorted(schema - set(cols) - mentioned - ADDED_BY_PIPELINE)
        if unset:
            F.append(_f("info", "schema", None, f"{len(unset)} detail column(s) are never mentioned in the code and will stay empty: {', '.join(unset[:25])}{' ...' if len(unset) > 25 else ''}"))

    # ---- lookups
    used = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and LOOKUP_NAME.match(n.value):
            used.setdefault(n.value, n.lineno)
    stats["lookups"] = sorted(used)
    if known_lookups is None:
        if used:
            F.append(_f("info", "lookups", None, "The lookup table is not available here, so the lookup names were not checked."))
    else:
        for name, line in sorted(used.items(), key=lambda kv: kv[1]):
            if name not in known_lookups:
                F.append(_f("error", "lookups", line, f"Lookup {name!r} is not defined (or is disabled) in the lookup table. The job would fail when it loads it."))

    # ---- style / risk
    for n in ast.walk(tree):
        if isinstance(n, ast.ExceptHandler) and n.type is None:
            F.append(_f("warning", "style", n.lineno, "Bare 'except:' also hides real errors. Use 'except Exception:' (or a specific error)."))
        elif isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "print":
            F.append(_f("warning", "style", n.lineno, "print() in worker code is easy to lose. Use the logging module."))
        elif isinstance(n, ast.Global):
            F.append(_f("warning", "style", n.lineno, "'global' makes the transformation depend on shared state between records."))
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for d in n.args.defaults + [k for k in n.args.kw_defaults if k is not None]:
                if isinstance(d, (ast.List, ast.Dict, ast.Set)):
                    F.append(_f("warning", "style", n.lineno, f"Mutable default argument in {n.name}(): it is shared between calls."))
        elif isinstance(n, ast.While) and isinstance(n.test, ast.Constant) and n.test.value is True:
            if not any(isinstance(x, (ast.Break, ast.Return)) for x in ast.walk(n)):
                F.append(_f("warning", "style", n.lineno, "'while True' with no break or return: this can loop forever."))
        elif isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "sleep":
            F.append(_f("warning", "style", n.lineno, "sleep() slows every record."))
    return done()
