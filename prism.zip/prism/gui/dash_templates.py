"""
dash_templates.py - starter dashboards a creator can copy. They use ONLY datasets and metrics that exist in dash_catalog.py
(verified against the PRISM DDL). TAP / ASN / AMA / CDR / profile-integrity templates are not offered because PRISM has no
tables for them yet; add them here when those datasets are added to the catalog.
"""
TEMPLATES = {
    "pipeline_ops": {
        "name": "Pipeline operations",
        "about": "Files and records processed, rejects, failed files and orchestrator runs.",
        "widgets": [
            {"type": "kpi", "title": "Files discovered", "dataset": "file_status", "metrics": ["files"], "span": 3},
            {"type": "kpi", "title": "Records loaded", "dataset": "file_status", "metrics": ["records_loaded"], "span": 3},
            {"type": "kpi", "title": "Reject rate", "dataset": "file_status", "metrics": ["reject_pct"], "span": 3, "decimals": 2},
            {"type": "kpi", "title": "Failed files", "dataset": "file_status", "metrics": ["files"], "span": 3,
             "filters": [{"field": "status", "op": "eq", "value": ["FAILED"]}]},
            {"type": "line", "title": "Files per day by status", "dataset": "file_status", "metrics": ["files"], "dims": ["status"], "time_grain": "day", "span": 8},
            {"type": "bar", "title": "Runs by status", "dataset": "pipeline_runs", "metrics": ["runs"], "dims": ["status"], "span": 4},
            {"type": "table", "title": "Files and records by source and status", "dataset": "file_status", "metrics": ["files", "records_loaded", "records_rejected"],
             "dims": ["source_type", "status"], "span": 12},
        ],
    },
    "recon_overview": {
        "name": "Reconciliation overview",
        "about": "Open alarms, mismatch rate and the worst reconciliations.",
        "widgets": [
            {"type": "kpi", "title": "Open alarms", "dataset": "recon_alarms", "metrics": ["alarms"], "span": 4,
             "filters": [{"field": "state", "op": "in", "value": ["PENDING", "OPEN", "ACKNOWLEDGED"]}]},
            {"type": "kpi", "title": "Mismatch rate", "dataset": "recon_results", "metrics": ["mismatch_pct"], "span": 4, "decimals": 2},
            {"type": "kpi", "title": "Largest difference %", "dataset": "recon_results", "metrics": ["max_diff_pct"], "span": 4},
            {"type": "line", "title": "Mismatch rate per day", "dataset": "recon_results", "metrics": ["mismatch_pct"], "time_grain": "day", "span": 8, "decimals": 2},
            {"type": "bar", "title": "Alarms by reconciliation", "dataset": "recon_alarms", "metrics": ["alarms"], "dims": ["recon_id"], "span": 4},
            {"type": "table", "title": "Results by reconciliation and status", "dataset": "recon_results", "metrics": ["result_rows", "total_diff", "avg_diff_pct"],
             "dims": ["recon_id", "status"], "span": 12},
        ],
    },
}
