"""
dash_access.py - who may do what with a dashboard. Pure functions; routes call them on EVERY request (the UI hiding a button is
never the control).

Two separate questions, always asked separately:
  1. DASHBOARD access  - may this user open / edit / publish / share this dashboard?   (this file)
  2. DATA access       - may this user read the data behind a widget?                   (dash_catalog.allowed_datasets, per widget)
A share gives (1) only. A viewer whose own role lacks the dataset's module sees "no access to this data" for that widget.

Modules (rbac.py):  dashboards  View = see dashboards shared with me,  Edit = create and edit my own (off for ordinary users)
                    dash_publish Edit = publish / unpublish / share dashboards I own
                    dash_admin   Edit = see every dashboard, edit / publish / share / archive any
"""
import rbac


def _lv(perms, module):
    return int(perms.get(module, 0))


def is_admin(perms) -> bool:
    return _lv(perms, "dash_admin") >= rbac.EDIT


def can_create(perms) -> bool:
    return _lv(perms, "dashboards") >= rbac.EDIT


def _owner_or_admin(username, perms, dash) -> bool:
    return dash["owner"] == username or is_admin(perms)


def can_edit(username, perms, dash) -> bool:
    return can_create(perms) and dash["status"] != "archived" and _owner_or_admin(username, perms, dash)


def can_publish(username, perms, dash) -> bool:
    """Publishing and sharing are separate from creating: the user needs the Publish & share module as well."""
    return (_lv(perms, "dash_publish") >= rbac.EDIT and _lv(perms, "dashboards") >= rbac.VIEW
            and dash["status"] != "archived" and _owner_or_admin(username, perms, dash))


can_share = can_publish


def can_archive(username, perms, dash) -> bool:
    return can_create(perms) and _owner_or_admin(username, perms, dash)


def can_view_draft(username, perms, dash) -> bool:
    return _lv(perms, "dashboards") >= rbac.VIEW and _owner_or_admin(username, perms, dash)


def can_view_published(username, role, perms, dash, shares) -> bool:
    """shares: iterable of (principal_type, principal) currently granted on this dashboard."""
    if _lv(perms, "dashboards") < rbac.VIEW or dash["status"] == "archived" or dash.get("published_version") is None:
        return False
    return dash["owner"] == username or ("user", username) in shares or ("role", role) in shares or is_admin(perms)


def can_see_at_all(username, role, perms, dash, shares) -> bool:
    """Used to answer 404 (not 403) so the existence and name of a private dashboard is never revealed."""
    return can_view_published(username, role, perms, dash, shares) or can_view_draft(username, perms, dash)
