"""
demo.py - sample data for `PRISM_GUI_DEV=1 python gui/app.py` and for the tests. Nothing here touches Google Cloud
and nothing is saved. DemoConfig has the same methods the GUI uses on config_store.ConfigStore, and applies the
SAME lookup validation (config_store.validate_lookup).
"""
import json
import os
import random
import secrets
import zlib
from datetime import datetime, timedelta, timezone

import config_store as cs
import dash_catalog as cat
import dash_exec
import dash_spec as sp
import dash_templates as tpl
import rbac
import security as sec
from app import create_app
from store import MemoryStore


def _t(): return datetime.now(timezone.utc)                                                           # noqa: E704


class DemoConfig:
    def __init__(self):
        self.lookups = {
            "lk_VFUK_R_UC_MVNO_IMSI": {"enabled": True, "table_name": "VFUK_R_UC_MVNO_IMSI", "key_fields": ["IMSI_PREFIX"], "value_fields": ["MVNO"], "match_type": "prefix", "changed_at": _t(), "changed_by": "seed", "note": None},
            "lk_VFUK_R_UC_APN_LIST": {"enabled": True, "table_name": "VFUK_R_UC_APN_LIST", "key_fields": ["APN", "TYPE", "NETWORK"], "value_fields": ["APN_GROUP"], "match_type": "exact", "changed_at": _t(), "changed_by": "seed", "note": None},
            "lk_VFUK_C_UC_PORTED": {"enabled": False, "table_name": "VFUK_C_UC_PORTED", "key_fields": ["MSISDN"], "value_fields": ["PORTED_TO"], "match_type": "exact", "changed_at": _t(), "changed_by": "seed", "note": None},
        }
        self.src = {"PGW": {"source_type": "PGW", "enabled": True, "input_prefix": "pgw/input/", "processed_prefix": "pgw/processed/",
                            "duplicate_prefix": "pgw/duplicate/", "quarantine_prefix": "pgw/quarantine/", "name_glob": "*.dat",
                            "conflict_policy": "reject", "lookup_window_days": 7, "min_age_seconds": 120, "ignore_suffixes": ".tmp,.part",
                            "detail_table": "vf-uk-raid-pre-prod.VPDB_DAT.VP_T_EVENTS_DETAIL_PGW", "max_reject_ratio": 0.01,
                            "changed_at": _t(), "changed_by": "seed", "note": None}}
        self.glob = {"max_attempts": 3, "batch_files": 500, "lease_min": 30, "max_job_wait_min": 240, "changed_at": _t(), "changed_by": "seed", "note": None}
        self.recons = {"pgw_daily_counts": {"recon_id": "pgw_daily_counts", "enabled": True, "description": "Files read vs rows loaded, per day"}}
        self.vers = []

    def latest_lookups(self): return {k: dict(v) for k, v in self.lookups.items()}                     # noqa: E704
    def sources(self): return sorted(self.src)                                                         # noqa: E704
    def latest_source(self, s): return dict(self.src[s]) if s in self.src else None                    # noqa: E704
    def latest_global(self): return dict(self.glob)                                                    # noqa: E704
    def latest_recons(self): return {k: dict(v) for k, v in self.recons.items()}                       # noqa: E704
    def history(self, table, key_col, key, limit=10): return [{**self.src[key], "_changed": ["(seed)"]}]    # noqa: E704
    def lookup_history(self, name, limit=10): return [{**r, "_changed": c} for r, c in self.vers if r["lookup_name"] == name][:limit]

    def set_lookup(self, name, changes, by, note=None, create=False, dry_run=False):
        cur = self.lookups.get(name)
        if cur is None and not create:
            raise cs.ConfigError(f"lookup {name!r} does not exist")
        new = {**{k: v for k, v in (cur or {}).items() if k in cs.LOOKUP_SPEC}, **changes}
        cs.validate_lookup(new, f"lookup {name} after the change")
        self.lookups[name] = {**new, "changed_at": _t(), "changed_by": by, "note": note}
        self.vers.insert(0, ({**new, "lookup_name": name, "changed_at": _t(), "changed_by": by, "note": note}, ["(edited in the GUI)"]))


class SampleRunner:
    """Stands in for BigQuery in demo mode and tests: fabricates rows with the shape of the query (deterministic per query).
    Records every query it was asked to run in .queries."""
    SAMPLE = {"source_type": ["PGW"], "recon_id": ["recon_pgw_records", "recon_pgw_files"], "measure": ["records", "files"]}

    def __init__(self):
        self.queries = []

    def run(self, q):
        self.queries.append(q)
        params = {n: v for n, _, v in q.params}
        rnd = random.Random(zlib.crc32((q.sql + str(params["range_start"].date())).encode()))      # stable for a day, different for the previous period
        tcol = next((c for c in q.columns if c["kind"] == "time"), None)
        dcols = [c for c in q.columns if c["kind"] == "dim"]
        mcols = [c for c in q.columns if c["kind"] == "metric"]
        times = []
        if tcol:
            step = {"hour": timedelta(hours=1), "day": timedelta(days=1), "week": timedelta(days=7), "month": timedelta(days=30)}[tcol["grain"]]
            end = min(params["range_end"], datetime.now(timezone.utc))
            t = end - step * 14
            while t < end:
                t0 = t.replace(minute=0, second=0, microsecond=0)
                times.append((t0 if tcol["grain"] == "hour" else t0.replace(hour=0)).isoformat())
                t += step

        def values(c):
            known = self.SAMPLE.get(c["ref"])
            field = cat.DATASETS[q.dataset]["fields"].get(c["ref"], {})
            return known or (field.get("values") or ["A", "B"])[:4]

        rows = [{}]
        if tcol:
            rows = [{"t": t} for t in times]
        for c in dcols:
            rows = [{**r, c["alias"]: v} for r in rows for v in values(c)]
        for r in rows:
            for m in mcols:
                r[m["alias"]] = round({"int": rnd.randint(20, 4000), "pct": rnd.uniform(0, 6)}.get(m["fmt"], rnd.uniform(1, 40)), 2)
        if not (tcol or dcols):
            rows = rows[:1]
        return dash_exec.Result(rows[:int(q.sql.rsplit("LIMIT", 1)[1])], 1_048_576, 4, False)


def seed_roles(store, by="seed"):
    for name, r in rbac.BUILTIN_ROLES.items():
        if not store.get_role(name):
            store.put_role(name, r["description"], r["permissions"], True, by, "built-in role")


def new_dashboard(store, owner, name, template=None, publish=False, share=(), dash_id=None, definition=None):
    dash_id = dash_id or "d_" + secrets.token_hex(6)
    defn = sp.validate_dashboard(definition)[0] if definition else sp.validate_dashboard({"widgets": tpl.TEMPLATES[template]["widgets"]})[0] if template else sp.default_dashboard()
    base = {"version": 1, "kind": "created", "name": name, "description": "", "owner": owner, "status": "active", "published_version": None,
            "published_at": None, "definition": json.dumps(defn)}
    store.dash_put(dash_id, base, by=owner, note="created")
    if publish:
        store.dash_put(dash_id, {**base, "kind": "publish", "published_version": 1, "published_at": datetime.now(timezone.utc)}, by=owner, note="published v1")
    for ptype, principal in share:
        store.share_put(dash_id, ptype, principal, True, owner)
    return dash_id


def new_user(store, username, password, role, display_name="", must_change=False, by="seed"):
    store.put_user(username, {"display_name": display_name or username, "email": None, "role": role, "overrides": "{}", "enabled": True,
                              "password_hash": sec.hash_password(password), "must_change_password": must_change,
                              "password_changed_at": _t()}, by=by, note="created")


def build_demo():
    store = MemoryStore()
    seed_roles(store)
    pw = "Demo-" + secrets.token_urlsafe(9) + "!7"
    new_user(store, "admin", pw, "admin", "Demo Administrator")
    new_user(store, "operator1", pw, "operator", "Demo Operator")
    new_user(store, "viewer1", pw, "viewer", "Demo Viewer")
    new_user(store, "creator1", pw, "dashboard-creator", "Demo Dashboard Creator")
    new_user(store, "publisher1", pw, "dashboard-publisher", "Demo Dashboard Publisher")
    new_user(store, "coder1", pw, "code-editor", "Demo Code Editor")
    new_user(store, "approver1", pw, "code-approver", "Demo Code Approver")
    seed = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sources", "pgw", "seed", "transformation_PGW.v1.py")
    if os.path.exists(seed):                                                   # the real PGW code as version 1, so the demo shows real code
        store.transform.seed("PGW", open(seed, encoding="utf-8").read(), "seed", "initial import")
    new_dashboard(store, "publisher1", "Pipeline operations", "pipeline_ops", publish=True, share=[("role", "viewer"), ("role", "operator")])
    new_dashboard(store, "publisher1", "Reconciliation overview (draft)", "recon_overview")
    return create_app(store, DemoConfig(), secrets.token_hex(32), dev=True, runner=SampleRunner()), pw
