"""
charts.py - turns a query result into something the templates can show: KPI value, SVG chart, table.

Charts are drawn as inline SVG on the server, so no chart library has to be shipped and the markup can be tested. Every piece of
dynamic text is HTML-escaped. Interactivity (tooltips, legend toggle, click-to-filter, drill) is added by static/dash.js from data
attributes written here:
    data-s   series name        data-tip  tooltip text        data-fk / data-fv   dashboard-filter key and value this mark represents
Without JavaScript the <title> children still give a native browser tooltip.
Types: kpi (with previous-period comparison), line, area, bar (grouped / stacked), donut, heatmap, table, pivot.
"""
import math
from datetime import datetime

from markupsafe import Markup, escape

import dash_catalog as cat
import dash_spec as sp

PALETTE = ["#e60000", "#25282b", "#00697c", "#5e2750", "#eb6100", "#fecb00", "#7e7e7e", "#0096ad"]
H, ML, MR, MT, MB = 280, 62, 14, 14, 46
WIDTH_BY_SPAN = {3: 300, 4: 360, 6: 520, 8: 640, 12: 960}      # drawing width follows the card width, so text keeps a readable size
MAX_HEAT = 24


def fmt(v, kind="int", decimals=1):
    if v is None:
        return "–"
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(escape(str(v)))
    if kind == "int":
        return f"{v:,.0f}"
    if kind == "pct":
        return f"{v:,.{decimals}f}%"
    return f"{v:,.{decimals}f}"


def _nice_ticks(lo, hi, n=5):
    if hi == lo:
        hi = lo + 1
    span = hi - lo
    step = 10 ** math.floor(math.log10(span / n))
    for m in (1, 2, 2.5, 5, 10):
        if span / (step * m) <= n:
            step *= m
            break
    t, ticks = math.floor(lo / step) * step, []
    while t <= hi + step * 0.5:
        ticks.append(round(t, 10))
        t += step
    return ticks


def _short(v, n=14):
    s = str(v)
    return s if len(s) <= n else s[: n - 1] + "…"


def _xlabel(v, grain):
    if grain and isinstance(v, str):
        try:
            d = datetime.fromisoformat(v)
            return {"hour": d.strftime("%d %b %H:00"), "day": d.strftime("%d %b"), "week": d.strftime("%d %b"), "month": d.strftime("%b %Y")}[grain]
        except ValueError:
            pass
    return _short(v)


def _tick(t, mcols):
    kind = mcols[0]["fmt"] if mcols else "int"
    if abs(t) >= 1_000_000:
        return f"{t / 1_000_000:g}M"
    if abs(t) >= 10_000:
        return f"{t / 1000:g}k"
    return f"{t:g}" + ("%" if kind == "pct" else "")


def _fattr(widget, col, value):
    """data-fk / data-fv for a mark that represents one value of a dimension (click-to-filter). Time buckets are not filters."""
    if not col or col["kind"] != "dim":
        return ""
    try:
        key = cat.filter_key(widget["dataset"], col["ref"])
    except KeyError:
        return ""
    return f' data-fk="{escape(key)}" data-fv="{escape(str(value))}"'


def _legend(items, widget=None):
    return [(n, c, d) for n, c, d in items]


# ---------------------------------------------------------------------------------------------------- line / area / bar
def _axis_data(widget, columns, rows):
    tcol = next((c for c in columns if c["kind"] == "time"), None)
    dcols = [c for c in columns if c["kind"] == "dim"]
    mcols = [c for c in columns if c["kind"] == "metric"]
    xcol = tcol or (dcols[0] if dcols else None)
    scol = dcols[0] if (tcol and dcols) else (dcols[1] if (not tcol and len(dcols) > 1) else None)      # series field (none for a time-only line)
    xs, series = [], {}
    for r in rows:
        x = r[xcol["alias"]]
        if x not in xs:
            xs.append(x)
        if scol:
            series.setdefault(str(r[scol["alias"]]), {})[x] = r[mcols[0]["alias"]]
        else:
            for m in mcols:
                series.setdefault(m["label"], {})[x] = r[m["alias"]]
    if len(series) > sp.MAX_SERIES:
        raise ValueError(f"Too many series ({len(series)}; the limit is {sp.MAX_SERIES}). Add a filter or group by a different field.")
    return xs, series, mcols, tcol, xcol, scol


def _svg_chart(widget, columns, rows):
    W = WIDTH_BY_SPAN.get(int(widget.get("span", 6)), 520)
    xs, series, mcols, tcol, xcol, scol = _axis_data(widget, columns, rows)
    names = list(series)
    vals = [v for s in series.values() for v in s.values() if v is not None]
    if not vals:
        return None
    wtype = widget["type"]
    bar, stacked = wtype == "bar", bool(widget.get("stacked")) and len(names) > 1 and min(vals) >= 0
    if stacked:
        lo, hi = 0, max(sum((series[n].get(x) or 0) for n in names) for x in xs)
    else:
        lo, hi = min(min(vals), 0) if (bar or wtype == "area") else min(vals), max(vals)
    ticks = _nice_ticks(lo, hi if hi > lo else lo + 1)
    lo, hi = min(ticks[0], lo), max(ticks[-1], hi)
    pw, ph = W - ML - MR, H - MT - MB
    sy = lambda v: MT + ph - (float(v) - lo) / ((hi - lo) or 1) * ph             # noqa: E731
    step = pw / max(len(xs), 1)
    sx = lambda i: ML + step * (i + 0.5)                                         # noqa: E731
    zero = sy(0) if lo <= 0 <= hi else sy(lo)
    o = [f'<svg class="chart" viewBox="0 0 {W} {H}" role="img" aria-label="{escape(widget["title"])}" preserveAspectRatio="xMidYMid meet">']
    for t in ticks:
        y = sy(t)
        o.append(f'<line x1="{ML}" y1="{y:.1f}" x2="{W - MR}" y2="{y:.1f}" stroke="#e4e4e4"/>'
                 f'<text x="{ML - 8}" y="{y + 4:.1f}" text-anchor="end" font-size="11" fill="#4a4d4e">{escape(_tick(t, mcols))}</text>')
    every = max(1, math.ceil(len(xs) / 10))
    for i, x in enumerate(xs):
        if i % every == 0:
            o.append(f'<text x="{sx(i):.1f}" y="{H - MB + 16}" text-anchor="middle" font-size="11" fill="#4a4d4e">{escape(_xlabel(x, tcol["grain"] if tcol else None))}'
                     f'<title>{escape(str(x))}</title></text>')
    o.append(f'<line x1="{ML}" y1="{zero:.1f}" x2="{W - MR}" y2="{zero:.1f}" stroke="#7e7e7e"/>')
    mfmt = (mcols[0]["fmt"], widget.get("decimals", 1))
    for k, n in enumerate(names):
        color, sa = PALETTE[k % len(PALETTE)], f' data-s="{escape(n)}"'
        fa = lambda x: _fattr(widget, scol if scol else xcol, n if scol else x)   # noqa: E731  (series dim, else the category dim)
        if bar:
            gw = step * 0.72
            bw = gw if stacked else gw / max(len(names), 1)
            for i, x in enumerate(xs):
                v = series[n].get(x)
                if v is None:
                    continue
                if stacked:
                    base = sum((series[m].get(x) or 0) for m in names[:k])
                    y0, y1, bx = sy(base + v), sy(base), sx(i) - gw / 2
                else:
                    y0, y1, bx = sy(max(v, 0)), (sy(min(v, 0)) if lo < 0 else sy(max(lo, 0))), sx(i) - gw / 2 + k * bw
                tip = f"{n} · {x if tcol else _short(x, 40)}: {fmt(v, *mfmt)}" if len(names) > 1 else f"{_short(x, 40)}: {fmt(v, *mfmt)}"
                o.append(f'<rect class="pt" x="{bx:.1f}" y="{min(y0, y1):.1f}" width="{max(bw - 1, 1):.1f}" height="{max(abs(y1 - y0), 0.5):.1f}" fill="{color}"{sa}{fa(x)}>'
                         f'<title>{escape(tip)}</title></rect>')
        else:
            segs, seg = [], []
            for i, x in enumerate(xs):
                v = series[n].get(x)
                if v is None:
                    if seg:
                        segs.append(seg); seg = []
                    continue
                seg.append((sx(i), sy(v), x, v))
            if seg:
                segs.append(seg)
            for sgm in segs:
                if wtype == "area" and len(sgm) > 1:
                    poly = " ".join(f"{a:.1f},{b:.1f}" for a, b, _, _ in sgm)
                    o.append(f'<polygon fill="{color}" fill-opacity="0.16" stroke="none" points="{sgm[0][0]:.1f},{zero:.1f} {poly} {sgm[-1][0]:.1f},{zero:.1f}"{sa}/>')
                if len(sgm) > 1:
                    o.append(f'<polyline fill="none" stroke="{color}" stroke-width="2.5" points="{" ".join(f"{a:.1f},{b:.1f}" for a, b, _, _ in sgm)}"{sa}/>')
                for a, b, x, v in sgm:
                    o.append(f'<circle class="pt" cx="{a:.1f}" cy="{b:.1f}" r="3.5" fill="{color}"{sa}{fa(x)}><title>{escape(n)} · {escape(str(x))}: {escape(fmt(v, *mfmt))}</title></circle>')
    o.append("</svg>")
    legend = [(n, PALETTE[k % len(PALETTE)], "") for k, n in enumerate(names)] if len(names) > 1 else []
    return Markup("".join(o)), legend


# ---------------------------------------------------------------------------------------------------- donut
def _arc(cx, cy, R, r, a0, a1):
    """Ring segment path from angle a0 to a1 (radians, 0 = 12 o'clock, clockwise)."""
    if a1 - a0 >= 2 * math.pi - 1e-6:
        a1 = a0 + 2 * math.pi - 1e-4
    pt = lambda rad, a: (cx + rad * math.sin(a), cy - rad * math.cos(a))        # noqa: E731
    (x0, y0), (x1, y1), (xi1, yi1), (xi0, yi0) = pt(R, a0), pt(R, a1), pt(r, a1), pt(r, a0)
    big = 1 if a1 - a0 > math.pi else 0
    return f"M{x0:.2f},{y0:.2f} A{R},{R} 0 {big} 1 {x1:.2f},{y1:.2f} L{xi1:.2f},{yi1:.2f} A{r},{r} 0 {big} 0 {xi0:.2f},{yi0:.2f} Z"


def _donut(widget, columns, rows):
    dcol = next(c for c in columns if c["kind"] == "dim")
    mcol = next(c for c in columns if c["kind"] == "metric")
    items = [(str(r[dcol["alias"]]), float(r[mcol["alias"]] or 0)) for r in rows]
    if any(v < 0 for _, v in items):
        raise ValueError("A donut chart needs values that are not negative. Use a bar chart for this metric.")
    total = sum(v for _, v in items)
    if total <= 0:
        return None
    additive = bool(cat.DATASETS[widget["dataset"]]["metrics"][mcol["ref"]].get("additive"))
    d = widget.get("decimals", 1)
    o, ang, legend = ['<svg class="chart donut" viewBox="0 0 260 260" role="img" aria-label="' + str(escape(widget["title"])) + '">'], 0.0, []
    for k, (n, v) in enumerate(items):
        if v <= 0:
            continue
        a1, color = ang + v / total * 2 * math.pi, PALETTE[k % len(PALETTE)]
        pct = f"{v / total * 100:.1f}%"
        tip = f"{n}: {fmt(v, mcol['fmt'], d)}" + (f" ({pct})" if additive else "")
        o.append(f'<path class="pt" d="{_arc(130, 130, 118, 72, ang, a1)}" fill="{color}" data-s="{escape(n)}"{_fattr(widget, dcol, n)}><title>{escape(tip)}</title></path>')
        legend.append((n, color, fmt(v, mcol["fmt"], d) + (f" · {pct}" if additive else "")))
        ang = a1
    if additive:
        o.append(f'<text x="130" y="128" text-anchor="middle" font-size="26" font-weight="700" fill="#25282b">{escape(fmt(total, mcol["fmt"], d))}</text>'
                 f'<text x="130" y="150" text-anchor="middle" font-size="12" fill="#7e7e7e">{escape(mcol["label"])}</text>')
    o.append("</svg>")
    return Markup("".join(o)), legend


# ---------------------------------------------------------------------------------------------------- heatmap
def _mix(t):
    """white-ish -> Vodafone red"""
    a, b = (253, 234, 234), (230, 0, 0)
    return "#%02x%02x%02x" % tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _heatmap(widget, columns, rows):
    tcol = next((c for c in columns if c["kind"] == "time"), None)
    dcols = [c for c in columns if c["kind"] == "dim"]
    mcol = next(c for c in columns if c["kind"] == "metric")
    xcol, ycol = (tcol, dcols[0]) if tcol else (dcols[1], dcols[0])
    xs = sorted({r[xcol["alias"]] for r in rows}, key=str)
    ys = sorted({str(r[ycol["alias"]]) for r in rows})
    if len(xs) > MAX_HEAT or len(ys) > MAX_HEAT:
        raise ValueError(f"Too many rows or columns for a heatmap (limit {MAX_HEAT} x {MAX_HEAT}). Add a filter or a shorter period.")
    cell = {(r[xcol["alias"]], str(r[ycol["alias"]])): r[mcol["alias"]] for r in rows}
    vals = [v for v in cell.values() if v is not None]
    if not vals:
        return None
    lo, hi = min(vals), max(vals)
    W, left, top = WIDTH_BY_SPAN.get(int(widget.get("span", 6)), 520), 100, 8
    cw, ch = (W - left - MR) / len(xs), min(34, 220 / max(len(ys), 1))
    Hh = top + ch * len(ys) + 34
    d, o = widget.get("decimals", 1), [f'<svg class="chart" viewBox="0 0 {W} {Hh:.0f}" role="img" aria-label="{escape(widget["title"])}">']
    for j, y in enumerate(ys):
        o.append(f'<text x="{left - 8}" y="{top + ch * j + ch / 2 + 4:.1f}" text-anchor="end" font-size="11" fill="#4a4d4e">{escape(_short(y, 16))}<title>{escape(y)}</title></text>')
    every = max(1, math.ceil(len(xs) / max(W // 60, 1)))
    for i, x in enumerate(xs):
        if i % every == 0:
            o.append(f'<text x="{left + cw * i + cw / 2:.1f}" y="{top + ch * len(ys) + 16:.1f}" text-anchor="middle" font-size="11" fill="#4a4d4e">{escape(_xlabel(x, tcol["grain"] if tcol else None))}</text>')
    for j, y in enumerate(ys):
        for i, x in enumerate(xs):
            v = cell.get((x, y))
            if v is None:
                continue
            t = 0.55 if hi == lo else (float(v) - lo) / (hi - lo)
            tip = f"{y} · {_xlabel(x, tcol['grain'] if tcol else None)}: {fmt(v, mcol['fmt'], d)}"
            o.append(f'<rect class="pt" x="{left + cw * i:.1f}" y="{top + ch * j:.1f}" width="{max(cw - 1.5, 1):.1f}" height="{max(ch - 1.5, 1):.1f}" fill="{_mix(0.08 + 0.92 * t)}"'
                     f' data-s="{escape(y)}"{_fattr(widget, ycol, y)}><title>{escape(tip)}</title></rect>')
            if cw >= 46:
                o.append(f'<text x="{left + cw * i + cw / 2:.1f}" y="{top + ch * j + ch / 2 + 4:.1f}" text-anchor="middle" font-size="10" pointer-events="none" fill="{"#fff" if t > 0.55 else "#25282b"}">{escape(fmt(v, mcol["fmt"], d))}</text>')
    o.append("</svg>")
    return Markup("".join(o)), [(f"{fmt(lo, mcol['fmt'], d)}  →  {fmt(hi, mcol['fmt'], d)}", _mix(0.5), "")]


# ---------------------------------------------------------------------------------------------------- tables
def _cell(r, c, d):
    v = r[c["alias"]]
    if c["kind"] == "metric":
        return fmt(v, c["fmt"], d)
    if c["kind"] == "time":
        return _xlabel(v, c.get("grain"))
    return "–" if v is None else str(v)


def _pivot(widget, columns, rows):
    d = widget.get("decimals", 1)
    rcol, ccol = [c for c in columns if c["kind"] == "dim"]
    mcol = next(c for c in columns if c["kind"] == "metric")
    cols = sorted({str(r[ccol["alias"]]) for r in rows})
    rws = sorted({str(r[rcol["alias"]]) for r in rows})
    if len(cols) > 12:
        raise ValueError(f"Too many columns for a pivot table ({len(cols)}; the limit is 12). Add a filter.")
    cell = {(str(r[rcol["alias"]]), str(r[ccol["alias"]])): r[mcol["alias"]] for r in rows}
    additive = bool(cat.DATASETS[widget["dataset"]]["metrics"][mcol["ref"]].get("additive"))
    head = [{"label": f"{rcol['label']} ↓ / {ccol['label']} →", "num": False}] + [{"label": c, "num": True} for c in cols] + ([{"label": "Total", "num": True}] if additive else [])
    body = []
    for rv in rws:
        line = [{"v": rv, "num": False}] + [{"v": fmt(cell.get((rv, c)), mcol["fmt"], d), "num": True} for c in cols]
        if additive:
            line.append({"v": fmt(sum(cell.get((rv, c)) or 0 for c in cols), mcol["fmt"], d), "num": True})
        body.append(line)
    return {"kind": "table", "head": head, "rows": body, "truncated": len(rows) >= widget["limit"]}


# ---------------------------------------------------------------------------------------------------- entry point
def _delta(cur, prev_rows, mcol):
    """Previous-period comparison for a KPI -> dict for the template, or None."""
    prev = prev_rows[0][mcol["alias"]] if prev_rows else None
    good = cat.DATASETS[mcol["dataset"]]["metrics"][mcol["ref"]].get("good") if mcol.get("dataset") else None
    if prev is None:
        return {"text": "no data in the previous period", "arrow": "", "tone": "neutral", "prev": ""}
    if float(prev) == 0:
        return {"text": "n/a", "arrow": "", "tone": "neutral", "prev": fmt(prev, mcol["fmt"], 1)}
    pct = (float(cur) - float(prev)) / abs(float(prev)) * 100
    direction = "up" if pct > 0.05 else "down" if pct < -0.05 else "flat"
    tone = "neutral" if (direction == "flat" or good is None) else ("good" if direction == good else "bad")
    return {"text": f"{pct:+.1f}%", "arrow": {"up": "▲", "down": "▼", "flat": "▬"}[direction], "tone": tone, "prev": fmt(prev, mcol["fmt"], 1)}


def render(widget: dict, columns: list, rows: list, prev_rows=None) -> dict:
    """-> {"kind": "kpi"|"svg"|"table"|"empty"|"error", ...} for templates/_widget.html"""
    decimals = widget.get("decimals", 1)
    try:
        wtype = widget["type"]
        if wtype == "kpi":
            m = {**next(c for c in columns if c["kind"] == "metric"), "dataset": widget["dataset"]}
            val = rows[0][m["alias"]] if rows else None
            if val is None:
                return {"kind": "empty"}
            out = {"kind": "kpi", "value": fmt(val, m["fmt"], decimals), "unit": "" if m["fmt"] == "pct" else m["unit"], "label": m["label"]}
            if widget.get("compare") and prev_rows is not None:
                out["delta"] = _delta(val, prev_rows, m)
            return out
        if not rows:
            return {"kind": "empty"}
        if wtype == "table":
            head = [{"label": c["label"] + (f" ({c['unit']})" if c["kind"] == "metric" and c["unit"] not in ("%", "") else ""), "num": c["kind"] == "metric"} for c in columns]
            return {"kind": "table", "head": head, "rows": [[{"v": _cell(r, c, decimals), "num": c["kind"] == "metric"} for c in columns] for r in rows],
                    "truncated": len(rows) >= widget["limit"]}
        if wtype == "pivot":
            return _pivot(widget, columns, rows)
        out = {"donut": _donut, "heatmap": _heatmap}.get(wtype, _svg_chart)(widget, columns, rows)
        if out is None:
            return {"kind": "empty"}
        return {"kind": "svg", "svg": out[0], "legend": out[1], "truncated": len(rows) >= widget["limit"]}
    except ValueError as e:
        return {"kind": "error", "message": str(e)}
