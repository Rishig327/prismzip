"""
dash_catalog.py - the APPROVED datasets, fields and governed metrics that Dashboard Studio may query.

Everything here is verified against sql/ddl.sql and sql/ddl_recon.sql (tests/test_gui_dashboards.py parses those files and
fails if a column or an expression refers to something that does not exist). Nothing is invented: PRISM has no financial /
revenue-exposure tables yet, so there are no money metrics. Add a dataset by adding an entry here (reviewed in git); users can
never type table names, columns or SQL - they only choose entries from this catalog.

dataset
  table       table in the PRISM control dataset (prism_settings.my_ctl_dataset)
  module      access module the USER must hold (View) for data from this dataset; a dashboard share never grants this
  time_field  partition column, ALWAYS filtered (cost control + partition pruning)
  fields      filterable / groupable columns (dimensions)
  metrics     governed measures: label, SQL aggregate expression (defined once, here), unit, format, meaning,
              additive (True for COUNT / SUM: totals and percentages of a total make sense), good ("down" = a falling value is good news,
              used to colour comparison arrows; absent = neutral)
  fields      "shared": a name that means the SAME thing in several datasets (source, recon). Dashboard filters and click-to-filter
              work on these; any other field filters only widgets of its own dataset.
  preview     columns shown by the limited data preview
"""
from prism_settings import my_ctl_dataset, my_project

OWNER = "PRISM platform team"

DATASETS = {
    "file_status": {
        "label": "File processing status",
        "about": "One row per file PRISM has seen (file_registry). Use it for files discovered, completed, failed or quarantined and for record counts.",
        "table": "file_registry", "module": "data_pipeline", "owner": OWNER,
        "time_field": "discovered_at", "time_label": "Discovered",
        "fields": {
            "source_type": {"label": "Source", "type": "STRING", "about": "Source system, for example PGW", "values": [], "shared": "source"},
            "status": {"label": "File status", "type": "STRING", "about": "Where the file is in its life cycle",
                       "values": ["DISCOVERED", "IN_PROGRESS", "COMPLETED", "FAILED", "QUARANTINED", "DUPLICATE", "SUPERSEDED"]},
        },
        "metrics": {
            "files": {"additive": True, "label": "Files", "expr": "COUNT(file_id)", "unit": "files", "fmt": "int", "about": "Number of distinct files"},
            "records_read": {"additive": True, "label": "Records read", "expr": "SUM(records_read)", "unit": "records", "fmt": "int", "about": "Records read from the files"},
            "records_loaded": {"additive": True, "label": "Records loaded", "expr": "SUM(records_loaded)", "unit": "records", "fmt": "int", "about": "Records loaded to the detail table"},
            "records_rejected": {"additive": True, "label": "Records rejected", "expr": "SUM(records_rejected)", "unit": "records", "fmt": "int", "about": "Records the pipeline rejected"},
            "reject_pct": {"good": "down", "label": "Reject rate", "expr": "SAFE_DIVIDE(SUM(records_rejected), NULLIF(SUM(records_read), 0)) * 100", "unit": "%", "fmt": "pct",
                           "about": "Rejected records as a percentage of records read"},
            "avg_attempts": {"good": "down", "label": "Average attempts", "expr": "AVG(attempt_count)", "unit": "attempts", "fmt": "dec", "about": "Average processing attempts per file"},
            "size_gb": {"additive": True, "label": "Data size", "expr": "SUM(size_bytes) / POW(1024, 3)", "unit": "GB", "fmt": "dec", "about": "Total size of the files in GB"},
        },
        "preview": ["source_type", "status", "attempt_count", "records_read", "records_loaded", "records_rejected", "size_bytes", "discovered_at", "completed_at"],
    },
    "pipeline_runs": {
        "label": "Pipeline runs",
        "about": "One row per orchestrator run (prism_runs).",
        "table": "prism_runs", "module": "data_pipeline", "owner": OWNER,
        "time_field": "started_at", "time_label": "Started",
        "fields": {
            "source_type": {"label": "Source", "type": "STRING", "about": "Source system", "values": [], "shared": "source"},
            "status": {"label": "Run status", "type": "STRING", "about": "Run state",
                       "values": ["STARTING", "CLAIMED", "LAUNCHED", "FINALISING", "DONE", "FAILED", "ABANDONED", "ORPHANED", "ADOPTED"]},
        },
        "metrics": {
            "runs": {"additive": True, "label": "Runs", "expr": "COUNT(run_id)", "unit": "runs", "fmt": "int", "about": "Number of orchestrator runs"},
            "avg_run_minutes": {"good": "down", "label": "Average run time", "expr": "AVG(TIMESTAMP_DIFF(finished_at, started_at, MINUTE))", "unit": "min", "fmt": "dec",
                                "about": "Minutes from start to finish (finished runs only)"},
        },
        "preview": ["source_type", "status", "started_at", "finished_at", "heartbeat_at"],
    },
    "recon_results": {
        "label": "Reconciliation results",
        "about": "Aggregate reconciliation result per window and measure (recon_result). diff = B minus A.",
        "table": "recon_result", "module": "data_recon", "owner": OWNER,
        "time_field": "window_start", "time_label": "Window start",
        "fields": {
            "recon_id": {"label": "Reconciliation", "type": "STRING", "about": "Reconciliation definition id", "values": [], "shared": "recon"},
            "status": {"label": "Result", "type": "STRING", "about": "Outcome of the comparison",
                       "values": ["MATCH", "MISMATCH", "MISSING_IN_A", "MISSING_IN_B"]},
            "measure": {"label": "Measure", "type": "STRING", "about": "What was compared", "values": []},
            "provisional": {"label": "Provisional", "type": "BOOL", "about": "Computed while recent files were still in flight", "values": ["true", "false"]},
        },
        "metrics": {
            "result_rows": {"additive": True, "label": "Result rows", "expr": "COUNT(recon_id)", "unit": "rows", "fmt": "int", "about": "Compared slices"},
            "mismatch_rows": {"good": "down", "additive": True, "label": "Non-matching rows", "expr": "COUNTIF(status != 'MATCH')", "unit": "rows", "fmt": "int", "about": "Slices whose status is not MATCH"},
            "mismatch_pct": {"good": "down", "label": "Mismatch rate", "expr": "SAFE_DIVIDE(COUNTIF(status != 'MATCH'), COUNT(recon_id)) * 100", "unit": "%", "fmt": "pct",
                             "about": "Non-matching slices as a percentage of all compared slices"},
            "total_diff": {"additive": True, "label": "Total difference (B - A)", "expr": "SUM(diff)", "unit": "units of the measure", "fmt": "dec", "about": "Sum of B minus A. Not a monetary value."},
            "avg_diff_pct": {"good": "down", "label": "Average difference %", "expr": "AVG(diff_pct)", "unit": "%", "fmt": "pct", "about": "Average |diff| / larger side"},
            "max_diff_pct": {"good": "down", "label": "Largest difference %", "expr": "MAX(diff_pct)", "unit": "%", "fmt": "pct", "about": "Largest |diff| / larger side"},
        },
        "preview": ["recon_id", "window_start", "measure", "a_value", "b_value", "diff", "diff_pct", "status", "provisional"],
    },
    "recon_alarms": {
        "label": "Reconciliation alarms",
        "about": "One row per alarm raised by a reconciliation (recon_alarm).",
        "table": "recon_alarm", "module": "data_recon", "owner": OWNER,
        "time_field": "window_start", "time_label": "Window start",
        "fields": {
            "recon_id": {"label": "Reconciliation", "type": "STRING", "about": "Reconciliation definition id", "values": [], "shared": "recon"},
            "state": {"label": "Alarm state", "type": "STRING", "about": "Alarm life cycle",
                      "values": ["PENDING", "OPEN", "ACKNOWLEDGED", "RESOLVED", "SUPPRESSED"]},
            "severity": {"label": "Severity", "type": "STRING", "about": "Alarm severity", "values": ["LOW", "MEDIUM", "HIGH"]},
        },
        "metrics": {
            "alarms": {"good": "down", "additive": True, "label": "Alarms", "expr": "COUNT(alarm_id)", "unit": "alarms", "fmt": "int", "about": "Number of alarms"},
            "max_breach_runs": {"good": "down", "label": "Longest breach", "expr": "MAX(breach_runs)", "unit": "runs", "fmt": "int", "about": "Most consecutive runs a breach was seen"},
            "avg_breach_runs": {"good": "down", "label": "Average breach", "expr": "AVG(breach_runs)", "unit": "runs", "fmt": "dec", "about": "Average consecutive runs a breach was seen"},
        },
        "preview": ["recon_id", "window_start", "state", "severity", "breach_runs", "first_raised_at", "last_seen_at", "resolved_at"],
    },
}


def table_ref(dataset_id: str) -> str:
    return f"{my_project}.{my_ctl_dataset}.{DATASETS[dataset_id]['table']}"


def allowed_datasets(perms: dict) -> dict:
    """Datasets this user may use: the user's OWN access module must be at least View. Dashboard sharing never changes this."""
    return {k: d for k, d in DATASETS.items() if int(perms.get(d["module"], 0)) >= 1}


def filter_key(dataset_id: str, field: str) -> str:
    """Key of a dashboard-level filter: the field's shared name, or '<dataset>.<field>' when it means something only in its dataset."""
    return DATASETS[dataset_id]["fields"][field].get("shared") or f"{dataset_id}.{field}"


def filter_keys() -> dict:
    """{key: {key, label, type, values, fields: {dataset_id: field}}} for every field a dashboard filter can use."""
    out = {}
    for ds_id, ds in DATASETS.items():
        for fname, f in ds["fields"].items():
            k = filter_key(ds_id, fname)
            e = out.setdefault(k, {"key": k, "label": f["label"] if f.get("shared") else f"{f['label']} ({ds['label']})", "type": f["type"],
                                   "values": list(f.get("values") or []), "fields": {}})
            e["fields"][ds_id] = fname
    return out
