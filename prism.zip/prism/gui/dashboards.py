"""
dashboards.py - Dashboard Studio routes. Registered by app.create_app().

Every route re-checks access on the server (dash_access.py for the DASHBOARD, dash_catalog.allowed_datasets for the DATA).
A dashboard the user may not see answers 404, so its existence and name are never revealed.
Query flow:  stored widget config -> validate (dash_spec) -> catalog-only SQL (build_query) -> BigQuery with cost caps (dash_exec) -> render (charts).
"""
import csv
import io
import json
import re
import secrets
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from flask import Response, abort, flash, g, redirect, render_template, request, url_for

import charts
import dash_access as acc
import dash_catalog as cat
import dash_spec as sp
import dash_templates as tpl
import rbac
from dash_exec import QueryError

ID_RE = re.compile(r"^d_[0-9a-f]{12}$")
NAME_MAX = 80
AUDIT_BYTES = 100 * 1024 ** 2          # single widget queries are audited when they scan at least this much, or fail (page views are always audited)


def _csv_safe(v):
    """Spreadsheet formula injection guard: a text cell that starts with = + - @ is prefixed with an apostrophe. Numbers stay numbers."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v


def register(app, store, runner, need, audit, forget):

    def now():
        return datetime.now(timezone.utc)

    def me():
        return g.user["username"]

    def shares_of(dash_id):
        return {(r["principal_type"], r["principal"]) for r in store.share_list(dash_id)}

    def load(dash_id):
        if not ID_RE.match(dash_id or ""):
            abort(404)
        d = store.dash_get(dash_id)
        if d is None:
            abort(404)
        return d

    def definition_of(row):
        try:
            clean, _ = sp.validate_dashboard(json.loads(row["definition"]))
            return clean
        except (TypeError, ValueError):
            return sp.default_dashboard()

    def status_of(d):
        if d["status"] == "archived":
            return "Archived"
        if d.get("published_version") is None:
            return "Draft"
        return "Published" if d["published_version"] == d["version"] else "Published (newer draft)"

    def see_or_404(d):
        if not acc.can_see_at_all(me(), g.user["role"], g.perms, d, shares_of(d["dashboard_id"])):
            abort(404)

    def edit_or_404(d):
        see_or_404(d)
        if not acc.can_edit(me(), g.perms, d):
            abort(403)

    def save_version(d, new_def, kind, note, **changes):
        row = {**d, "version": d["version"] + 1, "kind": kind, "definition": json.dumps(new_def), **changes}
        store.dash_put(d["dashboard_id"], row, by=me(), note=note)
        forget()
        return row

    def stale(d):
        """Two editors at once: the form carries the version it was opened at."""
        if request.form.get("ver") != str(d["version"]):
            flash("This dashboard was changed by someone else since you opened it. Review the current version and try again.", "error")
            return redirect(url_for("dash_edit", dash_id=d["dashboard_id"]))
        return None

    def clean_name(raw):
        name = (raw or "").strip()
        if not name or len(name) > NAME_MAX:
            return None
        return name

    def date_range(default_preset, quiet=False):
        try:
            if request.args.get("start") or request.args.get("end"):
                st_, en_ = sp.resolve_range(start=request.args.get("start"), end=request.args.get("end"))
                return st_, en_, {"start": request.args.get("start"), "end": request.args.get("end")}
            preset = request.args.get("range") or default_preset
            st_, en_ = sp.resolve_range(preset)
            return st_, en_, {"range": preset}
        except sp.SpecError as err:
            if not quiet:
                flash(" ".join(err.problems), "error")
            st_, en_ = sp.resolve_range(default_preset)
            return st_, en_, {"range": default_preset}

    def active_filters(defn, quiet=False):
        """Dashboard filters the viewer chose (only the ones the creator enabled)."""
        active, problems = sp.parse_active_filters(request.args, defn.get("filters", []))
        if not quiet:
            for p_ in problems:
                flash(p_, "error")
        return active

    def run_one(w, start, end, active):
        """One widget -> (render dict, bytes scanned, millis). A KPI with comparison runs a second query for the previous period."""
        w = sp.apply_filters(w, active)
        try:
            q = sp.build_query(w, start, end)
            res = runner.run(q)
            prev, nbytes, ms = None, res.bytes_processed, res.millis
            if w["type"] == "kpi" and w.get("compare"):
                ps, pe = sp.previous_range(start, end)
                pr = runner.run(sp.build_query(w, ps, pe))
                prev, nbytes, ms = pr.rows, nbytes + pr.bytes_processed, ms + pr.millis
            return charts.render(w, q.columns, res.rows, prev), nbytes, ms
        except (QueryError, sp.SpecError) as e:
            return {"kind": "error", "message": str(e)}, 0, 0

    def run_widgets(widgets, start, end, active):
        """Synchronous mode (no JavaScript / lazy=0): every widget the USER may read, a few at a time. -> ({id: render}, telemetry)"""
        allowed, out, jobs = cat.allowed_datasets(g.perms), {}, []
        for w in widgets:
            if w["dataset"] in allowed:
                jobs.append(w)
            else:
                out[w["id"]] = {"kind": "denied"}
        tel = {"queries": 0, "bytes": 0, "millis": 0, "errors": 0}
        with ThreadPoolExecutor(max_workers=4) as ex:
            for w, (r, nbytes, ms) in zip(jobs, ex.map(lambda x: run_one(x, start, end, active), jobs)):
                out[w["id"]] = r
                tel["queries"] += 1
                tel["bytes"] += nbytes
                tel["millis"] += ms
                tel["errors"] += r["kind"] == "error"
        return out, tel

    def resolve_view(dash_id, allow_redirect=False):
        """The one place that decides WHICH version of a dashboard this user may see: -> (dashboard row, version row, mode)."""
        d = load(dash_id)
        draft = request.args.get("draft") == "1"
        if draft:
            if not acc.can_view_draft(me(), g.perms, d):
                abort(404)
            return d, d, "draft"
        if acc.can_view_published(me(), g.user["role"], g.perms, d, shares_of(dash_id)):
            return d, store.dash_row(dash_id, d["published_version"]) or abort(404), "published"
        if allow_redirect and acc.can_view_draft(me(), g.perms, d):
            return d, None, "redirect"
        abort(404)

    def view_context(defn, quiet=False):
        keys = cat.filter_keys()
        enabled = [keys[k] for k in defn.get("filters", []) if k in keys]
        return {"filter_defs": enabled, "labels": {f["key"]: f["label"] for f in enabled}}

    # ------------------------------------------------------------------ gallery
    @app.get("/dashboards")
    @need("dashboards")
    def dash_gallery():
        creator, admin, user = acc.can_create(g.perms), acc.is_admin(g.perms), me()
        tab = request.args.get("tab") or ("mine" if creator else "shared")
        if tab == "mine" and not creator or tab == "all" and not admin or tab == "templates" and not creator or tab not in ("mine", "shared", "all", "templates"):
            tab = "shared"
        q, sort = (request.args.get("q") or "").strip().lower(), request.args.get("sort") or "updated"
        everything, shares = store.dash_list(), store.shares_all()
        rows = []
        if tab == "mine":
            rows = [{**d, "via": ""} for d in everything if d["owner"] == user and (d["status"] != "archived" or request.args.get("archived") == "1")]
        elif tab == "shared":
            for d in everything:
                sh = shares.get(d["dashboard_id"], set())
                direct, via_role = ("user", user) in sh, ("role", g.user["role"]) in sh
                if d["owner"] != user and (direct or via_role) and acc.can_view_published(user, g.user["role"], g.perms, d, sh):
                    rows.append({**d, "via": "you" if direct else f"role {g.user['role']}"})
        elif tab == "all":
            rows = [{**d, "via": ""} for d in everything]
        if q:
            rows = [r for r in rows if q in r["name"].lower() or q in (r["description"] or "").lower() or q in r["owner"].lower()]
        rows.sort(key=(lambda r: r["name"].lower()) if sort == "name" else (lambda r: r["changed_at"]), reverse=(sort != "name"))
        for r in rows:
            r["status_label"] = status_of(r)
        return render_template("dash_gallery.html", rows=rows, tab=tab, q=q, sort=sort, creator=creator, admin=admin, templates=tpl.TEMPLATES, active_nav="dashboards")

    @app.post("/dashboards/new")
    @need("dashboards", rbac.EDIT)
    def dash_new():
        name = clean_name(request.form.get("name"))
        if not name:
            flash(f"Give the dashboard a name of 1-{NAME_MAX} characters.", "error")
            return redirect(url_for("dash_gallery"))
        template = request.form.get("template") or ""
        if template and template not in tpl.TEMPLATES:
            abort(400, "Unknown template.")
        defn, _ = sp.validate_dashboard({"widgets": tpl.TEMPLATES[template]["widgets"]}) if template else (sp.default_dashboard(), [])
        dash_id = "d_" + secrets.token_hex(6)
        store.dash_put(dash_id, {"version": 1, "kind": "created", "name": name, "description": (tpl.TEMPLATES[template]["about"] if template else ""),
                                 "owner": me(), "status": "active", "published_version": None, "published_at": None,
                                 "definition": json.dumps(defn)}, by=me(), note="from template " + template if template else "created")
        forget()
        audit("DASHBOARD_CREATED", me(), f"{dash_id} {name}" + (f" from template {template}" if template else ""))
        return redirect(url_for("dash_edit", dash_id=dash_id))

    # ------------------------------------------------------------------ catalog (datasets the user may use)
    @app.get("/dashboards/catalog")
    @need("dashboards", rbac.EDIT)
    def dash_catalog():
        return render_template("dash_catalog.html", datasets=cat.allowed_datasets(g.perms), hidden=len(cat.DATASETS) - len(cat.allowed_datasets(g.perms)), active_nav="dashboards")

    @app.get("/dashboards/catalog/<ds_id>/preview")
    @need("dashboards", rbac.EDIT)
    def dash_preview(ds_id):
        ds = cat.allowed_datasets(g.perms).get(ds_id)
        if ds is None:
            abort(404)
        start, end = sp.resolve_range("last_7_days")
        q = sp.build_preview(ds_id, start, end)
        try:
            res = runner.run(q)
            rendered = charts.render({"type": "table", "limit": 20, "decimals": 1}, q.columns, res.rows)
            audit("DATA_PREVIEW", me(), f"{ds_id} bytes={res.bytes_processed} ms={res.millis}")
        except QueryError as e:
            rendered = {"kind": "error", "message": str(e)}
        return render_template("dash_preview.html", ds_id=ds_id, ds=ds, r=rendered, active_nav="dashboards")

    # ------------------------------------------------------------------ viewer
    @app.get("/dashboards/<dash_id>")
    @need("dashboards")
    def dash_view(dash_id):
        d, row, mode = resolve_view(dash_id, allow_redirect=True)
        if mode == "redirect":
            return redirect(url_for("dash_view", dash_id=dash_id, draft=1))          # owner / admin of an unpublished or archived dashboard
        defn = definition_of(row)
        start, end, qs = date_range(defn["date"]["preset"])
        active = active_filters(defn)
        lazy = request.args.get("lazy") != "0"
        results, tel = ({}, {"queries": 0, "bytes": 0, "millis": 0, "errors": 0}) if lazy else run_widgets(defn["widgets"], start, end, active)
        audit("DASHBOARD_VIEWED", me(), f"{dash_id} v{row['version']} {mode} widgets={len(defn['widgets'])} lazy={int(lazy)} queries={tel['queries']} "
                                         f"errors={tel['errors']} bytes={tel['bytes']} ms={tel['millis']}")
        return render_template("dash_view.html", d=d, row=row, defn=defn, results=results, tel=tel, mode=mode, qs=qs, start=start, end=end, presets=sp.PRESETS,
                               can_edit=acc.can_edit(me(), g.perms, d), can_publish=acc.can_publish(me(), g.perms, d), status=status_of(d), lazy=lazy,
                               show_cost=acc.can_view_draft(me(), g.perms, d), now=now(), active=active, active_nav="dashboards",
                               export_ok=rbac.allowed(g.perms, "dash_export"), **view_context(defn))

    @app.get("/dashboards/<dash_id>/widgets/<wid>/render")
    @need("dashboards")
    def dash_widget_render(dash_id, wid):
        """HTML fragment of ONE widget, loaded by static/dash.js when the widget scrolls into view (and on refresh). Same checks as the page."""
        d, row, mode = resolve_view(dash_id)
        defn = definition_of(row)
        w = next((x for x in defn["widgets"] if x["id"] == wid), None) or abort(404)
        start, end, _ = date_range(defn["date"]["preset"], quiet=True)
        active = active_filters(defn, quiet=True)
        if w["dataset"] not in cat.allowed_datasets(g.perms):
            r, nbytes, ms = {"kind": "denied"}, 0, 0
        else:
            r, nbytes, ms = run_one(w, start, end, active)
            if r["kind"] == "error" or nbytes >= AUDIT_BYTES:
                audit("WIDGET_QUERY", me(), f"{dash_id} {wid} {w['dataset']} {'FAILED' if r['kind'] == 'error' else 'ok'} bytes={nbytes} ms={ms}")
        export_url = url_for("dash_export", dash_id=dash_id, wid=wid, **request.args.to_dict()) if rbac.allowed(g.perms, "dash_export") and r["kind"] not in ("denied", "error") else ""
        return render_template("dash_widget_body.html", w=w, r=r, updated=now(), export_url=export_url, nbytes=nbytes, ms=ms,
                               show_cost=acc.can_view_draft(me(), g.perms, d))

    @app.get("/dashboards/<dash_id>/widgets/<wid>/export.csv")
    @need("dashboards")
    def dash_export(dash_id, wid):
        """CSV of one widget's result. Separate permission (Export data), the user's own data access, same row limit as the widget, audited."""
        if not rbac.allowed(g.perms, "dash_export"):
            audit("ACCESS_DENIED", me(), f"export {dash_id}")
            abort(403)
        d, row, mode = resolve_view(dash_id)
        defn = definition_of(row)
        w = next((x for x in defn["widgets"] if x["id"] == wid), None) or abort(404)
        if w["dataset"] not in cat.allowed_datasets(g.perms):
            abort(403)
        start, end, _ = date_range(defn["date"]["preset"], quiet=True)
        q = sp.build_query(sp.apply_filters(w, active_filters(defn, quiet=True)), start, end)
        try:
            res = runner.run(q)
        except QueryError as e:
            abort(400, str(e))
        out = io.StringIO()
        cw = csv.writer(out)
        cw.writerow([c["label"] + (f" ({c['unit']})" if c["kind"] == "metric" and c["unit"] else "") for c in q.columns])
        for r_ in res.rows:
            cw.writerow([_csv_safe(r_[c["alias"]]) for c in q.columns])
        slug = re.sub(r"[^a-z0-9]+", "_", f"{d['name']}_{w['title']}".lower()).strip("_")[:60] or "export"
        audit("DATA_EXPORTED", me(), f"{dash_id} {wid} {w['dataset']} rows={len(res.rows)} bytes={res.bytes_processed}")
        return Response(out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f'attachment; filename="{slug}.csv"'})

    # ------------------------------------------------------------------ editor
    @app.get("/dashboards/<dash_id>/edit")
    @need("dashboards", rbac.EDIT)
    def dash_edit(dash_id):
        d = load(dash_id)
        edit_or_404(d)
        defn = definition_of(d)
        start, end, qs = date_range(defn["date"]["preset"])
        active = active_filters(defn)
        lazy = request.args.get("lazy") != "0"
        results, tel = ({}, {"queries": 0, "bytes": 0, "millis": 0, "errors": 0}) if lazy else run_widgets(defn["widgets"], start, end, active)
        return render_template("dash_edit.html", d=d, defn=defn, results=results, tel=tel, qs=qs, status=status_of(d), types=sp.WIDGET_TYPES, lazy=lazy,
                               datasets=cat.allowed_datasets(g.perms), presets=sp.PRESETS, can_publish=acc.can_publish(me(), g.perms, d),
                               can_archive=acc.can_archive(me(), g.perms, d), max_widgets=sp.MAX_WIDGETS, active_nav="dashboards", active=active,
                               all_filter_keys=cat.filter_keys(), refresh_options=sp.REFRESH_MINUTES, export_ok=rbac.allowed(g.perms, "dash_export"),
                               **view_context(defn))

    @app.post("/dashboards/<dash_id>/layout")
    @need("dashboards", rbac.EDIT)
    def dash_layout(dash_id):
        """Saves the drag / resize result: the new order and widths. Only reorders and resizes what already exists."""
        d = load(dash_id)
        edit_or_404(d)
        if (r := stale(d)):
            return r
        defn = definition_of(d)
        by = {w["id"]: w for w in defn["widgets"]}
        order = [x for x in (request.form.get("order") or "").split(",") if x]
        if sorted(order) != sorted(by):
            flash("The widgets on this dashboard changed. Reload the editor and try again.", "error")
            return redirect(url_for("dash_edit", dash_id=dash_id))
        spans = {}
        for pair in (request.form.get("spans") or "").split(","):
            k, _, v = pair.partition(":")
            if k in by and v.isdigit() and int(v) in sp.SPANS:
                spans[k] = int(v)
        new = [{**by[i], "span": spans.get(i, by[i]["span"])} for i in order]
        if new == defn["widgets"]:
            flash("The layout is unchanged.", "info")
            return redirect(url_for("dash_edit", dash_id=dash_id))
        defn["widgets"] = new
        save_version(d, defn, "save", "layout")
        audit("DASHBOARD_SAVED", me(), f"{dash_id} layout")
        flash("Layout saved as a new draft version.", "ok")
        return redirect(url_for("dash_edit", dash_id=dash_id))

    @app.post("/dashboards/<dash_id>/settings")
    @need("dashboards", rbac.EDIT)
    def dash_settings(dash_id):
        d = load(dash_id)
        edit_or_404(d)
        if (r := stale(d)):
            return r
        name = clean_name(request.form.get("name"))
        if not name:
            flash(f"Give the dashboard a name of 1-{NAME_MAX} characters.", "error")
            return redirect(url_for("dash_edit", dash_id=dash_id))
        defn = definition_of(d)
        preset = request.form.get("preset")
        defn["date"] = {"preset": preset if preset in sp.PRESETS else defn["date"]["preset"]}
        defn["filters"] = request.form.getlist("dfilter")
        defn["refresh"] = request.form.get("refresh") or 0
        defn, errs = sp.validate_dashboard(defn)
        if errs:
            for e_ in errs:
                flash(e_, "error")
            return redirect(url_for("dash_edit", dash_id=dash_id))
        save_version(d, defn, "save", "settings", name=name, description=(request.form.get("description") or "").strip()[:300])
        audit("DASHBOARD_SAVED", me(), f"{dash_id} settings")
        flash("Saved as a new draft version.", "ok")
        return redirect(url_for("dash_edit", dash_id=dash_id))

    # ---- widgets
    def widget_from_form(f, wid=None):
        flt = []
        for i in range(3):
            field = f.get(f"flt_field_{i}", "")
            if not field:
                continue
            op, raw = f.get(f"flt_op_{i}", "eq"), f.get(f"flt_value_{i}", "")
            flt.append({"field": field, "op": op, "value": [v.strip() for v in raw.split(",")] if op == "in" else [raw.strip()]})
        return {"id": wid, "type": f.get("type"), "dataset": f.get("dataset"), "title": f.get("title"), "description": f.get("description"),
                "metrics": f.getlist("metrics"), "dims": [x for x in (f.get("dim0"), f.get("dim1")) if x], "time_grain": f.get("time_grain") or None,
                "filters": flt, "sort": {"by": f.get("sort_by"), "dir": f.get("sort_dir")}, "limit": f.get("limit"), "span": f.get("span"),
                "stacked": f.get("stacked") == "on", "decimals": f.get("decimals"), "compare": f.get("compare") == "on"}

    def widget_form_page(d, w, errors=None, preview=None, creating=True):
        ds = cat.allowed_datasets(g.perms).get(w.get("dataset"))
        if ds is None:
            abort(403)
        return render_template("dash_widget_form.html", d=d, w=w, ds=ds, errors=errors or [], preview=preview, creating=creating, types=sp.WIDGET_TYPES,
                               grains=sp.GRAINS, ops=sp.FILTER_OPS, spans=sp.SPANS, active_nav="dashboards")

    @app.get("/dashboards/<dash_id>/widgets/new")
    @need("dashboards", rbac.EDIT)
    def dash_widget_new(dash_id):
        d = load(dash_id)
        edit_or_404(d)
        wtype, ds_id = request.args.get("type"), request.args.get("dataset")
        if wtype not in sp.WIDGET_TYPES or ds_id not in cat.DATASETS:
            flash("Choose a widget type and a dataset.", "error")
            return redirect(url_for("dash_edit", dash_id=dash_id))
        return widget_form_page(d, {"type": wtype, "dataset": ds_id, "span": 3 if wtype == "kpi" else 6, "limit": sp.LIMIT_BY_TYPE.get(wtype, sp.LIMIT_DEFAULT), "decimals": 1,
                                    "metrics": [], "dims": [], "filters": [], "sort": {}}, creating=True)

    def save_widget(d, wid=None):
        w = widget_from_form(request.form, wid)
        clean, errs = sp.validate_widget(w)
        if clean and clean["dataset"] not in cat.allowed_datasets(g.perms):
            abort(403)
        defn = definition_of(d)
        if wid is None and len(defn["widgets"]) >= sp.MAX_WIDGETS:
            errs.append(f"A dashboard can have at most {sp.MAX_WIDGETS} widgets.")
        if request.form.get("action") == "preview" and clean and not errs:
            start, end = sp.resolve_range(defn["date"]["preset"])
            res, _ = run_widgets([clean], start, end, {})
            return widget_form_page(d, {**w, **clean}, preview=(clean, res[clean["id"]]), creating=wid is None)
        if errs:
            return widget_form_page(d, {**w, "span": request.form.get("span"), "limit": request.form.get("limit")}, errors=errs, creating=wid is None)
        if wid is None:
            defn["widgets"].append(clean)
        else:
            defn["widgets"] = [clean if x["id"] == wid else x for x in defn["widgets"]]
        save_version(d, defn, "save", f"widget {'added' if wid is None else 'changed'}: {clean['title']}")
        audit("DASHBOARD_SAVED", me(), f"{d['dashboard_id']} widget {clean['id']} {clean['type']} {clean['dataset']}")
        flash("Widget saved.", "ok")
        return redirect(url_for("dash_edit", dash_id=d["dashboard_id"]))

    @app.post("/dashboards/<dash_id>/widgets")
    @need("dashboards", rbac.EDIT)
    def dash_widget_create(dash_id):
        d = load(dash_id)
        edit_or_404(d)
        return stale(d) or save_widget(d)

    @app.route("/dashboards/<dash_id>/widgets/<wid>", methods=["GET", "POST"])
    @need("dashboards", rbac.EDIT)
    def dash_widget_edit(dash_id, wid):
        d = load(dash_id)
        edit_or_404(d)
        cur = next((x for x in definition_of(d)["widgets"] if x["id"] == wid), None)
        if cur is None:
            abort(404)
        if request.method == "POST":
            return stale(d) or save_widget(d, wid)
        return widget_form_page(d, cur, creating=False)

    @app.post("/dashboards/<dash_id>/widgets/<wid>/delete")
    @need("dashboards", rbac.EDIT)
    def dash_widget_delete(dash_id, wid):
        d = load(dash_id)
        edit_or_404(d)
        if (r := stale(d)):
            return r
        defn = definition_of(d)
        if not any(x["id"] == wid for x in defn["widgets"]):
            abort(404)
        defn["widgets"] = [x for x in defn["widgets"] if x["id"] != wid]
        save_version(d, defn, "save", f"widget removed: {wid}")
        audit("DASHBOARD_SAVED", me(), f"{dash_id} widget {wid} removed")
        flash("Widget removed.", "ok")
        return redirect(url_for("dash_edit", dash_id=dash_id))

    @app.post("/dashboards/<dash_id>/widgets/<wid>/move")
    @need("dashboards", rbac.EDIT)
    def dash_widget_move(dash_id, wid):
        d = load(dash_id)
        edit_or_404(d)
        if (r := stale(d)):
            return r
        defn, ws = definition_of(d), definition_of(d)["widgets"]
        i = next((k for k, x in enumerate(ws) if x["id"] == wid), None)
        if i is None:
            abort(404)
        j = i - 1 if request.form.get("dir") == "up" else i + 1
        if 0 <= j < len(ws):
            ws[i], ws[j] = ws[j], ws[i]
            defn["widgets"] = ws
            save_version(d, defn, "save", "widget moved")
        return redirect(url_for("dash_edit", dash_id=dash_id))

    # ------------------------------------------------------------------ publish / archive / duplicate / restore
    @app.post("/dashboards/<dash_id>/publish")
    @need("dashboards")
    def dash_publish(dash_id):
        d = load(dash_id)
        see_or_404(d)
        if not acc.can_publish(me(), g.perms, d):
            audit("ACCESS_DENIED", me(), f"publish {dash_id}")
            abort(403)
        if (r := stale(d)):
            return r
        defn, errs = sp.validate_dashboard(json.loads(d["definition"]))
        if errs or not defn["widgets"]:
            for e in errs or ["Add at least one widget before publishing."]:
                flash(e, "error")
            return redirect(url_for("dash_edit", dash_id=dash_id))
        store.dash_put(dash_id, {**d, "kind": "publish", "published_version": d["version"], "published_at": now()}, by=me(), note=f"published v{d['version']}")
        forget()
        audit("DASHBOARD_PUBLISHED", me(), f"{dash_id} v{d['version']}")
        flash(f"Published version {d['version']}. Only people it is shared with can open it.", "ok")
        return redirect(url_for("dash_edit", dash_id=dash_id))

    @app.post("/dashboards/<dash_id>/unpublish")
    @need("dashboards")
    def dash_unpublish(dash_id):
        d = load(dash_id)
        see_or_404(d)
        if not acc.can_publish(me(), g.perms, d):
            abort(403)
        store.dash_put(dash_id, {**d, "kind": "unpublish", "published_version": None, "published_at": None}, by=me(), note="unpublished")
        forget()
        audit("DASHBOARD_UNPUBLISHED", me(), dash_id)
        flash("Unpublished. Viewers can no longer open it.", "ok")
        return redirect(url_for("dash_edit", dash_id=dash_id))

    @app.post("/dashboards/<dash_id>/archive")
    @need("dashboards", rbac.EDIT)
    def dash_archive(dash_id):
        d = load(dash_id)
        see_or_404(d)
        if not acc.can_archive(me(), g.perms, d):
            abort(403)
        store.dash_put(dash_id, {**d, "kind": "archive", "status": "archived", "published_version": None, "published_at": None}, by=me(), note="archived")
        forget()
        audit("DASHBOARD_ARCHIVED", me(), dash_id)
        flash("Archived. It is hidden from everyone except its owner and administrators.", "ok")
        return redirect(url_for("dash_gallery"))

    @app.post("/dashboards/<dash_id>/duplicate")
    @need("dashboards", rbac.EDIT)
    def dash_duplicate(dash_id):
        d = load(dash_id)
        see_or_404(d)
        if acc.can_view_draft(me(), g.perms, d):
            source = d
        else:
            source = store.dash_row(dash_id, d["published_version"]) if d.get("published_version") is not None else None
            if source is None:
                abort(404)
        new_id = "d_" + secrets.token_hex(6)
        defn = definition_of(source)
        store.dash_put(new_id, {"version": 1, "kind": "duplicate", "name": ("Copy of " + d["name"])[:NAME_MAX], "description": d["description"], "owner": me(),
                                "status": "active", "published_version": None, "published_at": None, "definition": json.dumps(defn)}, by=me(), note=f"copy of {dash_id}")
        forget()
        audit("DASHBOARD_DUPLICATED", me(), f"{dash_id} -> {new_id}")
        return redirect(url_for("dash_edit", dash_id=new_id))

    @app.get("/dashboards/<dash_id>/versions")
    @need("dashboards", rbac.EDIT)
    def dash_versions(dash_id):
        d = load(dash_id)
        edit_or_404(d)
        return render_template("dash_versions.html", d=d, versions=store.dash_versions(dash_id), status=status_of(d), active_nav="dashboards")

    @app.post("/dashboards/<dash_id>/restore/<int:version>")
    @need("dashboards", rbac.EDIT)
    def dash_restore(dash_id, version):
        d = load(dash_id)
        edit_or_404(d)
        old = store.dash_row(dash_id, version)
        if old is None:
            abort(404)
        save_version(d, definition_of(old), "restore", f"restored version {version}", name=old["name"], description=old["description"])
        audit("DASHBOARD_SAVED", me(), f"{dash_id} restored v{version}")
        flash(f"Version {version} restored as a new draft version. Publish it to make it live.", "ok")
        return redirect(url_for("dash_edit", dash_id=dash_id))

    # ------------------------------------------------------------------ sharing
    @app.get("/dashboards/<dash_id>/share")
    @need("dashboards")
    def dash_share(dash_id):
        d = load(dash_id)
        see_or_404(d)
        if not acc.can_share(me(), g.perms, d):
            abort(403)
        return render_template("dash_share.html", d=d, shares=store.share_list(dash_id), roles=[r for r in store.list_roles() if r["enabled"]],
                               status=status_of(d), active_nav="dashboards")

    @app.post("/dashboards/<dash_id>/share")
    @need("dashboards")
    def dash_share_add(dash_id):
        d = load(dash_id)
        see_or_404(d)
        if not acc.can_share(me(), g.perms, d):
            abort(403)
        ptype, principal = request.form.get("ptype"), (request.form.get("principal") or "").strip().lower()
        if ptype == "user":
            u = store.get_user(principal)
            ok = bool(u and u["enabled"])
        elif ptype == "role":
            r = store.get_role(principal)
            ok = bool(r and r["enabled"])
        else:
            ok = False
        if not ok:
            flash("Choose an existing, enabled user or role.", "error")
        else:
            store.share_put(dash_id, ptype, principal, True, me())
            forget()
            audit("DASHBOARD_SHARED", principal if ptype == "user" else None, f"{dash_id} with {ptype} {principal}")
            flash(f"Shared with {ptype} {principal}. They still need access to the underlying data to see the numbers.", "ok")
        return redirect(url_for("dash_share", dash_id=dash_id))

    @app.post("/dashboards/<dash_id>/share/revoke")
    @need("dashboards")
    def dash_share_revoke(dash_id):
        d = load(dash_id)
        see_or_404(d)
        if not acc.can_share(me(), g.perms, d):
            abort(403)
        ptype, principal = request.form.get("ptype"), (request.form.get("principal") or "").strip().lower()
        if ("user" if ptype == "user" else "role" if ptype == "role" else None) and (ptype, principal) in shares_of(dash_id):
            store.share_put(dash_id, ptype, principal, False, me())
            forget()
            audit("DASHBOARD_UNSHARED", principal if ptype == "user" else None, f"{dash_id} from {ptype} {principal}")
            flash("Access removed.", "ok")
        return redirect(url_for("dash_share", dash_id=dash_id))
