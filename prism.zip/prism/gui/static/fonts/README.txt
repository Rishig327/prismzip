Vodafone brand fonts, taken from the vodafone.com files you supplied (the same four weights the site loads):
  Vodafone-Light.woff (300)   Vodafone-Regular.woff (400)   Vodafone-Bold.woff (700)   Vodafone-ExtraBold.woff (900)
prism.css loads them for the PRISM GUI. They are Vodafone's brand fonts: keep them inside Vodafone-internal use, and ask the
brand team if the GUI is ever shown outside the company. If a file is missing the GUI falls back to Arial.
