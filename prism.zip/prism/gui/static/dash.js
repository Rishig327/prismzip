/* PRISM dashboards - viewer + editor behaviour. Plain JavaScript, no libraries, no inline scripts (CSP: script-src 'self').
   Everything here only ADDS to a page that already works without JavaScript:
     - lazy loading: each widget body is fetched from its own render URL when it scrolls into view (3 at a time), so off-screen widgets cost no query
     - refresh: the "Refresh" button and the dashboard's optional refresh interval re-run only the widgets in view
     - tooltips (from the SVG <title> text), legend click to show/hide a series
     - click-to-filter: a bar, slice, point or cell carries data-fk / data-fv; clicking it sets the dashboard filter (f_<key>) if the creator enabled it
   The server re-checks access for every fragment request; nothing here is a security control. */
(function () {
  "use strict";
  var root = document.getElementById("dash");
  if (!root) return;
  document.documentElement.classList.add("js-on");

  var enabled = (root.dataset.filters || "").split(",").filter(Boolean);
  var refreshMin = parseInt(root.dataset.refresh || "0", 10) || 0;
  var labels = {};
  try { labels = JSON.parse(root.dataset.labels || "{}"); } catch (e) { labels = {}; }
  var MAX_PARALLEL = 3, running = 0, queue = [];
  if (enabled.length) root.classList.add("cf-on");

  var tip = document.createElement("div");
  tip.id = "tip"; tip.hidden = true;
  document.body.appendChild(tip);

  function query() { return location.search.replace(/^\?/, ""); }

  // ---------------------------------------------------------------- lazy loading
  function pump() { while (running < MAX_PARALLEL && queue.length) run(queue.shift()); }
  function enqueue(el) {
    if (el.dataset.state === "queued" || el.dataset.state === "loading") return;
    el.dataset.state = "queued"; queue.push(el); pump();
  }
  function run(el) {
    running++; el.dataset.state = "loading"; el.classList.add("refreshing");
    var q = query();
    fetch(el.dataset.render + (q ? "?" + q : ""), { credentials: "same-origin", headers: { "X-Requested-With": "fetch" } })
      .then(function (r) {
        if (r.redirected && /\/login/.test(r.url)) throw new Error("Your session has ended. Reload the page to sign in again.");
        if (!r.ok) throw new Error(r.status === 403 || r.status === 404 ? "This widget is not available to you." : "The widget could not be loaded (" + r.status + ").");
        return r.text();
      })
      .then(function (html) { el.innerHTML = html; enhance(el); el.dataset.state = "loaded"; })
      .catch(function (e) {
        el.innerHTML = '<div class="wmsg err"></div>'; el.firstChild.textContent = e.message; el.dataset.state = "error";
      })
      .then(function () { el.classList.remove("refreshing"); running--; pump(); });
  }
  function enhance(el) {                           // SVG <title> -> custom tooltip (the native one would show twice)
    [].forEach.call(el.querySelectorAll("svg title"), function (t) {
      var p = t.parentNode; p.setAttribute("data-tip", t.textContent); p.removeChild(t);
    });
  }

  var bodies = [].slice.call(root.querySelectorAll(".wbody[data-render]"));
  var io = "IntersectionObserver" in window ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) { if (en.isIntersecting) { io.unobserve(en.target); enqueue(en.target); } });
  }, { rootMargin: "200px" }) : null;
  bodies.forEach(function (el) { if (io) io.observe(el); else enqueue(el); });

  function inView(el) { var r = el.getBoundingClientRect(); return r.bottom > -200 && r.top < window.innerHeight + 200; }
  function reloadAll() {                           // visible widgets now, the others when they scroll into view
    bodies.forEach(function (el) {
      var s = el.dataset.state;
      if (s !== "loaded" && s !== "error") return;
      if (inView(el) || !io) enqueue(el); else { el.dataset.state = "stale"; io.observe(el); }
    });
  }

  var refreshBtn = document.getElementById("refresh-now");
  if (refreshBtn && bodies.length) { refreshBtn.hidden = false; refreshBtn.addEventListener("click", reloadAll); }
  if (refreshMin > 0 && bodies.length) setInterval(function () { if (!document.hidden) reloadAll(); }, refreshMin * 60000);

  // ---------------------------------------------------------------- tooltip + legend + click-to-filter
  function place(e) { tip.style.left = (e.pageX + 14) + "px"; tip.style.top = (e.pageY + 14) + "px"; }
  root.addEventListener("mouseover", function (e) {
    var t = e.target.closest ? e.target.closest("[data-tip]") : null;
    if (!t) return;
    tip.textContent = t.getAttribute("data-tip"); tip.hidden = false; place(e);
  });
  root.addEventListener("mousemove", function (e) { if (!tip.hidden) place(e); });
  root.addEventListener("mouseout", function (e) { if (e.target.closest && e.target.closest("[data-tip]")) tip.hidden = true; });

  root.addEventListener("click", function (e) {
    var li = e.target.closest(".legend li[data-s]");
    if (li) {
      var off = li.classList.toggle("off"), name = li.getAttribute("data-s");
      [].forEach.call(li.closest(".wcard").querySelectorAll("svg [data-s]"), function (n) {
        if (n.getAttribute("data-s") === name) n.style.display = off ? "none" : "";
      });
      return;
    }
    var mark = e.target.closest("[data-fk]");
    if (mark && enabled.indexOf(mark.getAttribute("data-fk")) >= 0) toggleFilter(mark.getAttribute("data-fk"), mark.getAttribute("data-fv"));
  });

  function setParams(p) { history.replaceState(null, "", location.pathname + (p.toString() ? "?" + p.toString() : "")); syncFilterUi(); reloadAll(); }
  function toggleFilter(key, val) {
    var p = new URLSearchParams(location.search), cur = (p.get("f_" + key) || "").split(",").filter(Boolean);
    if (cur.length === 1 && cur[0] === val) p.delete("f_" + key); else p.set("f_" + key, val);
    setParams(p);
  }
  function syncFilterUi() {
    var p = new URLSearchParams(location.search), chips = document.getElementById("chips");
    if (chips) chips.textContent = "";
    enabled.forEach(function (k) {
      var v = p.get("f_" + k), input = document.querySelector('input[name="f_' + k + '"]');
      if (input) input.value = v || "";
      if (!v || !chips) return;
      var c = document.createElement("span"), x = document.createElement("button");
      c.className = "chip"; c.textContent = (labels[k] || k) + ": " + v + " ";
      x.type = "button"; x.setAttribute("aria-label", "Remove filter " + (labels[k] || k)); x.textContent = "\u00d7";
      x.addEventListener("click", function () { var q = new URLSearchParams(location.search); q.delete("f_" + k); setParams(q); });
      c.appendChild(x); chips.appendChild(c);
    });
  }
  syncFilterUi();
})();
