/* PRISM code editor: line-number gutter, Tab key, status line, unsaved-change warning, Ctrl+S, jump to a line from the validation list.
   Plain JavaScript, no libraries. The page works without it (a plain text box + the Save buttons); this only makes editing comfortable. */
(function () {
  "use strict";
  var ta = document.getElementById("codearea");
  if (!ta) return;
  var gutter = document.getElementById("gutter"), status = document.getElementById("cstatus"), badge = document.getElementById("unsaved");
  var form = document.getElementById("codeform"), initial = ta.value, submitting = false;

  function numbers() {
    var n = ta.value.split("\n").length;
    if (ta.value.charAt(ta.value.length - 1) === "\n") n--;
    var s = "";
    for (var i = 1; i <= Math.max(n, 1); i++) s += i + "\n";
    gutter.textContent = s;
  }
  function where() {
    var before = ta.value.slice(0, ta.selectionStart).split("\n");
    status.textContent = "Line " + before.length + ", column " + (before[before.length - 1].length + 1);
  }
  function changed() { badge.hidden = ta.value === initial; numbers(); where(); }

  ta.addEventListener("input", changed);
  ta.addEventListener("keyup", where);
  ta.addEventListener("click", where);
  ta.addEventListener("scroll", function () { gutter.scrollTop = ta.scrollTop; });
  ta.addEventListener("keydown", function (e) {
    if (e.key === "Tab") {
      e.preventDefault();
      var a = ta.selectionStart, b = ta.selectionEnd, v = ta.value;
      if (a === b && !e.shiftKey) { ta.value = v.slice(0, a) + "    " + v.slice(b); ta.selectionStart = ta.selectionEnd = a + 4; }
      else {                                          // indent / outdent every selected line
        var ls = v.lastIndexOf("\n", a - 1) + 1, block = v.slice(ls, b), out;
        out = e.shiftKey ? block.replace(/^ {1,4}/gm, "") : block.replace(/^/gm, "    ");
        ta.value = v.slice(0, ls) + out + v.slice(b); ta.selectionStart = ls; ta.selectionEnd = ls + out.length;
      }
      changed();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
      e.preventDefault(); document.getElementById("btn-save").click();
    }
  });
  form.addEventListener("submit", function () { submitting = true; });
  window.addEventListener("beforeunload", function (e) { if (ta.value !== initial && !submitting) { e.preventDefault(); e.returnValue = ""; } });

  document.addEventListener("click", function (e) {            // validation list: click a line number to jump there
    var a = e.target.closest ? e.target.closest("[data-line]") : null;
    if (!a) return;
    e.preventDefault();
    var line = parseInt(a.getAttribute("data-line"), 10), lines = ta.value.split("\n"), off = 0, i;
    for (i = 0; i < line - 1 && i < lines.length; i++) off += lines[i].length + 1;
    ta.focus(); ta.setSelectionRange(off, off + (lines[line - 1] || "").length);
    ta.scrollTop = Math.max(0, (line - 4) * (parseFloat(getComputedStyle(ta).lineHeight) || 20)); gutter.scrollTop = ta.scrollTop;
    document.getElementById("codecard").scrollIntoView({ block: "nearest" });
    where();
  });
  numbers(); where();
})();
