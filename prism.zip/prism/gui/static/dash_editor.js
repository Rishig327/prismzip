/* PRISM dashboard editor - drag to move, drag the right edge to resize, undo / redo, unsaved-change warning, save layout.
   The layout is the ORDER of the widgets and the WIDTH (3, 4, 6, 8 or 12 of 12 columns) of each. Saving posts the order and
   widths to the server, which validates them again and creates a new draft version. Without JavaScript the arrow buttons and the
   width setting on each widget still work. */
(function () {
  "use strict";
  var grid = document.getElementById("wgrid"), bar = document.getElementById("layoutbar");
  if (!grid || !bar || !grid.querySelector(".wcard")) return;
  document.documentElement.classList.add("js-on");
  bar.hidden = false;

  var SPANS = [3, 4, 6, 8, 12], dragId = null, submitting = false;
  function $(id) { return document.getElementById(id); }
  var btnUndo = $("undo"), btnRedo = $("redo"), btnSave = $("savelayout"), btnDiscard = $("discard"), dirtyEl = $("dirty"), form = $("layoutform");

  function cards() { return [].slice.call(grid.querySelectorAll(".wcard[data-wid]")); }
  function read() { return cards().map(function (c) { return { id: c.dataset.wid, span: parseInt(c.dataset.span, 10) }; }); }
  function setSpan(c, n) {
    c.className = c.className.replace(/\bspan\d+\b/, "span" + n); c.dataset.span = n;
    var rz = c.querySelector(".rz"); if (rz) rz.setAttribute("aria-valuenow", n);
  }
  function apply(state) {
    var map = {}; cards().forEach(function (c) { map[c.dataset.wid] = c; });
    state.forEach(function (s) { var c = map[s.id]; if (c) { grid.appendChild(c); setSpan(c, s.span); } });
  }

  var saved = JSON.stringify(read()), hist = [saved], pos = 0;
  function dirty() { return hist[pos] !== saved; }
  function ui() {
    btnUndo.disabled = pos === 0; btnRedo.disabled = pos === hist.length - 1;
    var d = dirty(); dirtyEl.hidden = !d; btnSave.disabled = !d; btnDiscard.disabled = !d;
  }
  function push() {
    var s = JSON.stringify(read());
    if (s === hist[pos]) return;
    hist = hist.slice(0, pos + 1); hist.push(s); if (hist.length > 60) hist.shift();
    pos = hist.length - 1; ui();
  }
  function go(d) { var n = pos + d; if (n < 0 || n >= hist.length) return; pos = n; apply(JSON.parse(hist[pos])); ui(); }

  btnUndo.addEventListener("click", function () { go(-1); });
  btnRedo.addEventListener("click", function () { go(1); });
  btnDiscard.addEventListener("click", function () { apply(JSON.parse(saved)); hist = [saved]; pos = 0; ui(); });
  form.addEventListener("submit", function () {
    var st = read();
    $("f_order").value = st.map(function (s) { return s.id; }).join(",");
    $("f_spans").value = st.map(function (s) { return s.id + ":" + s.span; }).join(",");
    submitting = true;
  });
  window.addEventListener("beforeunload", function (e) { if (dirty() && !submitting) { e.preventDefault(); e.returnValue = ""; } });
  document.addEventListener("keydown", function (e) {
    if (/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName) || !(e.ctrlKey || e.metaKey)) return;
    var k = e.key.toLowerCase();
    if (k === "z") { e.preventDefault(); go(e.shiftKey ? 1 : -1); } else if (k === "y") { e.preventDefault(); go(1); }
  });

  // ---------------------------------------------------------------- drag to move (by the handle only)
  function clearMarks() { cards().forEach(function (c) { c.classList.remove("drop-before", "drop-after", "dragging"); c.removeAttribute("draggable"); }); }
  function before(over, e) {
    var r = over.getBoundingClientRect();
    return parseInt(over.dataset.span, 10) === 12 ? e.clientY < r.top + r.height / 2 : e.clientX < r.left + r.width / 2;
  }
  grid.addEventListener("mousedown", function (e) { var h = e.target.closest(".dh"); if (h) h.closest(".wcard").setAttribute("draggable", "true"); });
  grid.addEventListener("dragstart", function (e) {
    var c = e.target.closest(".wcard");
    if (!c || c.getAttribute("draggable") !== "true") return;
    dragId = c.dataset.wid; c.classList.add("dragging");
    e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", dragId);
  });
  grid.addEventListener("dragover", function (e) {
    if (!dragId) return;
    e.preventDefault();
    var over = e.target.closest(".wcard");
    cards().forEach(function (c) { c.classList.remove("drop-before", "drop-after"); });
    if (over && over.dataset.wid !== dragId) over.classList.add(before(over, e) ? "drop-before" : "drop-after");
  });
  grid.addEventListener("drop", function (e) {
    if (!dragId) return;
    e.preventDefault();
    var over = e.target.closest(".wcard"), src = grid.querySelector('.wcard[data-wid="' + dragId + '"]');
    if (over && src && over !== src) grid.insertBefore(src, before(over, e) ? over : over.nextSibling);
    dragId = null; clearMarks(); push();
  });
  grid.addEventListener("dragend", function () { dragId = null; clearMarks(); });

  // ---------------------------------------------------------------- resize (right edge) + keyboard
  function nearest(cols) { return SPANS.reduce(function (a, b) { return Math.abs(b - cols) < Math.abs(a - cols) ? b : a; }); }
  grid.addEventListener("pointerdown", function (e) {
    var h = e.target.closest(".rz");
    if (!h) return;
    e.preventDefault();
    var c = h.closest(".wcard"), colW = grid.getBoundingClientRect().width / 12, left = c.getBoundingClientRect().left;
    h.setPointerCapture(e.pointerId);
    function move(ev) { var n = nearest((ev.clientX - left) / colW); if (n !== parseInt(c.dataset.span, 10)) setSpan(c, n); }
    function up(ev) { h.removeEventListener("pointermove", move); h.removeEventListener("pointerup", up); try { h.releasePointerCapture(ev.pointerId); } catch (x) {} push(); }
    h.addEventListener("pointermove", move); h.addEventListener("pointerup", up);
  });
  grid.addEventListener("keydown", function (e) {
    var h = e.target.closest(".rz");
    if (!h || (e.key !== "ArrowLeft" && e.key !== "ArrowRight")) return;
    e.preventDefault();
    var c = h.closest(".wcard"), i = SPANS.indexOf(parseInt(c.dataset.span, 10)) + (e.key === "ArrowRight" ? 1 : -1);
    if (i >= 0 && i < SPANS.length) { setSpan(c, SPANS[i]); push(); }
  });
  ui();
})();
