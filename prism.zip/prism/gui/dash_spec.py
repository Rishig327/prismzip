"""
dash_spec.py - widget / dashboard validation and the controlled query builder. Pure functions, no Flask, no BigQuery.

A dashboard stores STRUCTURED configuration only (never SQL, never secrets). Before anything is saved or executed the backend:
  1. validates every widget against the catalog (known dataset, metrics, fields, operators, limits; unknown keys are dropped),
  2. builds SQL from catalog entries only - identifiers and metric expressions come from dash_catalog.py, user text is only ever
     a query PARAMETER (@name),
  3. always adds the dataset's partition-column time range, never uses SELECT *, always adds a LIMIT.
"""
import re
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Tuple

import dash_catalog as cat

SCHEMA_VERSION = 1
WIDGET_TYPES = {"kpi": "KPI card", "line": "Line chart", "area": "Area chart", "bar": "Bar chart", "donut": "Donut chart", "heatmap": "Heatmap",
                "table": "Data table", "pivot": "Pivot table"}
GRAINS = {"hour": "HOUR", "day": "DAY", "week": "WEEK(MONDAY)", "month": "MONTH"}
FILTER_OPS = {"eq": "is", "neq": "is not", "in": "is one of"}
SPANS = (3, 4, 6, 8, 12)                       # width in a 12-column grid
MAX_WIDGETS, MAX_METRICS, MAX_DIMS, MAX_FILTERS = 12, 4, 2, 5
LIMIT_DEFAULT, LIMIT_MAX = 50, 500
MAX_SERIES = 8
MAX_SLICES = 8                                 # donut
MAX_DASH_FILTERS = 4
REFRESH_MINUTES = (0, 1, 5, 15)                # 0 = no automatic refresh
LIMIT_BY_TYPE = {"donut": MAX_SLICES, "heatmap": 200, "pivot": 100}    # sensible default row limits when a form sends none
MAX_RANGE_DAYS = 93                            # the widest date range any viewer or creator can ask for (cost control)
PRESETS = {"last_1_day": 1, "last_7_days": 7, "last_30_days": 30, "last_90_days": 90}
IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class SpecError(ValueError):
    """Carries every problem found, one per line, in plain language."""
    def __init__(self, problems):
        self.problems = list(problems)
        super().__init__("\n".join(self.problems))


def new_widget_id() -> str:
    return "w" + secrets.token_hex(3)


def default_dashboard() -> dict:
    return {"schema": SCHEMA_VERSION, "date": {"preset": "last_7_days"}, "filters": [], "refresh": 0, "widgets": []}


# ---------------------------------------------------------------------------------------------------- validation
def _text(v, limit, label, errs, required=False):
    s = ("" if v is None else str(v)).strip()
    if required and not s:
        errs.append(f"{label} is required.")
    if len(s) > limit:
        errs.append(f"{label} must be at most {limit} characters.")
    return s[:limit]


def validate_widget(raw: dict, datasets=None) -> Tuple[dict, List[str]]:
    """Returns (clean widget, problems). Only whitelisted keys survive, so nothing executable can be stored."""
    datasets, errs, w = datasets or cat.DATASETS, [], raw or {}
    wtype = w.get("type")
    if wtype not in WIDGET_TYPES:
        errs.append("Choose a widget type.")
    ds_id = w.get("dataset")
    ds = datasets.get(ds_id)
    if ds is None:
        errs.append("Choose an approved dataset.")
        return {}, errs
    metrics = [m for m in (w.get("metrics") or []) if isinstance(m, str)]
    dims = [d for d in (w.get("dims") or []) if isinstance(d, str) and d]
    grain = w.get("time_grain") or None
    if len(set(metrics)) != len(metrics):
        errs.append("A metric can only be chosen once.")
    if not metrics:
        errs.append("Choose at least one metric.")
    if len(metrics) > MAX_METRICS:
        errs.append(f"At most {MAX_METRICS} metrics per widget.")
    for m in metrics:
        if m not in ds["metrics"]:
            errs.append(f"Metric {m!r} is not available in {ds['label']}.")
    if len(set(dims)) != len(dims) or len(dims) > MAX_DIMS:
        errs.append(f"Choose at most {MAX_DIMS} different fields to group by.")
    for d in dims:
        if d not in ds["fields"]:
            errs.append(f"Field {d!r} is not available in {ds['label']}.")
    if grain is not None and grain not in GRAINS:
        errs.append("Choose a time granularity: hour, day, week or month.")

    if wtype == "kpi":
        if len(metrics) != 1:
            errs.append("A KPI card shows exactly one metric.")
        if dims or grain:
            errs.append("A KPI card cannot be grouped.")
    elif wtype in ("line", "area"):
        name = "A line chart" if wtype == "line" else "An area chart"
        if not grain:
            errs.append(f"{name} needs a time granularity.")
        if len(dims) > 1:
            errs.append(f"{name} can have at most one series field (group by).")
        if dims and len(metrics) != 1:
            errs.append("With a series field, choose exactly one metric.")
    elif wtype == "donut":
        if len(metrics) != 1 or len(dims) != 1 or grain:
            errs.append("A donut chart shows one metric split by exactly one field (no time axis).")
    elif wtype == "heatmap":
        if len(metrics) != 1:
            errs.append("A heatmap shows exactly one metric.")
        if not ((grain and len(dims) == 1) or (not grain and len(dims) == 2)):
            errs.append("A heatmap needs two axes: a time axis plus one field, or two fields.")
    elif wtype == "pivot":
        if len(metrics) != 1 or len(dims) != 2 or grain:
            errs.append("A pivot table shows one metric with rows from one field and columns from another (exactly two fields, no time axis).")
    elif wtype == "bar":
        if not grain and not dims:
            errs.append("A bar chart needs a time granularity or a field to group by.")
        if grain and len(dims) > 1:
            errs.append("With a time axis, choose at most one series field.")
        if (len(dims) == 2 or (grain and dims)) and len(metrics) != 1:
            errs.append("With a series field, choose exactly one metric.")

    filters, seen = [], 0
    for f in (w.get("filters") or []):
        if not f or not f.get("field"):
            continue
        seen += 1
        fld = ds["fields"].get(f.get("field"))
        op = f.get("op")
        if fld is None:
            errs.append(f"Filter field {f.get('field')!r} is not available.")
            continue
        if op not in FILTER_OPS:
            errs.append(f"Filter on {fld['label']}: choose is, is not or is one of.")
            continue
        vals = f.get("value")
        vals = [str(v).strip() for v in (vals if isinstance(vals, list) else [vals]) if str(v).strip() != ""]
        if not vals:
            errs.append(f"Filter on {fld['label']} needs a value.")
            continue
        if op != "in" and len(vals) != 1:
            errs.append(f"Filter on {fld['label']}: give one value, or use 'is one of'.")
        if len(vals) > 20 or any(len(v) > 100 for v in vals):
            errs.append(f"Filter on {fld['label']}: at most 20 values of 100 characters.")
        if fld["type"] == "BOOL" and any(v.lower() not in ("true", "false") for v in vals):
            errs.append(f"Filter on {fld['label']}: use true or false.")
        filters.append({"field": f["field"], "op": op, "value": vals[:20] if op == "in" else vals[:1]})
    if seen > MAX_FILTERS:
        errs.append(f"At most {MAX_FILTERS} filters per widget.")

    try:
        limit = int(w.get("limit") or LIMIT_DEFAULT)
    except (TypeError, ValueError):
        limit = 0
    if not 1 <= limit <= LIMIT_MAX:
        errs.append(f"Row limit must be between 1 and {LIMIT_MAX}.")
        limit = LIMIT_DEFAULT
    if wtype == "donut" and limit > MAX_SLICES:
        errs.append(f"A donut shows at most {MAX_SLICES} slices (the largest ones).")
        limit = MAX_SLICES
    sort = w.get("sort") or {}
    sby, sdir = sort.get("by") or "", (sort.get("dir") or "desc").lower()
    if sby and sby not in metrics and sby not in dims and sby != "time":
        errs.append("Sort by one of the chosen metrics or fields.")
        sby = ""
    if sby == "time" and not grain:
        sby = ""
    if sdir not in ("asc", "desc"):
        errs.append("Sort direction must be ascending or descending.")
        sdir = "desc"
    try:
        span = int(w.get("span") or (3 if wtype == "kpi" else 6))
    except (TypeError, ValueError):
        span = 0
    if span not in SPANS:
        errs.append("Width must be 3, 4, 6, 8 or 12 of 12 columns.")
        span = 6
    try:
        decimals = int(w.get("decimals", 1))
    except (TypeError, ValueError):
        decimals = 1
    decimals = min(max(decimals, 0), 4)

    compare = bool(w.get("compare"))
    if compare and wtype != "kpi":
        errs.append("Comparison with the previous period is only available on KPI cards.")
        compare = False
    default_title = ds["metrics"][metrics[0]]["label"] if metrics and metrics[0] in ds["metrics"] else ""
    clean = {"id": w.get("id") if isinstance(w.get("id"), str) and IDENT.match(w.get("id", "")) else new_widget_id(),
             "type": wtype, "title": _text(w.get("title") or default_title, 80, "Title", errs, required=True),
             "description": _text(w.get("description"), 200, "Description", errs), "dataset": ds_id, "metrics": metrics, "dims": dims,
             "time_grain": grain, "filters": filters, "sort": {"by": sby, "dir": sdir}, "limit": limit, "span": span,
             "stacked": bool(w.get("stacked")) and wtype == "bar", "decimals": decimals, "compare": compare}
    return clean, errs


def validate_dashboard(defn: dict, datasets=None) -> Tuple[dict, List[str]]:
    errs, d = [], defn or {}
    date = d.get("date") or {}
    preset = date.get("preset") if date.get("preset") in PRESETS else "last_7_days"
    widgets, ids = [], set()
    raw = d.get("widgets") or []
    if len(raw) > MAX_WIDGETS:
        errs.append(f"At most {MAX_WIDGETS} widgets per dashboard.")
    for i, w in enumerate(raw[:MAX_WIDGETS], 1):
        cw, e = validate_widget(w, datasets)
        errs += [f"Widget {i}: {x}" for x in e]
        if cw:
            if cw["id"] in ids:
                cw["id"] = new_widget_id()
            ids.add(cw["id"])
            widgets.append(cw)
    keys = cat.filter_keys()
    dfilters = []
    for k in (d.get("filters") or []):
        if k in keys and k not in dfilters:
            dfilters.append(k)
        elif k not in keys:
            errs.append(f"Unknown dashboard filter {k!r}.")
    if len(dfilters) > MAX_DASH_FILTERS:
        errs.append(f"At most {MAX_DASH_FILTERS} dashboard filters.")
        dfilters = dfilters[:MAX_DASH_FILTERS]
    try:
        refresh = int(d.get("refresh") or 0)
    except (TypeError, ValueError):
        refresh = 0
    if refresh not in REFRESH_MINUTES:
        errs.append("Refresh interval must be off, 1, 5 or 15 minutes.")
        refresh = 0
    return {"schema": SCHEMA_VERSION, "date": {"preset": preset}, "filters": dfilters, "refresh": refresh, "widgets": widgets}, errs


# ---------------------------------------------------------------------------------------------------- date range
def resolve_range(preset=None, start=None, end=None, now=None) -> Tuple[datetime, datetime]:
    """(start, end) UTC, end exclusive. A preset or custom dates (yyyy-mm-dd); never wider than MAX_RANGE_DAYS."""
    now = now or datetime.now(timezone.utc)
    if start or end:
        try:
            s = datetime.strptime(start, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            e = datetime.strptime(end, "%Y-%m-%d").replace(tzinfo=timezone.utc) + timedelta(days=1)
        except (TypeError, ValueError):
            raise SpecError(["Enter both dates as yyyy-mm-dd."])
        if e <= s:
            raise SpecError(["The end date must not be before the start date."])
        if (e - s).days > MAX_RANGE_DAYS:
            raise SpecError([f"The date range can be at most {MAX_RANGE_DAYS} days."])
        return s, min(e, now + timedelta(days=1))
    days = PRESETS.get(preset or "last_7_days")
    if days is None:
        raise SpecError(["Unknown date range."])
    return now - timedelta(days=days), now + timedelta(minutes=1)


# ---------------------------------------------------------------------------------------------------- query builder
@dataclass
class Query:
    sql: str
    params: list                                            # [(name, 'TIMESTAMP'|'STRING'|'BOOL', value)] or (name, 'ARRAY<STRING>', [..])
    columns: list                                           # [{"alias","kind":"time|dim|metric","ref","label","fmt","unit"}]
    dataset: str = ""
    meta: dict = field(default_factory=dict)


def _q(ident: str) -> str:
    if not IDENT.match(ident):                              # catalog identifiers only; this is a second line of defence
        raise SpecError([f"unsafe identifier {ident!r}"])
    return f"`{ident}`"


def build_query(widget: dict, start: datetime, end: datetime) -> Query:
    ds = cat.DATASETS[widget["dataset"]]
    tf, grain, cols, select, group = ds["time_field"], widget.get("time_grain"), [], [], []
    if grain:
        select.append(f"TIMESTAMP_TRUNC({_q(tf)}, {GRAINS[grain]}) AS t")
        group.append("t")
        cols.append({"alias": "t", "kind": "time", "ref": tf, "label": ds["time_label"], "grain": grain})
    for i, d in enumerate(widget["dims"]):
        select.append(f"{_q(d)} AS d{i}")
        group.append(f"d{i}")
        cols.append({"alias": f"d{i}", "kind": "dim", "ref": d, "label": ds["fields"][d]["label"]})
    for i, m in enumerate(widget["metrics"]):
        mt = ds["metrics"][m]
        select.append(f"{mt['expr']} AS m{i}")              # expression text comes from the catalog, never from the user
        cols.append({"alias": f"m{i}", "kind": "metric", "ref": m, "label": mt["label"], "fmt": mt["fmt"], "unit": mt["unit"]})
    params = [("range_start", "TIMESTAMP", start), ("range_end", "TIMESTAMP", end)]
    where = [f"{_q(tf)} >= @range_start", f"{_q(tf)} < @range_end"]
    for i, f in enumerate(widget["filters"]):
        fld, col = ds["fields"][f["field"]], _q(f["field"])
        vals = [v.lower() == "true" for v in f["value"]] if fld["type"] == "BOOL" else list(f["value"])
        typ = "BOOL" if fld["type"] == "BOOL" else "STRING"
        if f["op"] == "in":
            where.append(f"{col} IN UNNEST(@f{i})")
            params.append((f"f{i}", f"ARRAY<{typ}>", vals))
        else:
            where.append(f"{col} {'=' if f['op'] == 'eq' else '!='} @f{i}")
            params.append((f"f{i}", typ, vals[0]))
    sort = widget.get("sort") or {}
    alias = {m: f"m{i}" for i, m in enumerate(widget["metrics"])}
    alias.update({d: f"d{i}" for i, d in enumerate(widget["dims"])})
    if sort.get("by") == "time":
        order = f"t {sort['dir'].upper()}"
    elif sort.get("by") in alias:
        order = f"{alias[sort['by']]} {sort['dir'].upper()}"
    elif grain:
        order = "t ASC"
    else:
        order = "m0 DESC" if widget["metrics"] else ""
    sql = (f"SELECT {', '.join(select)}\nFROM `{cat.table_ref(widget['dataset'])}`\nWHERE {' AND '.join(where)}"
           + (f"\nGROUP BY {', '.join(group)}" if group else "") + (f"\nORDER BY {order}" if order and group else "")
           + f"\nLIMIT {int(widget['limit']) if group else 1}")
    return Query(sql, params, cols, widget["dataset"], {"type": widget["type"], "grain": grain})


def build_preview(dataset_id: str, start: datetime, end: datetime, rows: int = 20) -> Query:
    """Limited look at an approved dataset: catalog-listed columns only, newest first, partition range, 20 rows."""
    ds = cat.DATASETS[dataset_id]
    sel = ", ".join(_q(c) for c in ds["preview"])
    sql = (f"SELECT {sel}\nFROM `{cat.table_ref(dataset_id)}`\nWHERE {_q(ds['time_field'])} >= @range_start AND {_q(ds['time_field'])} < @range_end"
           f"\nORDER BY {_q(ds['time_field'])} DESC\nLIMIT {int(min(rows, 50))}")
    cols = [{"alias": c, "kind": "dim", "ref": c, "label": c} for c in ds["preview"]]
    return Query(sql, [("range_start", "TIMESTAMP", start), ("range_end", "TIMESTAMP", end)], cols, dataset_id, {"type": "preview"})


# ---------------------------------------------------------------------------------------------------- viewer filters, comparison
def parse_active_filters(args, enabled_keys) -> Tuple[dict, List[str]]:
    """Reads f_<key>=a,b from the request for the filters the creator ENABLED on the dashboard. Everything else is ignored.
    -> ({key: [values]}, problems). Values are only ever used as query parameters."""
    keys, out, problems = cat.filter_keys(), {}, []
    for k in enabled_keys:
        if k not in keys:
            continue
        raw = (args.get(f"f_{k}") or "").strip()
        vals = [v.strip() for v in raw.split(",") if v.strip()]
        if not vals:
            continue
        if len(vals) > 20 or any(len(v) > 100 for v in vals):
            problems.append(f"Filter {keys[k]['label']}: at most 20 values of 100 characters.")
            continue
        if keys[k]["type"] == "BOOL" and any(v.lower() not in ("true", "false") for v in vals):
            problems.append(f"Filter {keys[k]['label']}: use true or false.")
            continue
        out[k] = vals
    return out, problems


def apply_filters(widget: dict, active: dict) -> dict:
    """Copy of the widget with the dashboard filters added - only for datasets that have that field."""
    keys, extra = cat.filter_keys(), []
    for k, vals in active.items():
        fname = keys.get(k, {}).get("fields", {}).get(widget["dataset"])
        if fname:
            extra.append({"field": fname, "op": "in", "value": list(vals)})
    return {**widget, "filters": list(widget["filters"]) + extra} if extra else widget


def previous_range(start: datetime, end: datetime) -> Tuple[datetime, datetime]:
    """The period of the same length immediately before [start, end)."""
    return start - (end - start), start
