"""
store.py - users, roles and the audit log of the GUI, in BigQuery (VPDB_ADM) like the rest of PRISM.

Users and roles are APPEND-ONLY, same as the config tables: a change inserts a NEW row, the newest row per key wins and the
older rows are the history (this is also what lets the password-history rule work: the old hashes are still there).
The audit table is append-only too and is what the account lock-out is computed from.

  prism_gui_user   username + version : display_name, email, role, overrides (JSON), enabled, password_hash, must_change_password
  prism_gui_role   role_name + version: description, permissions (JSON module -> level), enabled
  prism_gui_audit  one row per event  : event_time, username, actor, event, detail, ip
  prism_gui_dashboard        Dashboard Studio: one row per save/publish/archive; newest per dashboard_id is current; version = content version
  prism_gui_dashboard_share  who a dashboard is shared with (user or role); newest per (dashboard, type, principal); active=FALSE = revoked

MemoryStore has the same methods for tests and for the local demo (PRISM_GUI_DEV=1); nothing is persisted.
"""
import json
from datetime import datetime, timezone
from typing import Dict, List, Optional

from transform_store import MemoryTransformTable, TransformTable      # transformation code of the sources (common/transform_store.py)

T_USER, T_ROLE, T_AUDIT = "prism_gui_user", "prism_gui_role", "prism_gui_audit"
T_DASH, T_SHARE = "prism_gui_dashboard", "prism_gui_dashboard_share"
DASH_COLS = ("version", "kind", "name", "description", "owner", "status", "published_version", "published_at", "definition")
USER_COLS = ("display_name", "email", "role", "overrides", "enabled", "password_hash", "must_change_password", "password_changed_at")


def _now():
    return datetime.now(timezone.utc)


class MemoryStore:
    def __init__(self):
        self.users: Dict[str, List[dict]] = {}       # username -> versions, oldest first
        self.roles: Dict[str, List[dict]] = {}
        self.events: List[dict] = []
        self.dashes: Dict[str, List[dict]] = {}
        self.share_rows: List[dict] = []
        self.transform = MemoryTransformTable()

    # ---- dashboards
    def dash_get(self, dash_id):
        v = self.dashes.get(dash_id)
        return dict(v[-1]) if v else None

    def dash_list(self):
        return [dict(v[-1]) for v in self.dashes.values()]

    def dash_row(self, dash_id, version):
        rows = [r for r in self.dashes.get(dash_id, []) if r["version"] == version]
        return dict(rows[-1]) if rows else None

    def dash_versions(self, dash_id, limit=30):
        rows = [r for r in reversed(self.dashes.get(dash_id, [])) if r["kind"] in ("created", "save", "restore", "duplicate")]
        return [dict(r) for r in rows][:limit]

    def dash_put(self, dash_id, row: dict, by: str, note: str = None):
        self.dashes.setdefault(dash_id, []).append({"dashboard_id": dash_id, "changed_at": _now(), "changed_by": by, "note": note,
                                                    **{c: row.get(c) for c in DASH_COLS}})

    def share_put(self, dash_id, ptype, principal, active, by):
        self.share_rows.append({"dashboard_id": dash_id, "principal_type": ptype, "principal": principal, "level": "view",
                                "active": active, "changed_at": _now(), "changed_by": by})

    def _shares_latest(self):
        cur = {}
        for r in self.share_rows:
            cur[(r["dashboard_id"], r["principal_type"], r["principal"])] = r
        return [dict(r) for r in cur.values() if r["active"]]

    def share_list(self, dash_id):
        return sorted((r for r in self._shares_latest() if r["dashboard_id"] == dash_id), key=lambda r: (r["principal_type"], r["principal"]))

    def shares_all(self):
        out = {}
        for r in self._shares_latest():
            out.setdefault(r["dashboard_id"], set()).add((r["principal_type"], r["principal"]))
        return out

    # ---- users
    def get_user(self, username) -> Optional[dict]:
        v = self.users.get(username)
        return dict(v[-1]) if v else None

    def list_users(self) -> List[dict]:
        return sorted((dict(v[-1]) for v in self.users.values()), key=lambda r: r["username"])

    def user_versions(self, username, limit=10) -> List[dict]:
        return [dict(r) for r in reversed(self.users.get(username, []))][:limit]

    def put_user(self, username, row: dict, by: str, note: str = None):
        rec = {"username": username, "changed_at": _now(), "changed_by": by, "note": note, **{c: row.get(c) for c in USER_COLS}}
        self.users.setdefault(username, []).append(rec)

    # ---- roles
    def get_role(self, name) -> Optional[dict]:
        v = self.roles.get(name)
        return dict(v[-1]) if v else None

    def list_roles(self) -> List[dict]:
        return sorted((dict(v[-1]) for v in self.roles.values()), key=lambda r: r["role_name"])

    def put_role(self, name, description, permissions: dict, enabled: bool, by: str, note: str = None):
        rec = {"role_name": name, "changed_at": _now(), "changed_by": by, "note": note, "description": description,
               "permissions": json.dumps(permissions), "enabled": enabled}
        self.roles.setdefault(name, []).append(rec)

    # ---- audit
    def audit(self, event, username=None, actor=None, detail=None, ip=None):
        self.events.append({"event_time": _now(), "username": username, "actor": actor, "event": event,
                            "detail": detail, "ip": ip})

    def lock_events(self, username, relevant, limit=20):
        rows = [e for e in reversed(self.events) if e["username"] == username and e["event"] in relevant]
        return [(e["event"], e["event_time"]) for e in rows[:limit]]

    def list_audit(self, limit=200, username=None, event=None) -> List[dict]:
        rows = [e for e in reversed(self.events)
                if (not username or username in (e["username"] or "", e["actor"] or "")) and (not event or e["event"] == event)]
        return [dict(e) for e in rows[:limit]]


class BigQueryStore:
    def __init__(self, bq, project: str, dataset: str):
        from google.cloud import bigquery                     # imported here so MemoryStore needs no Google libraries
        self.S, self.A, self.bq = bigquery.ScalarQueryParameter, bigquery.ArrayQueryParameter, bq
        self.t = lambda name: f"`{project}.{dataset}.{name}`"  # noqa: E731
        self.transform = TransformTable(bq, project, dataset)

    def _insert(self, table, cols: dict, types: dict):
        names = list(cols)
        params = [self.S(c, types[c], cols[c]) for c in names]
        self.bq.run(f"INSERT INTO {self.t(table)} ({', '.join(names)}, changed_at) "
                    f"VALUES ({', '.join('@' + c for c in names)}, CURRENT_TIMESTAMP())", params)

    # ---- users
    def get_user(self, username):
        r = self.bq.rows(f"SELECT * FROM {self.t(T_USER)} WHERE username = @u "
                         "QUALIFY ROW_NUMBER() OVER (ORDER BY changed_at DESC) = 1", [self.S("u", "STRING", username)])
        return dict(r[0].items()) if r else None

    def list_users(self):
        return sorted((dict(r.items()) for r in self.bq.rows(
            f"SELECT * FROM {self.t(T_USER)} WHERE TRUE QUALIFY ROW_NUMBER() OVER (PARTITION BY username ORDER BY changed_at DESC) = 1")),
            key=lambda r: r["username"])

    def user_versions(self, username, limit=10):
        return [dict(r.items()) for r in self.bq.rows(
            f"SELECT * FROM {self.t(T_USER)} WHERE username = @u ORDER BY changed_at DESC LIMIT {int(limit)}",
            [self.S("u", "STRING", username)])]

    def put_user(self, username, row, by, note=None):
        types = {"username": "STRING", "changed_by": "STRING", "note": "STRING", "display_name": "STRING", "email": "STRING",
                 "role": "STRING", "overrides": "STRING", "enabled": "BOOL", "password_hash": "STRING",
                 "must_change_password": "BOOL", "password_changed_at": "TIMESTAMP"}
        self._insert(T_USER, {"username": username, "changed_by": by, "note": note, **{c: row.get(c) for c in USER_COLS}}, types)

    # ---- roles
    def get_role(self, name):
        r = self.bq.rows(f"SELECT * FROM {self.t(T_ROLE)} WHERE role_name = @r "
                         "QUALIFY ROW_NUMBER() OVER (ORDER BY changed_at DESC) = 1", [self.S("r", "STRING", name)])
        return dict(r[0].items()) if r else None

    def list_roles(self):
        return sorted((dict(r.items()) for r in self.bq.rows(
            f"SELECT * FROM {self.t(T_ROLE)} WHERE TRUE QUALIFY ROW_NUMBER() OVER (PARTITION BY role_name ORDER BY changed_at DESC) = 1")),
            key=lambda r: r["role_name"])

    def put_role(self, name, description, permissions, enabled, by, note=None):
        types = {"role_name": "STRING", "changed_by": "STRING", "note": "STRING", "description": "STRING",
                 "permissions": "STRING", "enabled": "BOOL"}
        self._insert(T_ROLE, {"role_name": name, "changed_by": by, "note": note, "description": description,
                              "permissions": json.dumps(permissions), "enabled": enabled}, types)

    # ---- dashboards
    def dash_get(self, dash_id):
        r = self.bq.rows(f"SELECT * FROM {self.t(T_DASH)} WHERE dashboard_id = @d QUALIFY ROW_NUMBER() OVER (ORDER BY changed_at DESC) = 1",
                         [self.S("d", "STRING", dash_id)])
        return dict(r[0].items()) if r else None

    def dash_list(self):
        return [dict(r.items()) for r in self.bq.rows(
            f"SELECT * FROM {self.t(T_DASH)} WHERE TRUE QUALIFY ROW_NUMBER() OVER (PARTITION BY dashboard_id ORDER BY changed_at DESC) = 1")]

    def dash_row(self, dash_id, version):
        r = self.bq.rows(f"SELECT * FROM {self.t(T_DASH)} WHERE dashboard_id = @d AND version = @v ORDER BY changed_at DESC LIMIT 1",
                         [self.S("d", "STRING", dash_id), self.S("v", "INT64", int(version))])
        return dict(r[0].items()) if r else None

    def dash_versions(self, dash_id, limit=30):
        return [dict(r.items()) for r in self.bq.rows(
            f"SELECT * FROM {self.t(T_DASH)} WHERE dashboard_id = @d AND kind IN ('created','save','restore','duplicate') "
            f"ORDER BY changed_at DESC LIMIT {int(limit)}", [self.S("d", "STRING", dash_id)])]

    def dash_put(self, dash_id, row, by, note=None):
        types = {"dashboard_id": "STRING", "changed_by": "STRING", "note": "STRING", "version": "INT64", "kind": "STRING", "name": "STRING",
                 "description": "STRING", "owner": "STRING", "status": "STRING", "published_version": "INT64", "published_at": "TIMESTAMP",
                 "definition": "STRING"}
        self._insert(T_DASH, {"dashboard_id": dash_id, "changed_by": by, "note": note, **{c: row.get(c) for c in DASH_COLS}}, types)

    def share_put(self, dash_id, ptype, principal, active, by):
        self._insert(T_SHARE, {"dashboard_id": dash_id, "principal_type": ptype, "principal": principal, "level": "view", "active": active,
                               "changed_by": by}, {"dashboard_id": "STRING", "principal_type": "STRING", "principal": "STRING", "level": "STRING",
                                                   "active": "BOOL", "changed_by": "STRING"})

    _SHARE_LATEST = ("SELECT * FROM {t} WHERE {w} QUALIFY ROW_NUMBER() OVER (PARTITION BY dashboard_id, principal_type, principal "
                     "ORDER BY changed_at DESC) = 1")

    def share_list(self, dash_id):
        rows = self.bq.rows(self._SHARE_LATEST.format(t=self.t(T_SHARE), w="dashboard_id = @d"), [self.S("d", "STRING", dash_id)])
        return sorted((dict(r.items()) for r in rows if r.active), key=lambda r: (r["principal_type"], r["principal"]))

    def shares_all(self):
        out = {}
        for r in self.bq.rows(self._SHARE_LATEST.format(t=self.t(T_SHARE), w="TRUE")):
            if r.active:
                out.setdefault(r.dashboard_id, set()).add((r.principal_type, r.principal))
        return out

    # ---- audit
    def audit(self, event, username=None, actor=None, detail=None, ip=None):
        S = self.S
        self.bq.run(f"INSERT INTO {self.t(T_AUDIT)} (event_time, username, actor, event, detail, ip) "
                    "VALUES (CURRENT_TIMESTAMP(), @u, @a, @e, @d, @i)",
                    [S("u", "STRING", username), S("a", "STRING", actor), S("e", "STRING", event),
                     S("d", "STRING", (detail or "")[:500] or None), S("i", "STRING", ip)])

    def lock_events(self, username, relevant, limit=20):
        rows = self.bq.rows(f"SELECT event, event_time FROM {self.t(T_AUDIT)} WHERE username = @u AND event IN UNNEST(@ev) "
                            f"ORDER BY event_time DESC LIMIT {int(limit)}",
                            [self.S("u", "STRING", username), self.A("ev", "STRING", list(relevant))])
        return [(r.event, r.event_time) for r in rows]

    def list_audit(self, limit=200, username=None, event=None):
        where, params = ["TRUE"], []
        if username:
            where.append("(username = @u OR actor = @u)"); params.append(self.S("u", "STRING", username))
        if event:
            where.append("event = @e"); params.append(self.S("e", "STRING", event))
        return [dict(r.items()) for r in self.bq.rows(
            f"SELECT * FROM {self.t(T_AUDIT)} WHERE {' AND '.join(where)} ORDER BY event_time DESC LIMIT {int(limit)}", params)]
