"""
pyhighlight.py - read-only syntax colouring and line diff of Python code for the code viewer. Standard library only; output is HTML-escaped.
"""
import builtins
import difflib
import io
import keyword
import tokenize

from markupsafe import Markup, escape

_BUILTINS = set(dir(builtins))


def _spans(code: str):
    """-> {line_index: [(col_start, col_end, css_class)]} from the tokenizer. A tokenizer error just stops colouring (plain text is always shown)."""
    marks, prev = {}, None
    try:
        for tok in tokenize.generate_tokens(io.StringIO(code).readline):
            name = tokenize.tok_name.get(tok.type, "")
            cls = None
            if name == "NAME":
                if keyword.iskeyword(tok.string):
                    cls = "kw"
                elif prev in ("def", "class"):
                    cls = "df"
                elif tok.string in _BUILTINS:
                    cls = "bi"
            elif name in ("STRING", "FSTRING_START", "FSTRING_MIDDLE", "FSTRING_END"):
                cls = "st"
            elif name == "COMMENT":
                cls = "cm"
            elif name == "NUMBER":
                cls = "nu"
            if cls:
                (r1, c1), (r2, c2) = tok.start, tok.end
                for r in range(r1, r2 + 1):
                    marks.setdefault(r - 1, []).append((c1 if r == r1 else 0, c2 if r == r2 else 10 ** 9, cls))
            if name == "NAME":
                prev = tok.string
            elif name not in ("NL", "NEWLINE", "COMMENT", "INDENT", "DEDENT"):
                prev = None
    except (tokenize.TokenError, SyntaxError, IndentationError):
        pass
    return marks


def highlight_lines(code: str):
    """-> list of Markup, one per source line (no trailing newline characters)."""
    lines, marks, out = code.split("\n"), _spans(code), []
    if lines and lines[-1] == "":
        lines.pop()                                      # the final newline is not an extra empty line
    for i, line in enumerate(lines):
        segs, pos, html = sorted(marks.get(i, [])), 0, []
        for c1, c2, cls in segs:
            c1, c2 = max(c1, pos), min(c2, len(line))
            if c1 >= c2:
                continue
            html.append(str(escape(line[pos:c1])))
            html.append(f'<span class="{cls}">{escape(line[c1:c2])}</span>')
            pos = c2
        html.append(str(escape(line[pos:])))
        out.append(Markup("".join(html)))
    return out


def diff_rows(a: str, b: str, context: int = 3):
    """Line diff of two texts -> [{kind: hunk|ctx|add|del, a: old line no, b: new line no, text}] with `context` lines around changes."""
    al, bl = a.splitlines(), b.splitlines()
    rows = []
    for group in difflib.SequenceMatcher(None, al, bl, autojunk=False).get_grouped_opcodes(context):
        rows.append({"kind": "hunk", "a": None, "b": None, "text": f"@@ line {group[0][1] + 1} (old) / {group[0][3] + 1} (new) @@"})
        for tag, i1, i2, j1, j2 in group:
            if tag == "equal":
                rows += [{"kind": "ctx", "a": i + 1, "b": j + 1, "text": al[i]} for i, j in zip(range(i1, i2), range(j1, j2))]
            else:
                rows += [{"kind": "del", "a": i + 1, "b": None, "text": al[i]} for i in range(i1, i2)]
                rows += [{"kind": "add", "a": None, "b": j + 1, "text": bl[j]} for j in range(j1, j2)]
    return rows
