"""
security.py - passwords, lockout and redirect safety. Pure functions (no Flask, no BigQuery).
Settings are the constants below; change them here.
"""
import secrets
import string
from datetime import timedelta

from werkzeug.security import check_password_hash, generate_password_hash

MIN_LEN, MAX_LEN, MIN_CLASSES = 12, 128, 3        # length, and how many of: lower, upper, digit, symbol
HISTORY = 5                                       # a new password may not equal any of the last N passwords
MAX_AGE_DAYS = 90                                 # older than this: the user must choose a new password at sign-in
LOCK_THRESHOLD, LOCK_MINUTES = 5, 15              # N wrong passwords in a row (within LOCK_MINUTES) lock the account
IDLE_MINUTES, ABSOLUTE_HOURS = 30, 8              # session ends after this much inactivity / in any case after this
BANNED_WORDS = ("password", "passw0rd", "vodafone", "prism", "vois", "welcome", "letmein", "qwerty", "123456", "changeme")
LOCK_RELEVANT = ("LOGIN_FAIL", "LOGIN_OK", "UNLOCK", "PASSWORD_RESET", "PASSWORD_CHANGED")


def hash_password(password: str) -> str:
    return generate_password_hash(password, method="scrypt")


DUMMY_HASH = hash_password(secrets.token_hex(16))      # checked for unknown users, so the response time does not reveal them


def verify_password(stored_hash: str, password: str) -> bool:
    try:
        return check_password_hash(stored_hash or DUMMY_HASH, password or "")
    except Exception:                                   # malformed hash must never raise into the login page
        return False


def policy_problems(password: str, username: str = "", previous_hashes=()) -> list:
    """Every reason the password is refused (empty list = accepted)."""
    p, probs = password or "", []
    if len(p) < MIN_LEN:
        probs.append(f"at least {MIN_LEN} characters")
    if len(p) > MAX_LEN:
        probs.append(f"at most {MAX_LEN} characters")
    classes = sum(any(f(c) for c in p) for f in (str.islower, str.isupper, str.isdigit, lambda c: not c.isalnum()))
    if classes < MIN_CLASSES:
        probs.append(f"use at least {MIN_CLASSES} of: lower case, upper case, digit, symbol")
    if len(set(p)) < 5:
        probs.append("too repetitive")
    low = p.lower()
    if username and len(username) >= 3 and username.lower() in low:
        probs.append("must not contain the username")
    if any(w in low for w in BANNED_WORDS):
        probs.append("must not contain easy words such as password, vodafone, prism")
    if p and any(verify_password(h, p) for h in list(previous_hashes)[:HISTORY] if h):
        probs.append(f"was used recently (the last {HISTORY} passwords cannot be reused)")
    return probs


def generate_temp_password() -> str:
    """16 characters, no look-alikes (0/O, 1/l/I); always meets the policy. Shown once to the administrator."""
    lower, upper, digit, sym = "abcdefghijkmnopqrstuvwxyz", "ABCDEFGHJKLMNPQRSTUVWXYZ", "23456789", "-_.!@#"
    while True:
        chars = [secrets.choice(lower), secrets.choice(upper), secrets.choice(digit), secrets.choice(sym)]
        chars += [secrets.choice(lower + upper + digit) for _ in range(12)]
        secrets.SystemRandom().shuffle(chars)
        pw = "".join(chars)
        if not policy_problems(pw):
            return pw


def password_expired(changed_at, now) -> bool:
    return changed_at is None or now - changed_at > timedelta(days=MAX_AGE_DAYS)


def lock_until(events, now):
    """
    events: [(event_name, datetime)] NEWEST FIRST. A run of LOCK_THRESHOLD wrong passwords (each within LOCK_MINUTES of the
    newest) locks the account until LOCK_MINUTES after the newest one. A successful sign-in, an unlock or a password
    change ends the run. Returns the datetime the lock ends, or None when the account is not locked.
    """
    fails, newest = 0, None
    for ev, t in events:
        if ev != "LOGIN_FAIL":
            break
        if newest is None:
            newest = t
        if newest - t > timedelta(minutes=LOCK_MINUTES):
            break
        fails += 1
    if fails >= LOCK_THRESHOLD and newest is not None:
        end = newest + timedelta(minutes=LOCK_MINUTES)
        return end if now < end else None
    return None


def is_safe_next(path) -> bool:
    """Only same-site relative paths may be used as the after-login redirect (no open redirect)."""
    return bool(path) and path.startswith("/") and not path.startswith("//") and "\\" not in path and "://" not in path
