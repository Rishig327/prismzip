"""
rbac.py - modules, access levels and roles of the PRISM GUI. No Flask, no BigQuery: pure rules, easy to test.

A MODULE is one area of the GUI (Lookups, Users ...). Access to a module has a LEVEL: 0 none, 1 view, 2 edit (edit includes view).
A ROLE is a named set of levels per module. A USER has one role and may have per-module OVERRIDES that replace the role's
level for that module (so "operator, but also edit recon" needs no new role).
`max` is the highest level a module supports today: a module that is read-only in the GUI cannot be given edit.
"""
import json

NONE, VIEW, EDIT = 0, 1, 2
LEVELS = {NONE: "No access", VIEW: "View", EDIT: "Edit"}

# key -> label, what it is, highest level supported
MODULES = {
    "sources": {"label": "Sources & settings", "about": "Source and global configuration (read only)", "max": VIEW},
    "lookups": {"label": "Lookups",            "about": "Lookup definitions used by the pipeline",     "max": EDIT},
    "recon":   {"label": "Reconciliation",     "about": "Reconciliation definitions (read only)",     "max": VIEW},
    "audit":   {"label": "Audit log",          "about": "Sign-ins and administration events",          "max": VIEW},
    "users":   {"label": "Users",              "about": "Create users, reset passwords, unlock",       "max": EDIT},
    "roles":   {"label": "Roles",              "about": "Create roles and set module access",          "max": EDIT},
    # Dashboard Studio. nav=False: these are capabilities, not pages (only "Dashboards" has a menu entry)
    "dashboards":    {"label": "Dashboards",       "about": "View = open dashboards shared with you. Edit = create and edit your own (off for ordinary users)",
                      "max": EDIT, "endpoint": "dash_gallery"},
    "dash_publish":  {"label": "Publish & share",  "about": "Publish, unpublish and share dashboards you own",             "max": EDIT, "nav": False},
    "dash_admin":    {"label": "Dashboard admin",  "about": "See, edit, publish, share and archive every dashboard",       "max": EDIT, "nav": False},
    # Transformation code of the sources (Sources -> <source> -> Transformation code). Separate from the Sources module on purpose.
    "transform":         {"label": "Transformation code",  "about": "View = read the code and its history. Edit = edit the draft and run validation", "max": EDIT, "nav": False},
    "transform_approve": {"label": "Approve code",         "about": "Approve (publish a new version of), discard or restore transformation code",   "max": EDIT, "nav": False},
    "dash_export":   {"label": "Export data",     "about": "Download widget data as CSV (separate from viewing; off by default)",       "max": VIEW, "nav": False},
    "data_pipeline": {"label": "Pipeline data",    "about": "Data behind widgets: files, records, runs",                   "max": VIEW, "nav": False},
    "data_recon":    {"label": "Recon data",       "about": "Data behind widgets: reconciliation results and alarms",      "max": VIEW, "nav": False},
}

# roles created by `manage.py seed-roles` (can be changed in the GUI afterwards)
_NONE = {m: NONE for m in MODULES}


def _role(description, **levels):
    return {"description": description, "permissions": {**_NONE, **levels}}


BUILTIN_ROLES = {
    "admin":    {"description": "Full access, including users, roles and all dashboards",
                 "permissions": {m: d["max"] for m, d in MODULES.items()}},
    "operator": _role("Runs the platform: edits lookups, views everything operational", sources=VIEW, lookups=EDIT, recon=VIEW,
                      dashboards=VIEW, data_pipeline=VIEW, data_recon=VIEW),
    "viewer":   _role("Read only", sources=VIEW, lookups=VIEW, recon=VIEW, dashboards=VIEW, data_pipeline=VIEW, data_recon=VIEW),
    "code-editor":   _role("Edits and validates transformation code drafts (cannot approve)", sources=VIEW, transform=EDIT),
    "code-approver": _role("Reads transformation code and approves, discards or restores versions", sources=VIEW, transform=VIEW, transform_approve=EDIT),
    "dashboard-creator":   _role("Builds dashboards (cannot publish or share)", sources=VIEW, recon=VIEW, dashboards=EDIT,
                                 data_pipeline=VIEW, data_recon=VIEW),
    "dashboard-publisher": _role("Builds, publishes and shares own dashboards", sources=VIEW, recon=VIEW, dashboards=EDIT, dash_publish=EDIT,
                                 data_pipeline=VIEW, data_recon=VIEW),
}


def clean(perms) -> dict:
    """Keeps only known modules, integer levels, never above the module's max."""
    out = {}
    for m, d in MODULES.items():
        try:
            lv = int((perms or {}).get(m, NONE))
        except (TypeError, ValueError):
            lv = NONE
        out[m] = max(NONE, min(lv, d["max"]))
    return out


def loads(text) -> dict:
    try:
        v = json.loads(text) if text else {}
        return v if isinstance(v, dict) else {}
    except (TypeError, ValueError):
        return {}


def effective(role_perms, overrides) -> dict:
    """Level per module for one user: the override if there is one, else the role's level."""
    base, ov = clean(role_perms), overrides or {}
    merged = dict(base)
    for m in MODULES:
        if m in ov and ov[m] not in ("", None):
            merged[m] = ov[m]
    return clean(merged)


def allowed(perms: dict, module: str, level: int = VIEW) -> bool:
    return int(perms.get(module, NONE)) >= level
