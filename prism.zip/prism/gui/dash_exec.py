"""
dash_exec.py - runs the queries built by dash_spec.py with cost and load controls.

  * maximum_bytes_billed   a query that would scan more than MAX_BYTES_BILLED fails BEFORE it is billed
  * timeout                result wait of TIMEOUT_SECONDS, then the job is cancelled
  * concurrency            at most MAX_CONCURRENT dashboard queries run at once per process; others wait, then get a "busy" message
  * labels                 every job is labelled app=prism-gui, feature=dashboards (cost reports)
  * the CMEK key of the control dataset is attached like every other PRISM job (BqHelper)
Telemetry (bytes processed, milliseconds, rows) is returned with each result so the caller can audit it.
The browser never receives SQL, credentials or tokens - only normalised result rows.
"""
import logging
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from typing import List

log = logging.getLogger("prism.dashboards")
MAX_BYTES_BILLED = 5 * 1024 ** 3        # 5 GiB per widget query (cost cap). Raise only deliberately.
TIMEOUT_SECONDS = 30
MAX_CONCURRENT = 4
BUSY_WAIT_SECONDS = 15


class QueryError(Exception):
    """Message is safe to show to the user."""


@dataclass
class Result:
    rows: List[dict]
    bytes_processed: int = 0
    millis: int = 0
    cached: bool = False


def _plain(v):
    if isinstance(v, datetime):
        return v.isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, Decimal):
        return float(v)
    return v


class BigQueryRunner:
    def __init__(self, helper, max_bytes=MAX_BYTES_BILLED, timeout=TIMEOUT_SECONDS, max_concurrent=MAX_CONCURRENT):
        self.helper, self.max_bytes, self.timeout = helper, max_bytes, timeout
        self.slots = threading.BoundedSemaphore(max_concurrent)

    def _params(self, q):
        from google.cloud import bigquery
        out = []
        for name, typ, val in q.params:
            if typ.startswith("ARRAY<"):
                out.append(bigquery.ArrayQueryParameter(name, typ[6:-1], list(val)))
            else:
                out.append(bigquery.ScalarQueryParameter(name, typ, val))
        return out

    def run(self, q) -> Result:
        from google.cloud import bigquery
        if not self.slots.acquire(timeout=BUSY_WAIT_SECONDS):
            raise QueryError("PRISM is busy running other dashboard queries. Please try again in a moment.")
        ref, t0 = uuid.uuid4().hex[:8], time.monotonic()
        try:
            cfg = bigquery.QueryJobConfig(query_parameters=self._params(q), maximum_bytes_billed=self.max_bytes,
                                          labels={"app": "prism-gui", "feature": "dashboards"})
            if getattr(self.helper, "enc", None) is not None:
                cfg.destination_encryption_configuration = self.helper.enc
            job = self.helper.client.query(q.sql, job_config=cfg)
            try:
                raw = list(job.result(timeout=self.timeout))
            except Exception as e:
                try:
                    job.cancel()
                except Exception:
                    pass
                raise e
            aliases = [c["alias"] for c in q.columns]
            rows = [{a: _plain(r[a]) for a in aliases} for r in raw]
            return Result(rows, int(getattr(job, "total_bytes_processed", 0) or 0), int((time.monotonic() - t0) * 1000),
                          bool(getattr(job, "cache_hit", False)))
        except QueryError:
            raise
        except Exception as e:
            text = str(e)
            if "bytesBilled" in text or "maximum bytes billed" in text.lower():
                raise QueryError(f"This query would scan more than {self.max_bytes // 1024 ** 3} GB. Choose a shorter date range or add a filter.")
            if type(e).__name__ in ("TimeoutError", "Timeout") or "timed out" in text.lower() or "Deadline" in text:
                raise QueryError(f"The query took longer than {self.timeout} seconds and was stopped. Choose a shorter date range or add a filter.")
            if type(e).__name__ == "Forbidden":
                raise QueryError("The GUI service account has no permission to read this table. Ask a PRISM administrator.")
            if type(e).__name__ == "NotFound":
                raise QueryError("The table behind this dataset was not found. Ask a PRISM administrator.")
            if "quota" in text.lower():
                raise QueryError("A BigQuery quota limit was reached. Try again later.")
            log.exception("dashboard query failed ref=%s", ref)
            raise QueryError(f"The query failed (reference {ref}). A PRISM administrator can find it in the logs.")
        finally:
            self.slots.release()
