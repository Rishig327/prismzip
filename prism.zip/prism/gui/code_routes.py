"""
code_routes.py - Sources -> <source> -> Transformation code: view, edit the draft, validate, approve, history, diff, restore.

Workflow (rules live in common/transform_store.py):
   approved vN  --start-->  DRAFT (one per source; everybody edits the SAME draft)  --validate-->  --approve (someone else)-->  approved vN+1
Permissions (rbac.py):  Transformation code  View = read, Edit = edit the draft and run validation;   Approve code  Edit = approve / discard / restore
Approval needs a validation with no errors on the exact code of the draft, and (REQUIRE_DIFFERENT_APPROVER) a person who did not make the last change.
Running jobs are never affected: each job runs the version it was launched with.
"""
import importlib
import json
import re
from datetime import datetime, timezone

from flask import Response, abort, flash, g, redirect, render_template, request, url_for

import code_dryrun
import code_validate as cv
import pyhighlight
import rbac
import transform_store as ts

REQUIRE_DIFFERENT_APPROVER = True          # the person who made the last change to the draft cannot approve it (four eyes). Set False for a one-person team.
SOURCE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,39}$")


def register(app, store, cfg, need, audit, forget):
    tt = store.transform

    def me():
        return g.user["username"]

    def src_or_404(name):
        if not SOURCE_RE.match(name or "") or not (name in set(cfg.sources()) or tt.latest(name)):
            abort(404)
        return name

    def can_edit():
        return rbac.allowed(g.perms, "transform", rbac.EDIT)

    def can_approve():
        return rbac.allowed(g.perms, "transform_approve", rbac.EDIT) and rbac.allowed(g.perms, "transform", rbac.VIEW)

    def schema_for(source):
        try:
            return list(importlib.import_module(f"{source.lower()}_schema").DETAIL_SCHEMA)
        except Exception:
            return None

    def lookup_names():
        return {n for n, r in cfg.latest_lookups().items() if r.get("enabled")}

    def static_report(source, code):
        schema = schema_for(source)
        return cv.validate(code, [c for c, _ in schema] if schema else None, lookup_names())

    def full_report(source, code, extra_rows):
        """static checks + the test run (only if the static checks found no error: running broken code adds nothing)."""
        rep = static_report(source, code)
        if rep["ok"]:
            schema = schema_for(source)
            rep["findings"] += code_dryrun.dry_run(code, extra_rows, dict(schema) if schema else None)
            order = {"error": 0, "warning": 1, "info": 2}
            rep["findings"].sort(key=lambda x: (order[x["level"]], x["line"] or 0))
            for lv, key in (("error", "errors"), ("warning", "warnings"), ("info", "infos")):
                rep[key] = sum(1 for x in rep["findings"] if x["level"] == lv)
            rep["ok"] = rep["errors"] == 0
        return rep

    def norm(code):
        code = (code or "").replace("\r\n", "\n").replace("\r", "\n")
        return code if code.endswith("\n") else code + "\n"

    def report_of(row):
        try:
            return json.loads(row["validation_report"]) if row and row.get("validation_report") else None
        except ValueError:
            return None

    def render_edit(source, draft, text=None, rev=None, report="draft", sample="", conflict=None):
        cur = tt.current_approved(source)
        return render_template("code_edit.html", source=source, draft=draft, cur=cur, text=text if text is not None else draft["code"],
                               rev=rev or draft["code_sha256"], report=report_of(draft) if report == "draft" else report, sample=sample, conflict=conflict,
                               can_approve=can_approve(), four_eyes=REQUIRE_DIFFERENT_APPROVER, me=me(), active_nav="sources")

    # ------------------------------------------------------------------ overview
    @app.get("/sources/<name>/code")
    @need("transform")
    def code_home(name):
        src = src_or_404(name)
        cur, dr = tt.current_approved(src), tt.draft(src)
        return render_template("code_home.html", source=src, cur=cur, draft=dr, versions=tt.approved_versions(src, 8), events=tt.events(src, 12),
                               can_edit=can_edit(), can_approve=can_approve(), report=report_of(dr), four_eyes=REQUIRE_DIFFERENT_APPROVER, me=me(), active_nav="sources")

    def pick(src, which):
        """'draft' | version number | None (= current) -> (row, label) or 404"""
        if which == "draft":
            row = tt.draft(src)
            return (row, "draft") if row else abort(404)
        if which in (None, ""):
            row = tt.current_approved(src)
            return (row, f"v{row['version']}") if row else abort(404)
        try:
            row = tt.get_approved(src, int(which))
        except ValueError:
            abort(404)
        return (row, f"v{row['version']}") if row else abort(404)

    @app.get("/sources/<name>/code/view")
    @need("transform")
    def code_view(name):
        src = src_or_404(name)
        row, label = pick(src, request.args.get("version"))
        return render_template("code_view.html", source=src, row=row, label=label, lines=pyhighlight.highlight_lines(row["code"]), cur=tt.current_approved(src),
                               draft=tt.draft(src), can_edit=can_edit(), active_nav="sources")

    @app.get("/sources/<name>/code/download")
    @need("transform")
    def code_download(name):
        src = src_or_404(name)
        row, label = pick(src, request.args.get("version"))
        audit("TRANSFORM_DOWNLOADED", None, f"{src} {label}")
        return Response(row["code"], mimetype="text/x-python", headers={"Content-Disposition": f'attachment; filename="transformation_{src}_{label}.py"'})

    @app.get("/sources/<name>/code/history")
    @need("transform")
    def code_history(name):
        src = src_or_404(name)
        return render_template("code_history.html", source=src, versions=tt.approved_versions(src, 100), events=tt.events(src, 60), draft=tt.draft(src),
                               can_edit=can_edit(), active_nav="sources")

    @app.get("/sources/<name>/code/diff")
    @need("transform")
    def code_diff(name):
        src = src_or_404(name)
        cur = tt.current_approved(src)
        a_row, a_label = pick(src, request.args.get("a") or (str(cur["version"]) if cur else None))
        b_row, b_label = pick(src, request.args.get("b") or ("draft" if tt.draft(src) else (str(cur["version"]) if cur else None)))
        rows = pyhighlight.diff_rows(a_row["code"], b_row["code"])
        return render_template("code_diff.html", source=src, a=a_label, b=b_label, rows=rows, same=not rows, active_nav="sources",
                               added=sum(r["kind"] == "add" for r in rows), removed=sum(r["kind"] == "del" for r in rows))

    # ------------------------------------------------------------------ editing
    @app.get("/sources/<name>/code/edit")
    @need("transform", rbac.EDIT)
    def code_edit(name):
        src = src_or_404(name)
        dr = tt.draft(src)
        if dr is None:
            cur = tt.current_approved(src)
            return render_template("code_edit.html", source=src, draft=None, cur=cur, text=None, rev=None, report=None, sample="", conflict=None,
                                   can_approve=can_approve(), four_eyes=REQUIRE_DIFFERENT_APPROVER, me=me(), active_nav="sources")
        return render_edit(src, dr)

    @app.post("/sources/<name>/code/start")
    @need("transform", rbac.EDIT)
    def code_start(name):
        src = src_or_404(name)
        try:
            d = tt.start_draft(src, me())
        except ts.TransformError as e:
            flash(str(e), "error")
            return redirect(url_for("code_edit", name=src))
        forget()
        audit("TRANSFORM_DRAFT_STARTED", None, f"{src} from v{d['version']}")
        flash(f"Draft started from version {d['version']}. Everyone who edits this source edits this same draft until it is approved or discarded.", "ok")
        return redirect(url_for("code_edit", name=src))

    @app.post("/sources/<name>/code/save")
    @need("transform", rbac.EDIT)
    def code_save(name):
        src = src_or_404(name)
        text, rev, action = norm(request.form.get("code")), request.form.get("rev"), request.form.get("action", "save")
        sample = request.form.get("sample_rows", "")
        try:
            d = tt.save_draft(src, text, me(), expect_sha=rev)
        except ts.Conflict as e:
            cur_draft = tt.draft(src)
            audit("TRANSFORM_SAVE_CONFLICT", None, src)
            return render_edit(src, cur_draft, text=text, rev=cur_draft["code_sha256"], report=None, sample=sample, conflict=str(e)), 409
        except ts.TransformError as e:
            flash(str(e), "error")
            return redirect(url_for("code_edit", name=src))
        changed = d["code_sha256"] != (rev or "")
        if changed:
            audit("TRANSFORM_DRAFT_SAVED", None, f"{src} sha={d['code_sha256'][:12]}")
        if action != "validate":
            flash("Draft saved. It must be validated again before it can be approved." if changed else "No changes to save.", "ok" if changed else "info")
            return redirect(url_for("code_edit", name=src))
        extra, err = code_dryrun.parse_extra(sample)
        if err:
            flash(err, "error")
            extra = []
        rep = full_report(src, d["code"], extra)
        d = tt.record_validation(src, me(), rep["ok"], rep)
        audit("TRANSFORM_VALIDATED", None, f"{src} {'ok' if rep['ok'] else 'FAILED'} errors={rep['errors']} warnings={rep['warnings']}")
        flash("Validation passed." + (f" {rep['warnings']} warning(s) to look at." if rep["warnings"] else "") if rep["ok"]
              else f"Validation found {rep['errors']} error(s). Fix them and validate again.", "ok" if rep["ok"] else "error")
        return render_edit(src, d, report=rep, sample=sample)

    @app.post("/sources/<name>/code/approve")
    @need("transform_approve", rbac.EDIT)
    def code_approve(name):
        src = src_or_404(name)
        if not can_approve():
            abort(403)
        dr = tt.draft(src)
        if dr is None:
            flash("There is no open draft to approve.", "error")
            return redirect(url_for("code_home", name=src))
        if dr.get("validation_ok"):                                # (an unvalidated draft is refused below with the plainer message)
            rep = static_report(src, dr["code"])                  # re-check now: a lookup may have been disabled since the validation
            if not rep["ok"]:
                flash(f"The code no longer passes the checks ({rep['errors']} error(s)). Ask the editor to fix and validate it again.", "error")
                return redirect(url_for("code_edit", name=src) if can_edit() else url_for("code_diff", name=src))
        try:
            v = tt.approve(src, me(), (request.form.get("note") or "").strip()[:300] or None, four_eyes=REQUIRE_DIFFERENT_APPROVER)
        except ts.TransformError as e:
            audit("TRANSFORM_APPROVE_REFUSED", None, f"{src}: {e}"[:300])
            flash(str(e), "error")
            return redirect(url_for("code_diff", name=src))
        forget()
        audit("TRANSFORM_APPROVED", None, f"{src} v{v} sha={dr['code_sha256'][:12]} edited_by={dr['edited_by']}")
        flash(f"Version {v} is now the current version. The next runs use it; jobs that are already running keep the version they started with.", "ok")
        return redirect(url_for("code_home", name=src))

    @app.post("/sources/<name>/code/discard")
    @need("transform")
    def code_discard(name):
        src = src_or_404(name)
        if not (can_edit() or can_approve()):
            abort(403)
        try:
            tt.discard(src, me())
        except ts.TransformError as e:
            flash(str(e), "error")
            return redirect(url_for("code_home", name=src))
        forget()
        audit("TRANSFORM_DRAFT_DISCARDED", None, src)
        flash("Draft discarded. The current approved version is unchanged.", "ok")
        return redirect(url_for("code_home", name=src))

    @app.post("/sources/<name>/code/restore/<int:version>")
    @need("transform", rbac.EDIT)
    def code_restore(name, version):
        src = src_or_404(name)
        try:
            tt.restore_as_draft(src, version, me())
        except ts.TransformError as e:
            flash(str(e), "error")
            return redirect(url_for("code_history", name=src))
        forget()
        audit("TRANSFORM_RESTORED", None, f"{src} v{version} as draft")
        flash(f"Version {version} was copied into a new draft. Validate and approve it to make it current (as a new version number).", "ok")
        return redirect(url_for("code_edit", name=src))
