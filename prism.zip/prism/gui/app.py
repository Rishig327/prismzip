"""
app.py - PRISM GUI (Flask, server-rendered, no JavaScript).

Sign-in with lock-out, forced password change, roles with per-module access (rbac.py), per-user overrides, user / role
administration, audit log, and three PRISM modules wired to the same ConfigStore as config_admin.py (every change is
validated by the same rules and recorded with the signed-in user as `changed_by`).

Run locally with sample data and no Google access:   PRISM_GUI_DEV=1 python gui/app.py      (prints the admin password)
Production: gunicorn "app:create_production_app()" - see docs/DEPLOY_GUI.md.
"""
import glob
import hashlib
import hmac
import json
import os
import re
import secrets
import sys
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for

# Run from the project folder (python gui/app.py): config_store.py and prism_settings.py live in ../orchestrator and ../common.
# In the image everything sits beside this file, so these folders do not exist and nothing is added.
_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
for _p in [os.path.join(_ROOT, "orchestrator"), os.path.join(_ROOT, "common")] + sorted(glob.glob(os.path.join(_ROOT, "sources", "*"))):       # sources/*: <source>_schema.py
    if os.path.isdir(_p) and _p not in sys.path:
        sys.path.append(_p)

import rbac
import security as sec

PUBLIC = {"login", "healthz", "static"}
USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._@-]{2,39}$")
ROLE_RE = re.compile(r"^[a-z][a-z0-9_-]{1,29}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def create_app(store, cfg, secret_key, dev=False, cache_seconds=20, runner=None):
    """store: users/roles/audit/dashboards (store.py).  cfg: a config_store.ConfigStore (or demo.DemoConfig).
    runner: executes dashboard queries (dash_exec.BigQueryRunner; demo.SampleRunner in demo mode)."""
    import config_store as cs                                   # ConfigError + the lookup rules shared with config_admin.py

    app = Flask(__name__)
    app.config.update(SECRET_KEY=secret_key, SESSION_COOKIE_NAME="prism_session", SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=not dev, MAX_CONTENT_LENGTH=64 * 1024,
                      PERMANENT_SESSION_LIFETIME=timedelta(minutes=sec.IDLE_MINUTES))
    cache = {}

    def cached(key, loader):
        hit = cache.get(key)
        if hit and (datetime.now() - hit[0]).total_seconds() < cache_seconds:
            return hit[1]
        val = loader()
        cache[key] = (datetime.now(), val)
        return val

    def forget():                       # after any change made through this instance
        cache.clear()

    def now():
        return datetime.now(timezone.utc)

    def get_user(name):
        return cached(("u", name), lambda: store.get_user(name))

    def perms_of(user):
        role = cached(("r", user["role"]), lambda: store.get_role(user["role"]))
        base = rbac.loads(role["permissions"]) if role and role.get("enabled") else {}
        return rbac.effective(base, rbac.loads(user.get("overrides")))

    def stamp(user):                    # changes when the password or enabled flag changes -> old sessions end.
        raw = f"{user['password_hash']}|{user['enabled']}"       # (role / override changes need no sign-out: perms are re-read every click)
        return hashlib.sha256(raw.encode()).hexdigest()[:20]

    def ip():
        return (request.headers.get("X-Forwarded-For", request.remote_addr or "").split(",")[0].strip() or None)

    def audit(event, username=None, detail=None):
        try:
            store.audit(event, username=username, actor=(g.user["username"] if g.get("user") else None), detail=detail, ip=ip())
        except Exception:               # an audit failure must not take the page down, but must be visible in the logs
            app.logger.exception("audit write failed: %s", event)

    def csrf():
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(24)
        return session["csrf"]

    def need(module, level=rbac.VIEW):
        def deco(fn):
            @wraps(fn)
            def wrapper(*a, **k):
                if not rbac.allowed(g.perms, module, level):
                    audit("ACCESS_DENIED", detail=f"{request.path} needs {module}>={level}")
                    abort(403)
                return fn(*a, **k)
            return wrapper
        return deco

    # ------------------------------------------------------------------ every request
    @app.before_request
    def gate():
        g.user, g.perms = None, {}
        if request.endpoint in (None, "static", "healthz"):
            return
        if request.method == "POST":                                         # CSRF on EVERY post, sign-in included
            sent = request.form.get("csrf_token", "")
            if not sent or not hmac.compare_digest(sent, session.get("csrf", "")):
                abort(400, "The form expired. Go back, refresh the page and try again.")
        uid = session.get("uid")
        if not uid:
            if request.endpoint in PUBLIC:
                return
            return redirect(url_for("login", next=request.full_path.rstrip("?")) if request.method == "GET" else url_for("login"))
        user = get_user(uid)
        too_old = now() - datetime.fromisoformat(session.get("login_at", "1970-01-01T00:00:00+00:00")) > timedelta(hours=sec.ABSOLUTE_HOURS)
        if not user or not user["enabled"] or session.get("stamp") != stamp(user) or too_old:
            session.clear()
            flash("Your session has ended. Please sign in again.", "info")
            return redirect(url_for("login"))
        session.permanent = True
        g.user, g.perms = user, perms_of(user)
        g.must_change = bool(user.get("must_change_password")) or sec.password_expired(user.get("password_changed_at"), now())
        if g.must_change and request.endpoint not in ("change_password", "logout"):
            flash("Please choose a new password to continue.", "info")
            return redirect(url_for("change_password"))

    @app.after_request
    def headers(resp):
        scripts = "'self'" if (request.endpoint or "").startswith(("dash_", "code_")) else "'none'"      # JavaScript only on Dashboard Studio and code-editor pages, only our own files, never inline
        resp.headers["Content-Security-Policy"] = ("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; font-src 'self'; "
                                                   f"script-src {scripts}; form-action 'self'; frame-ancestors 'none'; base-uri 'none'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["X-Frame-Options"] = "DENY"
        if request.endpoint != "static":
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.context_processor
    def inject():
        return {"csrf_token": csrf, "me": g.get("user"), "perms": g.get("perms", {}), "MODULES": rbac.MODULES, "LEVELS": rbac.LEVELS,
                "allowed": rbac.allowed, "loads": rbac.loads, "VIEW": rbac.VIEW, "EDIT": rbac.EDIT, "sec": sec, "dev": dev}

    @app.errorhandler(400)
    @app.errorhandler(403)
    @app.errorhandler(404)
    def http_error(e):
        text = {400: "Bad request", 403: "You do not have access to this page", 404: "Page not found"}[e.code]
        return render_template("error.html", code=e.code, title=text, detail=getattr(e, "description", "") if e.code == 400 else ""), e.code

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception("unhandled error")
        return render_template("error.html", code=500, title="Something went wrong", detail="The error has been logged."), 500

    @app.get("/healthz")
    def healthz():
        return "ok"

    # ------------------------------------------------------------------ sign in / out
    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.user:
            return redirect(url_for("home"))
        nxt = request.args.get("next") or request.form.get("next") or ""
        if request.method == "POST":
            username = (request.form.get("username") or "").strip().lower()[:64]
            password = request.form.get("password") or ""
            user = store.get_user(username) if username else None          # always fresh here, never from the cache
            wait = None
            if user:
                end = sec.lock_until(store.lock_events(username, sec.LOCK_RELEVANT), now())
                wait = max(1, int((end - now()).total_seconds() // 60) + 1) if end else None
            if wait:
                audit("LOGIN_BLOCKED", username, "account locked")
                flash(f"Too many wrong passwords. Try again in about {wait} minute(s), or ask an administrator to unlock the account.", "error")
            else:
                ok = sec.verify_password(user["password_hash"] if user else None, password)
                if user and ok and user["enabled"]:
                    session.clear()
                    session.update(uid=username, stamp=stamp(user), login_at=now().isoformat(), csrf=secrets.token_urlsafe(24))
                    session.permanent = True
                    g.user = user
                    audit("LOGIN_OK", username)
                    return redirect(nxt if sec.is_safe_next(nxt) else url_for("home"))
                audit("LOGIN_FAIL", username if user else None, "disabled" if (user and ok) else ("unknown user" if not user else None))
                flash("Incorrect username or password.", "error")      # same text for unknown user, wrong password, disabled
        return render_template("login.html", next=nxt)

    @app.post("/logout")
    def logout():
        audit("LOGOUT", g.user["username"] if g.user else None)
        session.clear()
        flash("You have been signed out.", "info")
        return redirect(url_for("login"))

    @app.route("/account/password", methods=["GET", "POST"])
    def change_password():
        if request.method == "POST":
            cur, new, again = (request.form.get(k) or "" for k in ("current", "new", "again"))
            hist = [v["password_hash"] for v in store.user_versions(g.user["username"], sec.HISTORY + 1)]
            probs = []
            if not sec.verify_password(g.user["password_hash"], cur):
                probs.append("The current password is not correct.")
            if new != again:
                probs.append("The two new passwords are not the same.")
            probs += [f"New password: {p}." for p in sec.policy_problems(new, g.user["username"], hist)]
            if probs:
                for p in probs:
                    flash(p, "error")
                audit("PASSWORD_CHANGE_FAILED", g.user["username"], "; ".join(probs)[:300])
            else:
                row = {**g.user, "password_hash": sec.hash_password(new), "must_change_password": False, "password_changed_at": now()}
                store.put_user(g.user["username"], row, by=g.user["username"], note="password changed by the user")
                forget()
                fresh = store.get_user(g.user["username"])
                session["stamp"] = stamp(fresh)                              # this session stays signed in, the others end
                audit("PASSWORD_CHANGED", g.user["username"])
                flash("Your password has been changed.", "ok")
                return redirect(url_for("home"))
        return render_template("change_password.html", forced=g.must_change)

    # ------------------------------------------------------------------ home
    @app.get("/")
    def home():
        tiles = [(k, d) for k, d in rbac.MODULES.items() if rbac.allowed(g.perms, k) and d.get("nav", True)]
        return render_template("home.html", tiles=tiles)

    # ------------------------------------------------------------------ module: lookups
    def lookup_form_values(existing=None):
        f = request.form
        return {"table_name": f.get("table_name", "").strip(), "key_fields": cs.coerce_lookup("key_fields", f.get("key_fields", "")),
                "value_fields": cs.coerce_lookup("value_fields", f.get("value_fields", "")),
                "match_type": cs.coerce_lookup("match_type", f.get("match_type", "")), "enabled": f.get("enabled") == "on"}

    @app.get("/lookups")
    @need("lookups")
    def lookups():
        return render_template("lookups.html", rows=sorted(cfg.latest_lookups().items()))

    @app.route("/lookups/new", methods=["GET", "POST"])
    @app.route("/lookups/<name>", methods=["GET", "POST"])
    @need("lookups")
    def lookup_edit(name=None):
        creating = name is None
        cur = {} if creating else cfg.latest_lookups().get(name)
        if cur is None:
            abort(404)
        if request.method == "POST":
            if not rbac.allowed(g.perms, "lookups", rbac.EDIT):
                abort(403)
            try:
                lname = (request.form.get("lookup_name") or "").strip() if creating else name
                cfg.set_lookup(lname, lookup_form_values(), by=g.user["username"], note=(request.form.get("note") or None) or None,
                               create=creating)
                audit("LOOKUP_CHANGED", g.user["username"], lname)
                flash(f"Lookup {lname} saved. The workers use it from the next run.", "ok")
                return redirect(url_for("lookups"))
            except cs.ConfigError as e:
                flash(str(e), "error")
                split = lambda k: [x.strip() for x in request.form.get(k, "").split(",") if x.strip()]      # noqa: E731
                cur = {**cur, "table_name": request.form.get("table_name", ""), "key_fields": split("key_fields"),
                       "value_fields": split("value_fields"), "match_type": request.form.get("match_type", ""),
                       "enabled": request.form.get("enabled") == "on"}
        hist = [] if creating else cfg.lookup_history(name, 8)
        return render_template("lookup_form.html", name=name, row=cur, creating=creating, history=hist,
                               match_types=cs.LOOKUP_MATCH_TYPES)

    # ------------------------------------------------------------------ module: sources (read only)
    @app.get("/sources")
    @need("sources")
    def sources():
        rows = [(s, cfg.latest_source(s)) for s in cfg.sources()]
        return render_template("sources.html", rows=rows, glob=cfg.latest_global())

    @app.get("/sources/<name>")
    @need("sources")
    def source_detail(name):
        row = cfg.latest_source(name)
        if row is None:
            abort(404)
        return render_template("source_detail.html", name=name, row=row, history=cfg.history("prism_config_source", "source_type", name, 8))

    # ------------------------------------------------------------------ module: recon (read only)
    @app.get("/recon")
    @need("recon")
    def recon():
        return render_template("recon.html", rows=sorted(cfg.latest_recons().items()), dumps=lambda d: json.dumps(d, indent=2, default=str))

    # ------------------------------------------------------------------ module: audit
    @app.get("/audit")
    @need("audit")
    def audit_log():
        u, ev = (request.args.get("user") or "").strip().lower() or None, (request.args.get("event") or "").strip().upper() or None
        return render_template("audit.html", rows=store.list_audit(300, u, ev), user=u or "", event=ev or "")

    # ------------------------------------------------------------------ module: users
    def admins_left(username, new_row):
        """Enabled users who can edit users, after `username` is replaced by new_row (None = unchanged list)."""
        n = 0
        for u in store.list_users():
            if u["username"] == username:
                u = new_row
            if u and u["enabled"] and rbac.allowed(perms_of(u), "users", rbac.EDIT):
                n += 1
        return n

    def parse_user_form(base):
        f, errs = request.form, []
        role = f.get("role", "")
        if not store.get_role(role):
            errs.append("Choose an existing role.")
        email = (f.get("email") or "").strip()
        if email and not EMAIL_RE.match(email):
            errs.append("The e-mail address does not look valid.")
        ov = {}
        for m in rbac.MODULES:
            v = f.get("ov_" + m, "")
            if v in ("0", "1", "2"):
                ov[m] = int(v)
        ov = {m: min(v, rbac.MODULES[m]["max"]) for m, v in ov.items()}          # an override never exceeds what the module supports
        row = {**base, "display_name": (f.get("display_name") or "").strip()[:80], "email": email[:120] or None, "role": role,
               "overrides": json.dumps(ov), "enabled": f.get("enabled") == "on"}
        return row, errs

    @app.get("/users")
    @need("users")
    def users():
        locked = {}
        for u in store.list_users():
            end = sec.lock_until(store.lock_events(u["username"], sec.LOCK_RELEVANT), now())
            locked[u["username"]] = bool(end)
        return render_template("users.html", rows=store.list_users(), locked=locked)

    @app.route("/users/new", methods=["GET", "POST"])
    @need("users", rbac.EDIT)
    def user_new():
        row = {"role": "viewer", "enabled": True, "overrides": "{}"}
        if request.method == "POST":
            username = (request.form.get("username") or "").strip().lower()
            row, errs = parse_user_form({})
            if not USERNAME_RE.match(username):
                errs.append("Username: 3-40 characters, lower case letters, digits and . _ @ -")
            elif store.get_user(username):
                errs.append("That username already exists.")
            temp = (request.form.get("temp_password") or "").strip() or sec.generate_temp_password()
            errs += [f"Temporary password: {p}." for p in sec.policy_problems(temp, username)]
            if errs:
                for e in errs:
                    flash(e, "error")
            else:
                row.update(password_hash=sec.hash_password(temp), must_change_password=True, password_changed_at=now())
                store.put_user(username, row, by=g.user["username"], note="created")
                forget()
                audit("USER_CREATED", username, f"role={row['role']}")
                return render_template("temp_password.html", username=username, temp=temp, created=True)
        return render_template("user_form.html", u=row, creating=True, roles=store.list_roles(), history=[], locked=False)

    @app.route("/users/<username>", methods=["GET", "POST"])
    @need("users")
    def user_edit(username):
        user = store.get_user(username)
        if not user:
            abort(404)
        if request.method == "POST":
            if not rbac.allowed(g.perms, "users", rbac.EDIT):
                abort(403)
            row, errs = parse_user_form(user)
            if username == g.user["username"] and not row["enabled"]:
                errs.append("You cannot disable your own account.")
            if admins_left(username, row) < 1:
                errs.append("This change would leave no enabled user who can manage users.")
            if errs:
                for e in errs:
                    flash(e, "error")
                user = {**user, **row}
            else:
                store.put_user(username, row, by=g.user["username"], note="edited")
                forget()
                audit("USER_CHANGED", username, f"role={row['role']} enabled={row['enabled']} overrides={row['overrides']}")
                flash("User saved. Changes to role and module access apply at the user's next click.", "ok")
                return redirect(url_for("users"))
        end = sec.lock_until(store.lock_events(username, sec.LOCK_RELEVANT), now())
        hist = [{k: v for k, v in r.items() if k != "password_hash"} for r in store.user_versions(username, 8)]
        return render_template("user_form.html", u=user, creating=False, roles=store.list_roles(), history=hist, locked=bool(end))

    @app.post("/users/<username>/reset-password")
    @need("users", rbac.EDIT)
    def user_reset(username):
        user = store.get_user(username)
        if not user:
            abort(404)
        temp = sec.generate_temp_password()
        store.put_user(username, {**user, "password_hash": sec.hash_password(temp), "must_change_password": True,
                                  "password_changed_at": now()}, by=g.user["username"], note="password reset by administrator")
        forget()
        audit("PASSWORD_RESET", username)
        return render_template("temp_password.html", username=username, temp=temp, created=False)

    @app.post("/users/<username>/unlock")
    @need("users", rbac.EDIT)
    def user_unlock(username):
        if not store.get_user(username):
            abort(404)
        audit("UNLOCK", username)
        flash(f"{username} can sign in again.", "ok")
        return redirect(url_for("user_edit", username=username))

    # ------------------------------------------------------------------ module: roles
    @app.get("/roles")
    @need("roles")
    def roles():
        counts = {}
        for u in store.list_users():
            counts[u["role"]] = counts.get(u["role"], 0) + 1
        return render_template("roles.html", rows=store.list_roles(), counts=counts)

    @app.route("/roles/new", methods=["GET", "POST"])
    @app.route("/roles/<name>", methods=["GET", "POST"])
    @need("roles")
    def role_edit(name=None):
        creating = name is None
        role = {"role_name": "", "description": "", "permissions": "{}", "enabled": True} if creating else store.get_role(name)
        if role is None:
            abort(404)
        if request.method == "POST":
            if not rbac.allowed(g.perms, "roles", rbac.EDIT):
                abort(403)
            rname = (request.form.get("role_name") or "").strip().lower() if creating else name
            perms = rbac.clean({m: request.form.get("p_" + m, "0") for m in rbac.MODULES})
            enabled, errs = request.form.get("enabled") == "on", []
            if creating and not ROLE_RE.match(rname):
                errs.append("Role name: 2-30 characters, lower case letters, digits, - and _, starting with a letter.")
            if creating and store.get_role(rname):
                errs.append("That role already exists.")
            if not creating:                                                # never lock everybody out of user/role management
                for u in store.list_users():
                    if u["role"] == rname and u["enabled"] and u["username"] == g.user["username"]:
                        mine = rbac.effective(perms if enabled else {}, rbac.loads(u.get("overrides")))
                        if mine["users"] < rbac.EDIT or mine["roles"] < rbac.EDIT:
                            errs.append("This change would remove your own access to Users or Roles.")
            if errs:
                for e in errs:
                    flash(e, "error")
                role = {**role, "role_name": rname, "description": request.form.get("description", ""), "permissions": json.dumps(perms), "enabled": enabled}
            else:
                store.put_role(rname, (request.form.get("description") or "").strip()[:200], perms, enabled, by=g.user["username"],
                               note="created" if creating else "edited")
                forget()
                audit("ROLE_CREATED" if creating else "ROLE_CHANGED", None, f"{rname} {json.dumps(perms)} enabled={enabled}")
                flash(f"Role {rname} saved. It applies to its users at their next click.", "ok")
                return redirect(url_for("roles"))
        return render_template("role_form.html", role=role, perms=rbac.clean(rbac.loads(role["permissions"])), creating=creating)

    import dashboards
    from dash_exec import QueryError

    class NoRunner:                                  # Dashboard Studio pages work; widgets say clearly that no data source is configured
        def run(self, q):
            raise QueryError("No query runner is configured for this GUI instance.")

    dashboards.register(app, store, runner or NoRunner(), need, audit, forget)
    import code_routes
    code_routes.register(app, store, cfg, need, audit, forget)

    return app


def create_production_app():
    """gunicorn entry point: BigQuery store + ConfigStore. The signing key comes from the environment (Secret Manager)."""
    from prism_settings import bq_kms_key_name, my_ctl_dataset, my_project
    import config_store as cs
    from store import BigQueryStore
    key = os.environ.get("PRISM_GUI_SECRET_KEY", "")
    if len(key) < 32:
        raise RuntimeError("PRISM_GUI_SECRET_KEY must be set (at least 32 random characters, from Secret Manager)")
    from dash_exec import BigQueryRunner
    bq = cs.BqHelper(my_project, os.environ.get("PRISM_LOCATION", "europe-west2"), bq_kms_key_name)
    return create_app(BigQueryStore(bq, my_project, my_ctl_dataset), cs.ConfigStore(bq, my_project, my_ctl_dataset), key, runner=BigQueryRunner(bq))


if __name__ == "__main__":                                   # local demo only
    if os.environ.get("PRISM_GUI_DEV") != "1":
        raise SystemExit("Local demo only: set PRISM_GUI_DEV=1 (production uses gunicorn, see docs/DEPLOY_GUI.md)")
    from demo import build_demo
    demo_app, admin_pw = build_demo()
    print(f"\n  PRISM GUI demo  http://127.0.0.1:5000   user: admin   password: {admin_pw}\n  (sample data, nothing is saved)\n")
    demo_app.run(host="127.0.0.1", port=5000)
