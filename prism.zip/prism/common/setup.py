"""
Packages the Dataflow worker code (--setup_file). It lives in the prism-common image and packages WHATEVER modules
are in /template at launch: the common ones plus the source modules added by the source image (prism-pgw ...).
So a new source image needs no change here.  (Only used inside the Dataflow images, never run from the project folder.)
"""
import os

from setuptools import setup

HERE = os.path.dirname(os.path.abspath(__file__))

setup(
    name="prism",
    version="1.0.0",
    py_modules=sorted(os.path.splitext(f)[0] for f in os.listdir(HERE) if f.endswith(".py") and f != "setup.py"),
)
