"""
transform_loader.py - gives a Dataflow worker the transformation code of ONE exact approved version, from the table.

The orchestrator chooses the version when it launches the job and passes --transform_version and --transform_sha, so every worker of
the job runs the same code even if someone approves a newer version meanwhile. The loader:
  1. reads that version from prism_transform_code                  (TransformUnavailable if it is not there)
  2. checks the SHA-256 of the code against the one the orchestrator saw  (the code cannot have changed since launch)
  3. compiles it and finds the class  transform_record              (a clear error with the line number if it does not compile)
  4. creates one instance and calls its setup() (loads the lookups)   - the plugin then calls .process(record) as before
Any failure raises: the worker stops BEFORE processing a single record rather than run unknown logic.
"""
import linecache
import logging
import threading
import types

from transform_store import TransformError, TransformUnavailable, default_table, sha256

log = logging.getLogger("prism.transform")
_classes = {}                      # (source, version, sha) -> compiled class   (one compile per worker process)
_lock = threading.Lock()
_table = None                      # tests inject a table here


def set_table(table):
    global _table
    _table = table
    _classes.clear()


def compile_transform(code: str, source: str, version: int):
    """Compiles the code as a module of its own and returns its transform_record class. Tracebacks show the real source lines."""
    filename = f"<prism-transform {source} v{version}>"
    module = types.ModuleType(f"prism_transform_{source.lower()}_v{version}")
    module.__file__ = filename
    linecache.cache[filename] = (len(code), None, code.splitlines(True), filename)       # so a traceback prints the line of the code
    try:
        exec(compile(code, filename, "exec"), module.__dict__)
    except SyntaxError as e:
        raise TransformError(f"The transformation code for {source} v{version} does not compile: line {e.lineno}: {e.msg}") from e
    cls = module.__dict__.get("transform_record")
    if not callable(cls):
        raise TransformError(f"The transformation code for {source} v{version} does not define the class transform_record.")
    return cls


def load_transform(source: str, version, sha: str = None):
    """-> an initialised transform_record instance (setup() already called)."""
    if not version:
        raise TransformError("No transform version was passed to the job (--transform_version).")
    version = int(version)
    key = (source, version, sha or "")
    with _lock:
        cls = _classes.get(key)
        if cls is None:
            table = _table or default_table()
            row = table.get_approved(source, version)
            if row is None:
                raise TransformUnavailable(f"Approved transformation code {source} v{version} was not found in the table.")
            actual = sha256(row["code"])
            if actual != row["code_sha256"] or (sha and sha != actual):
                raise TransformError(f"The transformation code {source} v{version} does not match the hash the orchestrator launched with "
                                     f"(expected {(sha or row['code_sha256'])[:12]}, found {actual[:12]}). Refusing to run it.")
            cls = _classes[key] = compile_transform(row["code"], source, version)
            log.info("loaded transformation code %s v%s (sha %s)", source, version, actual[:12])
    inst = cls()
    if hasattr(inst, "setup"):
        inst.setup()
    return inst
