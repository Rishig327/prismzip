"""
transform_store.py - the TRANSFORMATION CODE of a source, kept in BigQuery (VPDB_ADM.prism_transform_code) instead of a file in the image.

Used by three programs, so it lives in common/:
  * the GUI              reads and writes it (view, draft, validate, approve)
  * the orchestrator     reads the current approved version, records it on the run and passes it to the Dataflow job
  * the Dataflow workers read ONE exact version (transform_loader.py)

The table is APPEND-ONLY like the other PRISM tables: every save, validation, approval or discard inserts a new row.
  state   DRAFT | APPROVED | DISCARDED
  kind    start | save | validate | restore | approve | discard | seed
  version APPROVED rows: the version number (1, 2, 3 ...).  DRAFT rows: the approved version the draft was started from.
Derived facts (nothing is updated in place):
  open draft        = the NEWEST row of the source has state DRAFT   (editing again edits THAT draft: a new DRAFT row, same draft)
  current version   = the APPROVED row with the highest version
  approval          = inserts an APPROVED row with version = current + 1; the draft is then closed (newest row is no longer a DRAFT)
A job uses the version it was launched with, so approving while a job runs never changes that job.
"""
import hashlib
import json
from datetime import datetime, timezone
from typing import Dict, List, Optional

TABLE = "prism_transform_code"
MAX_CODE_BYTES = 500_000
ROW_COLS = ("state", "kind", "version", "code", "code_sha256", "edited_by", "validation_ok", "validation_at", "validation_report",
            "approved_by", "approved_at")


class TransformError(Exception):
    """Message is safe to show to the user."""


class TransformUnavailable(TransformError):
    """There is no approved version (yet) / the requested version does not exist."""


class Conflict(TransformError):
    """The draft was changed by someone else since this editor opened it."""


def sha256(code: str) -> str:
    return hashlib.sha256(code.encode("utf-8")).hexdigest()


def _now():
    return datetime.now(timezone.utc)


class _Workflow:
    """The rules, written once on top of five primitives: latest / current_approved / get_approved / _insert / events."""

    # ---- read helpers built on the primitives
    def draft(self, source: str) -> Optional[dict]:
        row = self.latest(source)
        return row if row and row["state"] == "DRAFT" else None

    def require_current(self, source: str) -> dict:
        row = self.current_approved(source)
        if row is None:
            raise TransformUnavailable(f"There is no approved transformation code for {source} yet. Seed version 1 first "
                                       "(python gui/manage.py seed-transform).")
        return row

    # ---- writes
    def _row(self, source, state, kind, version, code, by, note, edited_by=None, validation=None, approved_by=None, approved_at=None) -> dict:
        ok, at, report = validation or (None, None, None)
        return {"source_type": source, "state": state, "kind": kind, "version": version, "code": code, "code_sha256": sha256(code) if code is not None else None,
                "edited_by": edited_by, "validation_ok": ok, "validation_at": at, "validation_report": report, "approved_by": approved_by,
                "approved_at": approved_at, "changed_by": by, "note": note}

    @staticmethod
    def _check_code(code):
        if not isinstance(code, str) or not code.strip():
            raise TransformError("The code is empty.")
        if len(code.encode("utf-8")) > MAX_CODE_BYTES:
            raise TransformError(f"The code is larger than {MAX_CODE_BYTES // 1000} KB.")
        if "\x00" in code:
            raise TransformError("The code contains a NUL character.")

    def seed(self, source, code, by, note="initial import") -> int:
        """Version 1, once. Refuses when the source already has any row."""
        self._check_code(code)
        if self.latest(source) is not None:
            raise TransformError(f"{source} already has transformation code in the table; use the GUI to change it.")
        self._insert(self._row(source, "APPROVED", "seed", 1, code, by, note, edited_by=by, approved_by=by, approved_at=_now()))
        return 1

    def start_draft(self, source, by, from_row: Optional[dict] = None, kind="start") -> dict:
        """Opens THE draft of this source (only one at a time) from the current approved version, or from `from_row` (restore)."""
        if self.draft(source):
            raise TransformError("A draft is already open for this source. Continue editing it, or discard it first.")
        base = from_row or self.require_current(source)
        self._insert(self._row(source, "DRAFT", kind, base["version"] if kind == "start" else self.require_current(source)["version"],
                               base["code"], by, f"draft started from v{base['version']}", edited_by=by))
        return self.draft(source)

    def save_draft(self, source, code, by, expect_sha: Optional[str], note=None) -> dict:
        """Edits the open draft. expect_sha = the code hash the editor opened; if someone saved in between, nothing is written."""
        d = self.draft(source)
        if d is None:
            raise TransformError("There is no open draft. Start one first.")
        if expect_sha is not None and expect_sha != d["code_sha256"]:
            raise Conflict(f"The draft was changed by {d['edited_by'] or d['changed_by']} since you opened it. Reload to see their version.")
        self._check_code(code)
        if sha256(code) == d["code_sha256"]:
            return d                                              # nothing changed: no new row, validation stays
        self._insert(self._row(source, "DRAFT", "save", d["version"], code, by, note, edited_by=by))     # validation is cleared: new code
        return self.draft(source)

    def record_validation(self, source, by, ok: bool, report: dict) -> dict:
        """Attaches a validation result to the draft's CURRENT code (a new DRAFT row with the same code)."""
        d = self.draft(source)
        if d is None:
            raise TransformError("There is no open draft to validate.")
        self._insert(self._row(source, "DRAFT", "validate", d["version"], d["code"], by, "validated" if ok else "validation failed",
                               edited_by=d["edited_by"], validation=(bool(ok), _now(), json.dumps(report, default=str))))
        return self.draft(source)

    def approve(self, source, by, note=None, four_eyes=True) -> int:
        d = self.draft(source)
        if d is None:
            raise TransformError("There is no open draft to approve.")
        if not d["validation_ok"]:
            raise TransformError("The draft has not passed validation. Validate it (and fix any errors) before approving.")
        if four_eyes and by == d["edited_by"]:
            raise TransformError(f"{by} made the last change to this draft, so someone else must approve it.")
        cur = self.current_approved(source)
        if cur is not None and cur["code_sha256"] == d["code_sha256"]:
            raise TransformError(f"The draft is identical to version {cur['version']}, so there is nothing to approve. Make a change, or discard the draft.")
        nxt = (cur or {"version": 0})["version"] + 1
        self._insert(self._row(source, "APPROVED", "approve", nxt, d["code"], by, note, edited_by=d["edited_by"],
                               validation=(d["validation_ok"], d["validation_at"], d["validation_report"]), approved_by=by, approved_at=_now()))
        return nxt

    def discard(self, source, by, note=None):
        d = self.draft(source)
        if d is None:
            raise TransformError("There is no open draft to discard.")
        self._insert(self._row(source, "DISCARDED", "discard", d["version"], d["code"], by, note, edited_by=d["edited_by"]))

    def restore_as_draft(self, source, version, by) -> dict:
        old = self.get_approved(source, version)
        if old is None:
            raise TransformUnavailable(f"Version {version} does not exist.")
        return self.start_draft(source, by, from_row=old, kind="restore")


class MemoryTransformTable(_Workflow):
    """Same behaviour in memory: tests and the local demo."""

    def __init__(self):
        self.rows: Dict[str, List[dict]] = {}

    def _insert(self, row):
        self.rows.setdefault(row["source_type"], []).append({**row, "changed_at": _now()})

    def latest(self, source):
        r = self.rows.get(source)
        return dict(r[-1]) if r else None

    def current_approved(self, source):
        ap = [r for r in self.rows.get(source, []) if r["state"] == "APPROVED"]
        return dict(max(ap, key=lambda r: r["version"])) if ap else None

    def get_approved(self, source, version):
        ap = [r for r in self.rows.get(source, []) if r["state"] == "APPROVED" and r["version"] == int(version)]
        return dict(ap[-1]) if ap else None

    def approved_versions(self, source, limit=50):
        ap = sorted((r for r in self.rows.get(source, []) if r["state"] == "APPROVED"), key=lambda r: -r["version"])
        return [{k: v for k, v in r.items() if k != "code"} for r in ap][:limit]

    def events(self, source, limit=50):
        return [{k: v for k, v in r.items() if k not in ("code", "validation_report")} for r in reversed(self.rows.get(source, []))][:limit]


class TransformTable(_Workflow):
    """BigQuery. `bq` provides rows(sql, params) and run(sql, params): config_store.BqHelper, or SimpleBq below."""

    def __init__(self, bq, project: str, dataset: str):
        self.bq, self.ref = bq, f"`{project}.{dataset}.{TABLE}`"

    def _S(self):
        from google.cloud import bigquery
        return bigquery.ScalarQueryParameter

    def _insert(self, row):
        S = self._S()
        types = {"source_type": "STRING", "state": "STRING", "kind": "STRING", "version": "INT64", "code": "STRING", "code_sha256": "STRING",
                 "edited_by": "STRING", "validation_ok": "BOOL", "validation_at": "TIMESTAMP", "validation_report": "STRING",
                 "approved_by": "STRING", "approved_at": "TIMESTAMP", "changed_by": "STRING", "note": "STRING"}
        names = list(types)
        self.bq.run(f"INSERT INTO {self.ref} ({', '.join(names)}, changed_at) VALUES ({', '.join('@' + n for n in names)}, CURRENT_TIMESTAMP())",
                    [S(n, types[n], row.get(n)) for n in names])

    def _one(self, where, params, order):
        r = self.bq.rows(f"SELECT * FROM {self.ref} WHERE {where} ORDER BY {order} LIMIT 1", params)
        return dict(r[0].items()) if r else None

    def latest(self, source):
        return self._one("source_type = @s", [self._S()("s", "STRING", source)], "changed_at DESC")

    def current_approved(self, source):
        return self._one("source_type = @s AND state = 'APPROVED'", [self._S()("s", "STRING", source)], "version DESC, changed_at DESC")

    def get_approved(self, source, version):
        S = self._S()
        return self._one("source_type = @s AND state = 'APPROVED' AND version = @v", [S("s", "STRING", source), S("v", "INT64", int(version))], "changed_at DESC")

    def approved_versions(self, source, limit=50):
        return [dict(r.items()) for r in self.bq.rows(
            f"SELECT * EXCEPT(code) FROM {self.ref} WHERE source_type = @s AND state = 'APPROVED' ORDER BY version DESC LIMIT {int(limit)}",
            [self._S()("s", "STRING", source)])]

    def events(self, source, limit=50):
        return [dict(r.items()) for r in self.bq.rows(
            f"SELECT * EXCEPT(code, validation_report) FROM {self.ref} WHERE source_type = @s ORDER BY changed_at DESC LIMIT {int(limit)}",
            [self._S()("s", "STRING", source)])]


class SimpleBq:
    """Minimal BigQuery helper for programs that do not have config_store (the Dataflow workers). CMEK key attached like BqHelper."""

    def __init__(self, project: str, location: str, kms_key: Optional[str] = None):
        from google.cloud import bigquery
        self.client = bigquery.Client(project=project, location=location)
        self.enc = bigquery.EncryptionConfiguration(kms_key_name=kms_key) if kms_key else None

    def _cfg(self, params):
        from google.cloud import bigquery
        cfg = bigquery.QueryJobConfig(query_parameters=params or [])
        if self.enc is not None:
            cfg.destination_encryption_configuration = self.enc
        return cfg

    def rows(self, sql, params=None):
        return list(self.client.query(sql, job_config=self._cfg(params)).result())

    def run(self, sql, params=None):
        job = self.client.query(sql, job_config=self._cfg(params))
        job.result()
        return job


def default_table(project=None, dataset=None, location=None, kms_key=None) -> TransformTable:
    """The table with the PRISM settings (project / control dataset / CMEK key from prism_settings.py)."""
    import os
    from prism_settings import bq_kms_key_name, my_ctl_dataset, my_project
    project, dataset = project or my_project, dataset or my_ctl_dataset
    return TransformTable(SimpleBq(project, location or os.environ.get("PRISM_LOCATION", "europe-west2"), kms_key or bq_kms_key_name), project, dataset)
